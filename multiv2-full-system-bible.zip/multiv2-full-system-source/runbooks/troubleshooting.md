# Troubleshooting matrix

| Symptom | Probable causes | Diagnosis | Resolution/rollback |
|---|---|---|---|
| readiness 503 | missing model, CURRENT, invalid generation | `curl /health/ready`; logs | restore exact model/DB; validate before restart |
| dimension/backend mismatch | Qwen/SigLIP mix | inspect health generation metadata | use matching image/model/DB; never coerce dimension |
| no results/500 search | model load, FAISS, evidence parse | logs; repeat health then small KIS | repair external mount or rollback image |
| CPU very slow | 2-core host/model inference | timed requests, ps/free | functional mode only; use competition GPU |
| GPU OOM/fallback | insufficient VRAM/wrong runtime | nvidia-smi, torch CUDA summary, logs | stop rollout; qualify hardware/profile |
| frontend 404 | wrong working dir/static path | curl `/`, inspect image | correct image/source; no frontend AI inference |
| video 404 | source dir/template/cache | env/mount/path checks | correct read-only videos or URL allowlist |
| CORS error | ALLOWED_ORIGINS mismatch | browser devtools/curl Origin | exact origin; no wildcard with credentials |
| port conflict | existing listener | `ss -lntp` | change host mapping or stop approved conflicting process |
| Docker pull/auth failure | registry/network/tag | `docker pull`, digest inspect | authenticate/use verified cache/mirror |
| disk full | image/build/log/cache | `df -h`, `docker system df` | safe cache/log cleanup; preserve persistent data |
| full pytest collection fails | missing historical eval modules | run `python3 -m pytest -q` | repair test tree or use CI filtered gate with limitation |
| OCR/ASR absent | optional executable/model missing | `projectctl env --check`; readiness/evidence counts | prepare external deps or accept extractive/visual-only scope |
