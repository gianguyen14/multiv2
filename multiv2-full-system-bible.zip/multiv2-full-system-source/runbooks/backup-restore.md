# Backup and restore

## Backup set

- Git source revision and deployment compose/env template.
- Secret references/secret-manager records; never plaintext in the archive unless approved encrypted storage.
- DB v1 `index/CURRENT`, all active/rollback generation files and generation metadata.
- mapping/payload/FAISS artifact hashes.
- OCR/ASR spools and their metadata/fingerprints.
- External Qwen model files plus exact revision/identity.
- Raw videos if they cannot be rehydrated; cache is disposable.

## Procedure

Use filesystem snapshot or controlled `rsync`/archive to a separate protected location. Preserve modes and symlinks. Record SHA-256. Do not write into active runtime while serving.

## Restore verification

Restore to a new root first. Check `CURRENT` parses, generation validates, SHA-256 matches, FAISS ntotal equals mapping/payload counts, all UIDs are canonical and encoder backend/model/dimension match the runtime. Run readiness and KIS/QA/TRAKE smoke before cutover.

No repository-native backup command exists; operator storage tooling is required.
