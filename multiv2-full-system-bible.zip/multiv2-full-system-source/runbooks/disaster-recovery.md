# Disaster recovery

| Scenario | Action |
|---|---|
| Host lost | provision Docker/Compose, restore config and external mounts, pull pinned image, run smoke |
| Docker Hub unavailable | use cached immutable image or approved mirror; do not build from unknown state |
| DB corrupted | stop traffic, restore validated generation to new root, verify checksums/cardinality, cut over |
| CURRENT invalid | restore previous valid pointer only after generation validation |
| Model missing | readiness should fail; restore exact Qwen model mount/revision |
| Disk full | inspect df/docker system df/logs; prune safe builder cache only; never delete DB/model/videos blindly |
| CUDA OOM | stop GPU rollout, capture logs/VRAM, return to validated profile; do not change embedding semantics silently |
| Network outage | restrict/restore local service; remote QA/video URL fallbacks may be unavailable |
| Wrong backend/index | stop immediately; restore compatible app/image/DB pair |
| Permissions | inspect UID 1000/cache ownership and mount modes; keep sensitive mounts read-only |
