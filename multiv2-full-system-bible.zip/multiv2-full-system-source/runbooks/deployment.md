# Deployment runbook

## Preconditions

Use a Linux host with Docker Engine and Compose v2, enough disk for image/model/DB/cache, external Qwen model and DB v1 paths, raw video source if preview is required, and firewall/auth controls. GPU competition host additionally needs NVIDIA driver/container runtime. The repository does not install Docker or provision data.

## Directories

```bash
sudo mkdir -p /opt/aic/{config,cache/videos,logs}
# Place/verify external DB, model and videos using your approved storage procedure.
ls -ld /home/hermes/aic/data/aic-db-v1/runtime /home/hermes/aic/models/Qwen3-VL-Embedding-2B /video/video
```

Do not copy model/DB/video into the image. Keep DB/model/video mounts read-only and cache writable.

## Image-first CPU

```bash
cd /opt/aic/config
cp /path/to/repo/ops/docker/release/.env.cpu.example .env
# Set IMAGE_TAG to a verified immutable CPU tag, AIC_DATA_ROOT, AIC_MODEL_ROOT, AIC_VIDEO_ROOT, AIC_CACHE_ROOT and ALLOWED_ORIGINS.
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env config
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env pull
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env up -d
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env ps
curl -f http://127.0.0.1:8000/health/ready
curl -f http://127.0.0.1:3000/
```

Run KIS/QA/TRAKE and one video range request before opening LAN access. Verify `docker top`, mounts, image digest and readiness generation/backend.

## GPU

Use the GPU Compose file only on a host with working NVIDIA runtime. Set CUDA profile values, verify `nvidia-smi`, render Compose config and require no silent CPU fallback. GPU validation is pending in this audit.

## Reboot/post-deploy

`restart: unless-stopped` is configured in release compose. After reboot verify container status, mounts, readiness, logs, port listeners and a real query.
