# Rollback runbook

## Image/config rollback

```bash
docker compose -f <selected-compose.yml> down
IMAGE_TAG=<previous-verified-tag> docker compose -f <selected-compose.yml> pull
IMAGE_TAG=<previous-verified-tag> docker compose -f <selected-compose.yml> up -d
curl -f http://127.0.0.1:8000/health/ready
```

Verify the returned generation backend/dimension and run known KIS/QA/TRAKE/media smoke.

## DB generation rollback

Restore a previously validated immutable generation and atomically restore its compatible CURRENT pointer using the approved data procedure. Verify SHA-256, FAISS ntotal, mapping/payload cardinality, encoder identity, model revision and dimensions before serving.

## Embedding warning

Never point SigLIP2 runtime at a Qwen 1024-D DB or Qwen runtime at a SigLIP2 index. If code was removed in a future migration, rollback must use a prior compatible application image/commit, not an embedding-space switch.
