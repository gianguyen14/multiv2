# Upgrade runbook

1. Record current `docker compose ps`, image ID/digest, env checksum, DB CURRENT and health payload.
2. Back up env/config and record previous immutable image tag.
3. Verify target image exists and its source/runtime contract is compatible with external Qwen DB v1.
4. Render Compose config; inspect ports, env and mount modes.
5. Pull target image; do not use `latest` or historical stale tags without explicit verification.
6. Recreate one service with `up -d`; do not rebuild or mutate external DB/model.
7. Wait for readiness; run KIS, QA, TRAKE, frontend and range checks.
8. If any mandatory check fails, use rollback immediately.

Never upgrade application image and embedding DB generation as unrelated changes. DB changes require separate compatibility validation.
