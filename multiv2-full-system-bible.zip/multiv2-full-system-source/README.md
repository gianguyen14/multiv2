# Full source documentation package

This package is a detailed source-audit/documentation source for `gianguyen14/multiv2`. It is intentionally Markdown/CSV/Mermaid/evidence only; no PDF is created in this task.

## Audit identity

- Requested baseline: `16386cbccf207977fa408dd2c8db614642583d3c`
- Actual audit commit: `245e50860c800de1e33fbfc8e9a846c82525e7c0`
- Branch: `migration/qwen-only-search`
- Audit timestamp: `2026-09-19T10:31:31Z` UTC
- State: `CURRENT_QWEN_PRIMARY_VALIDATED`
- Qwen-only migration: NOT COMPLETED
- SigLIP2 removal: BLOCKED by current roles
- GPU validation: `PENDING_GPU_VALIDATION`

## How to read

Start at `FULL_SYSTEM_BIBLE.md`. It contains the actual chapter text and appendices rather than only links. Then inspect `chapters/` for individually editable sections, `inventories/` for machine-readable audits, `architecture/` for Mermaid source, `runbooks/` for operations, `audits/` for risk/security/consistency, `benchmarks/` for raw/statistically correct evidence and `validation/` for command/test timelines.

## Scope limits

Tracked source at the actual audit commit was audited. Untracked working-tree experiments/data were excluded. Production DB/model/video assets are external and were not copied into this package. No GPU existed on the audit host. Docker Compose plugin was unavailable, so Compose runtime validation is UNVERIFIED. No source migration was performed.
