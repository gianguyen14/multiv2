# File reference appendix

Every tracked file is represented below. Important source files include symbols and operational implications; small artifacts are grouped by explicit path but still described.

## `.dockerignore`
**Role:** Committed container file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.env.example`
**Role:** Documented environment template for host paths, search backend, OCR/ASR, QA, refiner, networking and secrets placeholders.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.github/workflows/ci.yml`
**Role:** GitHub Actions workflow for CI or security scanning.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: name, on, push, branches, pull_request, branches, workflow_dispatch, permissions, contents, concurrency, group, cancel-in-progress
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.github/workflows/defender-for-devops.yml`
**Role:** GitHub Actions workflow for CI or security scanning.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: name, on, push, branches, pull_request, branches, schedule, jobs, MSDO, runs-on, steps
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.gitignore`
**Role:** Committed configuration file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `AGENTS.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ARCHITECTURE.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `DOCKER.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `Dockerfile`
**Role:** Single-stage Python 3.12 production image; installs CPU/CUDA-selectable torch, OS media/OCR packages, source and one-worker Uvicorn.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** FROM, ARG, ENV, RUN, COPY, USER, ENTRYPOINT, CMD
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `README.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `README.vi.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `SECURITY.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/ablation_results.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/autonomous_m27_m31_state.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/benchmark_patched_results.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/final_engineering_stabilization_state.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/frame_sampling_benchmark_matrix.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/frame_sampling_final_report.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/frame_sampling_legacy_baseline.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/m27_three_video_query_results.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/m31_final_report.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/real_sample_validation.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V004.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V005.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V006.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V007.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V008.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V009.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V010.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V011.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V012.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V013.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V014.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V015.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V016.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V017.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V018.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V001.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V001.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V001.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V002.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V002.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V002.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V003.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V003.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V003.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V004.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V004.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V004.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V005.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V005.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V005.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V006.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V006.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V006.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V007.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V007.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V007.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V008.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V008.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V008.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V009.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V009.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V009.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V010.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V010.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V010.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V011.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V011.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V011.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V012.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V012.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V012.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/video_audit.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/video_transcripts_sample.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/video_transcripts_sampled_windows.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/__init__.py`
**Role:** Committed application-source file for backend; purpose inferred from path and file header.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/api/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/api/advanced_search_api.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** configure_advanced_search_service, _get_service, _response, search_text_advanced, search_image_advanced, search_hybrid
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/api/search_api.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** configure_search_service, _get_search_service, search_text_endpoint, search_image_endpoint
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/competition_data.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** KISGroundTruth, QAGroundTruth, TRAKEGroundTruth, validate_dataset, dataset_report, load_jsonl, _validate, OrganizerAdapter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/competition_evaluation.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** evaluate_competition, _mean_report
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/local_refine_config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** LocalRefineConfig
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/retrieval_config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RetrievalConfig
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/video_ingest_config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _fingerprint, VideoIngestConfig
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/core/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/core/config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/dataset_ops.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** verify_media
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QueryCache
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/centroid_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShardCentroidIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/coordinator.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DistributedCoordinator
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m10_cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M10QueryCache
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m10_coordinator.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M10Coordinator
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m10_merge.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** merge_normalized
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m11_centroid_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MultiCentroidIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m11_merge.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** merge_zscore, merge_hybrid
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m11_router.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M11SemanticRouter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/merge.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** merge_results
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/router.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShardRouter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/routing_policy.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RoutingPolicy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/rpc.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ThreadRPC
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/semantic_router.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SemanticShardRouter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/worker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FaissWorker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/embeddings/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/embeddings/qwen3_vl.py`
**Role:** Local Qwen3-VL text-query adapter with instruction, pooling, MRL truncation and float32 L2 normalization.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** resolve_model_dir, model_script_path, weights_available, Qwen3VlLocalEmbedder
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/embeddings/siglip2.py`
**Role:** SigLIP2 dual-encoder adapter for legacy text and image embeddings, long-text handling and model identity.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** resolve_siglip2_revision, SigLIP2Encoder, get_siglip2_encoder
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/advanced_faiss_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AdvancedFaissIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/benchmark.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** generate_synthetic_embeddings, get_process_memory_mb, benchmark_index_suite
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/faiss_siglip_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FaissSigLIPIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/index_factory.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** IndexFactory
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/loaders/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/loaders/aic_loader.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AICLoader, create_loader
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/loaders/metadata_loader.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MetadataError, _run_ffprobe, _fallback_from_filename, load_metadata
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/main.py`
**Role:** FastAPI composition root: backend selection, health, search, frontend assets, frame serving and HTTP range video routes.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _iter_file_range, _debug_api_errors_enabled, _unavailable_detail, _read_limited_body, _multipart_file, _decode_image, SearchRequest, _build_configured_search, create_app
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/model_cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** model_cache_dir, visual_model_name, asr_model_name, _status, visual_status, _download_asr, asr_status, paddleocr_status, prepare_paddleocr, prepare_visual, prepare_asr, query_refiner_model_name, query_refiner_status, prepare_query_refiner, inventory
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/pipelines/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/async_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AsyncFaissRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/batch_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** BatchFaissRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** EmbeddingCache
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/candidate_resolver.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CandidateResolver, MappingCandidateResolver, PersistentCandidateResolver, candidate_id, resolve_candidates
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/competition_scoring.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** kis_r_score, qa_r_score, trake_r_score, competition_score, diversify
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/cross_encoder_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CrossEncoderReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/distributed_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DistributedRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/hybrid_ranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** HybridRanker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/hybrid_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** HybridSigLIPRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/kis_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** KISResult, DenseTemporalRefiner, KISPipeline, frame_interval_hit
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/local_refinement.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CoarseCandidate, MergedRegion, RefinedCandidate, generate_candidate_regions, generate_local_timestamps, refine_coarse_candidates
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/m12_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M12RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/m13_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M13RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/m14_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M14RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/model_scorer.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** validate_scores, ModelScorer, DeterministicTestScorer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/ninerouter_vision_scorer.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** NineRouterError, NineRouterHTTPError, _default_transport, NineRouterVisionScorer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/qa_query_decomposition.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QAQueryDecomposer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/query_planner.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Plan, QueryPlanner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/ranking_metrics.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _relevance, _unique_at_k, recall_at_k, precision_at_k, mrr_at_k, ndcg_at_k, ranking_metrics
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SimpleCosineReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SigLIPFaissRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/semantic_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SemanticReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/sharded_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShardedRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/siglip_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SigLIPSemanticScorer, create_siglip_reranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/trake.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** EventCandidate, TRAKEResult, TRAKEAligner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/video_multimodal.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _content_tokens, _query_features, _phrase_relevance, lexical_score, minmax, VideoSegmentCandidate, MultimodalVideoRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/video_qa.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _classify_question, _is_valid_answer, _extract_proper_nouns, _evidence_support, VideoQAResult, ExtractiveAnswerer, VideoQAPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrievers/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/runtime/device_policy.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RuntimeCapabilities, DeviceSelection, normalize_device, device_request, probe_torch, probe_ctranslate2, probe_paddle, resolve_device, _diagnostic_selection, runtime_summary
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/runtime/operations.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** memory_snapshot, memory_guard, resource_limits, resource_preflight, _get_git_provenance, write_run_manifest
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/samplers/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/samplers/base.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SamplingConfig, SamplingStrategy, FixedFPSStrategy, ShotPlusFixedFPSStrategy, AdaptiveDenseStrategy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/schemas/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/schemas/frame.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameData, ShotData
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/advanced_search_service.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AdvancedSearchService
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/candidate_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** classify_exact_match, CandidateReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/configured_search.py`
**Role:** Legacy SigLIP2 configured search provider including image search, query refinement, reranking and temporal refinement.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _read_modality_weight, _validated_modality_weight, _match_exact_term, ConfiguredSearch
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/qa_answer_synthesizer.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QAAnswerResult, QAAnswerSynthesizer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/query_refiner.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VisualQuery, TRAKEStagePlan, QueryPlan, LLMRefinementResponse, _phrase_pattern, _phrase_spans, _spans_overlap, validate_english_caption, DeterministicQueryParser, LocalLLMQueryRefiner, QueryPlanCache, QueryRefiner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/qwen_runtime_search.py`
**Role:** Qwen production text-query search provider: model encoding, FAISS recall, OCR/ASR fusion, QA and TRAKE.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** normalize_text, content_tokens, lexical_score, _prepared_lexical_score, build_timeline, nearest_uid, _best_text_evidence, _attach_video_evidence, QwenRuntimeSearch
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/search_service.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SearchService
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/temporal_refiner.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TemporalRefinerConfig, TemporalRegion, TemporalRefineCache, TemporalRefiner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/trake_coherence.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CoherenceDiagnostics, TRAKECoherenceAnalyzer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/video_source.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _lock_for, cache_dir, source_dir, source_url_template, configured, video_url_for, valid_video_id, _download, resolve_video_path
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/shot_detection/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/shot_detection/base.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShotDetector, TransNetV2Adapter, get_shot_detector, NullShotDetector
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/strategies/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/utils/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/utils/latency.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** LatencyRecorder
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/utils/profiling.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** timer, timing, measure_search_time, measure_batch_latency, memory_usage_estimate
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/validation/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/validation/dataset_validator.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** compute_file_sha256, get_process_rss_mb, create_subset_manifest, verify_frame_id_integrity, verify_artifact_integrity, run_query_batch_validation
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/atomic_io.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** fsync_directory, _replace, write_json_atomic, write_numpy_atomic
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_dedup.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** filter_near_duplicate_frames
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_id_policy.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameIdPolicy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_index.py`
**Role:** Immutable FAISS generation builder/validator and atomic CURRENT publication.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameIndexBundle, _sha256, current_generation_id, cleanup_stale_staging, _mapping_ids, validate_generation, load_current_frame_index, build_frame_index
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_neighborhood.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_frame_neighborhood, get_temporal_neighborhood
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_record.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameRecord
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_sampler.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameSamplingError, SampledFrame, iter_sample_frames, sample_frames, sample_sparse_shot_frames_with_protection, sample_sparse_shot_frames, iter_sample_sparse_shot_frames, extract_shot_representative_indices
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_store.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** source_hash, ResumePlan, FrameStore
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/ingest.py`
**Role:** CLI and orchestration for offline video ingest; constructs SigLIP2Encoder and publishes FAISS generations.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** discover_videos, ingest_path, main
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/ingest_manifest.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** IngestManifest
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/m15_ingestion_pipeline.py`
**Role:** Per-video metadata/frame/embedding ingestion pipeline with checkpointed manifests and resume.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VideoIngestionPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/m16_text_pipeline.py`
**Role:** Offline OCR/ASR evidence extraction, fingerprinting, cache validation and frame-timeline projection.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _fingerprint_digest, compute_ocr_fingerprint, compute_asr_fingerprint, TextEvidenceStore, M16TextPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/text_backends.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** resolve_whisper_revision, OCRBackend, TesseractOCRBackend, PaddleOCRBackend, AdaptiveOCRBackend, EasyOCRBackend, create_ocr_backend, ASRBackend, FasterWhisperASRBackend, SidecarASRBackend
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/text_evidence.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** normalize_text, OCRRecord, ASRSegment
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/video_decoder.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VideoDecodeError, DecodedFrame, _optional_int, _optional_float, inspect_video, iter_frames, inspect_and_count_video, decode_frame_indices
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/video_metadata.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VideoMetadata
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/scripts/__init__.py`
**Role:** Committed application-source file for backend/scripts; purpose inferred from path and file header.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `data/indexes/.gitkeep`
**Role:** Committed data-placeholder file for data/indexes; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `data/logs/.gitkeep`
**Role:** Committed data-placeholder file for data/logs; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `data/processed/.gitkeep`
**Role:** Committed data-placeholder file for data/processed; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/install.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/rollback.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/status.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/update.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.cpu.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, build, container_name, restart, ports, environment, volumes, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.cuda.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, backend, environment, deploy, worker, environment, deploy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.gpu.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, build, container_name, restart, ports, environment, volumes, deploy, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.release.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, container_name, restart, ports, environment, volumes, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, build, image, container_name, restart, ports, env_file, environment, volumes, healthcheck, aic-cli
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-entrypoint.sh`
**Role:** Committed container file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/.gitkeep`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/ADR-0005-qwen-backend.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/ADR-0006-qa-remote-llm.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/ADR-0007-video-preview.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/API_REFERENCE.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ARCHITECTURE.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/DATA_CONTRACT.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/DEPLOYMENT.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/QA_SYNTHESIS.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/QUICKSTART.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/RUNTIME_CONFIG.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/SEARCH_BACKENDS.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/autonomous_m27_m31_checkpoint.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m15_video_ingestion.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m16_text_evidence.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m27_representative_evaluation.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m27_three_video_evaluation.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m28_retrieval_quality_v2.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m29_temporal_refinement.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m30_qa_quality.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m31_final_competition_readiness.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/RC_RELEASE.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/REAL_DATA_VALIDATION.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_deployment.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_hub_private_deployment.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_release_1.0.0.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_release_1.1.0-rc1.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_engineering_freeze_report.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_engineering_stabilization_checkpoint.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_freeze_manifest.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_system_audit_and_architecture.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_worktree_inventory.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/real_data_validation_inventory.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/real_sample_validation.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/competition_data.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/projectctl.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/__init__.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/faiss_siglip_benchmark.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** generate_synthetic_vectors, generate_frame_ids, percentile_95, benchmark_faiss_sigclip_index, main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/sampling_benchmark.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** estimate_storage_size, run_benchmark, main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/sampling_benchmark_results.json`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/siglip2_benchmark.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_memory_usage_mb, get_gpu_memory_mb, create_test_images, run_benchmark
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/siglip2_benchmark_results.json`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/README.md`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/index.html`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/scripts/api.js`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/scripts/app.js`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/scripts/shortcuts.js`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/styles/main.css`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `multiv2-qwen-system-documentation.zip`
**Role:** Committed other file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `multiv2-qwen-system-documentation.zip.sha256`
**Role:** Committed other file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/DOCKER_CPU_GUIDE.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/DOCKER_GPU_GUIDE.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/FINALS_HARDWARE_QUALIFICATION.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/FULL_SYSTEM_USAGE_GUIDE.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/.env.cpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/.env.gpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/README.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/build-cpu.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/build-gpu.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/diagnose.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/.env.cpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/.env.gpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/compose.cpu.yml`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, container_name, restart, ports, environment, volumes, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/compose.gpu.yml`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, container_name, restart, ports, environment, volumes, deploy, healthcheck
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/finals_smoke.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/qualify_finals_hardware.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `projectctl.py`
**Role:** Operator CLI for env/doctor/status, model preparation, server startup, ingest, search, evaluation and cleanup.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** executable, tesseract_languages, _package_version, environment_report, command_env, command_dataset, command_smoke, model_inventory, readiness, _module, emit, configured_search, search_rows, command_doctor, _selected_models, command_models, _require_models, command_status
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `pyproject.toml`
**Role:** Committed configuration file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `pytest.ini`
**Role:** Committed configuration file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/base.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/cpu.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/dev.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/gpu.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `run_dev.py`
**Role:** Standard-library development runner: starts backend on 127.0.0.1:8000, serves/proxies frontend on 127.0.0.1:3000.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DevHTTPServer, DevRequestHandler, _backend_process, _stop_backend, _validate_layout, main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/ablation.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_ablation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/audit_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, run_audit_and_fix
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/build_gt_v1.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, build
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/build_gt_v2.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, build
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/build_m27_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_interval
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/create_m27_three_video_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, build
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/debug_qa.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/eval_m27.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** evaluate
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/eval_mini_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_eval
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/fusion_experiment.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** lexical_score_v2, strategy_d_visual_first_rerank
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/inspect_asr_ocr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/m26_1_trace.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** rank_of, init_searcher
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/make_contact_sheets.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/make_sparse_contacts.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/print_asr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/print_asr_v2_v3.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/prove_frames.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/run_queries.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/sample_asr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/sample_asr_windows.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/sample_text.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/subset_matrix.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/test_api.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/test_api_v2.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/test_fusion_v2.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_single_query
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/trace_fusion.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_traces
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/trace_qa.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/validate_artifacts.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/validate_ocr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** validate
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/validate_rc2_gpu.sh`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/__init__.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/fixtures/test_5s.mp4`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_advanced_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, make_system, test_reranking_changes_order_and_shape, test_hybrid_and_single_modality_fallbacks, test_expansion_and_edge_cases
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_aic_loader.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TestAICLoaderIntegration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_candidate_reranker_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyIndex, DummyResolver, DummyEncoder, test_configured_search_reranker_integration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_configured_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QueryEncoder, test_configured_app_lazily_opens_current_generation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_distributed_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Worker, test_routing_and_merge, test_distributed_correctness_cache_and_failure
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_faiss_siglip_index_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** siglip_encoder, sample_images, sample_frame_ids, TestFaissSigLIPIndexIntegration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m10_routing.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_semantic_routing_selects_closest_shards, test_merge_normalizes_and_deduplicates, test_cache_respects_routing_configuration, test_adaptive_policy_changes_behavior
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m11_ranking.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_multi_centroid_routing_and_recall, test_reranker_improves_ordering, test_hybrid_merge_and_zscore_dedup
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m12_quality.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, FakeRetriever, test_hard_negative_dataset_is_genuinely_difficult, test_candidate_generation_reranking_and_quality_gate, test_pipeline_survives_semantic_backend_failure
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m13_5_evaluation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, test_same_candidate_evaluation_reports_all_metrics, test_bootstrap_is_deterministic
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m13_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, FakeRetriever, FailingScorer, fixtures, test_retrieve_resolve_batch_score_and_same_candidate_invariant, test_model_failure_fails_open_to_retrieval_order, test_missing_payload_fails_open_without_dropping_results
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m13_siglip_real.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_real_siglip_dual_encoder_scores_local_images
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m14_9router_real.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_real_9router_model_accepts_image_and_returns_relevance_score
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m14_evaluation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Encoder, Scorer, test_m14_same_candidate_quality_signal_and_bootstrap_reporting, test_hard_negative_error_detects_negative_above_grade_three
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m14_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Encoder, Retriever, Scorer, pipeline, test_retrieves_once_scores_same_pool_preserves_metadata_and_stable_ties, test_invalid_score_or_exception_fails_open_for_entire_query, test_hybrid_uses_same_candidate_pool_and_final_k
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_config_invalidation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_config_invalidation_is_dependency_aware, test_manifest_claim_is_rejected_when_embedding_is_missing, test_index_type_change_rebuilds_only_index
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_corrupt_video_isolation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_corrupt_video_does_not_destroy_valid_dataset_ingestion
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_index_publication.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_failed_publication_preserves_previous_generation, test_current_replace_failure_preserves_active_generation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_interrupted_resume.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** logical_artifacts, test_forced_interruption_resumes_from_highest_valid_stage
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_multivideo_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_multivideo_search_resolves_original_frames
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_siglip2_real.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_real_siglip2_multivideo_search_mapping
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_video_ingestion.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, test_m15_ingestion_resume_index_and_resolution
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m16_text_evidence.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeOCR, FakeASR, ingest, test_ocr_asr_persistence_mapping_and_resume, test_modality_resume_does_not_suppress_later_asr, test_silent_no_text_and_failure_isolation, test_unicode_normalization_preserves_vietnamese, test_ocr_asr_fingerprint_invalidation_and_selective_rerun, test_corrupt_ocr_asr_json_safely_invalidates, test_legacy_ocr_asr_cache_without_meta_is_safely_accepted
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m17_multimodal_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** frame, test_each_modality_and_fusion_retrieve_their_evidence, test_multimodal_evaluation_has_complete_candidate_coverage
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m18_kis_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, FakeRetriever, test_dense_refinement_selects_exact_semantic_frame, test_dense_refinement_falls_back_and_enforces_budget
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m19_video_qa.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** KIS, record, test_qa_localizes_and_answers_from_ocr_evidence, test_qa_uses_asr_and_abstains_without_evidence
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m20_trake.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_trake_dynamic_programming_enforces_order, test_trake_rejects_wrong_order_and_impossible_gap, test_trake_impossible_intermediate_transition_no_spurious_path, test_trake_same_video_enforcement, test_trake_small_top_k_disjoint_candidates, test_trake_malformed_and_edge_case_events, test_trake_ties_are_deterministic, test_trake_cli_and_configured_search_consistency
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m21_competition_scoring.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_competition_cutoff_score_rewards_early_hits, test_qa_and_trake_scores_apply_full_conditions, test_diversification_removes_temporal_duplicates_and_caps_videos
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m23_operator_api.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_operator_ui_health_search_and_media, test_video_result_contract_and_player_assets, test_operator_page_contains_competition_controls, test_frontend_static_assets_are_served_and_traversal_rejected, test_unconfigured_search_and_path_traversal_are_rejected, test_frame_server_rejects_symlink_escape, test_cors_rejects_wildcard_with_credentials, test_security_headers_present_on_responses, test_search_endpoint_rejects_server_local_image_query
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m8_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Encoder, vectors, test_ivf_training_and_search, test_sharded_retrieval_and_pipeline, test_planner_decisions_and_config
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_ocr_routing_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MockIntegrationPrimaryPaddle, MockIntegrationFallbackTesseract, MockIntegrationFailingPaddle, test_adaptive_ocr_pipeline_integration_primary_success, test_adaptive_ocr_pipeline_integration_fallback_on_primary_error
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_performance_layer.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CountingEncoder, test_batch_matches_loop_for_flat_and_hnsw, test_async_matches_loop, test_cache_reduces_encoder_work
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_query_refiner_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyIndex, DummyResolver, DummyEncoder, DummyBundle, test_dual_visual_retrieval_dedup, test_ocr_and_visual_fusion, test_trake_dp_preservation, test_kis_fallback_when_query_refine_disabled, test_image_search_does_not_invoke_query_refiner, test_cli_query_plan, test_api_debug_query_plan, test_query_cache_corruption_resilience, test_synthetic_ocr_and_asr_routing_and_provenance, test_trake_gap_diagnostics_preserves_monotonicity
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_retrieval_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeSigLIP2Encoder, test_image_and_text_retrieval_pipeline, test_retrieval_edge_cases
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_siglip2_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TestSigLIP2Integration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_temporal_refiner_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** make_test_video, MockEncoder, test_configured_search_trake_end_to_end, test_offline_temporal_refinement_execution, test_kis_qa_image_search_contracts_unaffected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_video_preview.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _client_with_source, test_video_route_serves_mp4_and_head, test_video_route_supports_range_seek, test_video_route_rejects_invalid_or_missing_video, test_video_route_lazy_downloads_from_url
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/m15_support.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** create_video, MeanRGBEncoder
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/smoke_three_video.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_smoke
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_9router_vision_reranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** image_path, response, test_constructs_pairwise_multimodal_request_without_retrieval_signals, test_rejects_invalid_model_output, test_retries_only_transient_failures, test_does_not_retry_auth_failure, test_accepts_observed_route_to_canonical_model_normalization, test_rejects_upstream_model_switch
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_adaptive_ocr.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MockSentinelPaddleBackend, MockSentinelTesseractBackend, MockWorkingPaddleBackend, MockWorkingTesseractBackend, MockFailingPaddleBackend, test_auto_cpu_routing_selects_tesseract, test_auto_gpu_routing_selects_paddle_primary, test_paddle_success_does_not_call_tesseract, test_empty_paddle_result_triggers_tesseract_fallback, test_low_confidence_paddle_triggers_fallback, test_paddle_runtime_error_falls_back_gracefully, test_forced_tesseract_never_initializes_paddle, test_forced_paddle_device_error, test_cache_fingerprint_invalidation_on_backend_change, test_resume_sentinel_does_not_construct_ocr_backends, test_corrupt_cache_validation_fails_safely, test_unicode_vietnamese_preserved
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_benchmark_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_hhi_calculation, test_concentration_empty_and_normal, test_rank_metrics_calculations, test_latency_stats_calculations, test_query_input_loading_json_and_jsonl, test_failure_localization_stages, test_diversity_simulations
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_candidate_reranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_visual_only_preserves_rrf_order, test_exact_ocr_match_priority, test_partial_match_distinct_from_full_exact, test_multi_channel_candidate_priority, test_reranker_disabled_returns_unchanged, test_reranker_exception_fallback, test_score_scale_independence, test_no_gt_specific_strings
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_candidate_reranker_profiling.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _base_candidates, _plan, _ocr_evidence, _asr_evidence, test_candidate_reranker_profiling
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_candidate_resolver.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_single_and_missing_resolution, test_batch_preserves_order_and_metadata, test_resolve_candidates_preserves_retrieval_fields
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_competition_data.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_loads_internal_ground_truth_contracts, test_rejects_invalid_intervals_and_event_alignment
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_competition_evaluation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_competition_evaluator_reports_all_cutoffs
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_configured_search_fusion_weights.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _Encoder, _Resolver, _search, _plan, _ocr, _asr, test_weighted_rrf_is_sorted_by_fused_rank, test_modality_weights_are_isolated_and_zero_disables_work, test_default_rrf_weights_preserve_existing_asr_weight, test_invalid_modality_weight_is_rejected, test_invalid_visual_variant_weight_is_rejected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_device_policy.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** capability, test_device_syntax, test_precedence_keeps_explicit_auto, test_auto_cpu_and_cuda_are_backend_specific, test_explicit_cuda_errors_and_index_selection, test_cpu_only_components_reject_cuda
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_evaluator_semantics.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** evaluate_kis_result, evaluate_qa_result, evaluate_trake_result, test_kis_evaluator, test_qa_evaluator, test_trake_evaluator
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_faiss_siglip_index.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** sample_vectors, sample_frame_ids, TestFaissSigLIPIndex
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_dedup.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyFrameRecord, _make_unit_vector, test_first_frame_always_retained, test_near_duplicate_removed_when_above_threshold, test_distinct_frame_retained_when_below_threshold, test_threshold_boundary_deterministic_drop_at_exact_equality, test_comparison_against_previous_retained_reference, test_protected_shot_representative_survives_near_duplicate, test_all_detected_shots_remain_represented, test_periodic_only_fallback, test_disabled_dedup_returns_all_candidates, test_reject_invalid_dedup_threshold, test_dedup_determinism
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_id_policy.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_zero_and_one_based_submission_policies_preserve_internal_index, test_rejects_invalid_frame_policy_and_index
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_pipeline_invariants.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_timeline, test_config_rollback_legacy, test_config_sparse_shot_resolution, test_config_invalid_values_rejection, test_sampler_empty_input_raises_error, test_sampler_single_frame, test_sampler_interval_shorter_than_duration, test_sampler_interval_longer_than_duration, test_sampler_indivisible_duration, test_shot_boundary_matrix_and_filtering, test_synthetic_shot_coverage_100_percent, test_provenance_rules_and_forbidden_states, test_multi_shot_same_frame_edge_case, test_dedup_threshold_and_previous_retained_behavior, test_dedup_malformed_embeddings_rejection, test_metadata_roundtrip_new_and_old_payloads, test_existing_index_read_only_contract, test_shot_detector_factory_call_path_mocked
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_record.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_frame_uid_is_deterministic_and_roundtrips
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_sampler.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** frame, test_irregular_timestamps_preserve_original_source_indices, test_streaming_sampler_does_not_consume_ahead, test_missing_pts_is_not_reconstructed_from_fps
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_gpu_rc2_stabilization.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_provenance_without_git, test_command_status_without_git, test_ocr_fallback_reporting, test_paddleocr_status_diagnostics, test_siglip2_vocab_and_token_invariants, test_query_refiner_fallback_safety, test_entrypoint_script_executable
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_hybrid_ranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_normalization_and_configurable_weights, test_zero_variance_dedup_and_determinism, test_invalid_weights_and_nonpositive_top_k
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_image_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** StubConfiguredSearch, dummy_image, test_image_embedding_normalization, test_search_image_missing_file, test_search_image_unsupported_input_type, test_api_image_search_empty_body, test_api_image_search_corrupt_body, test_api_image_search_multipart_and_query_options, test_api_image_search_rejects_non_image_content_type, test_api_image_search_invalid_top_k, test_authoritative_frame_id_semantics
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_imports.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_backend_imports
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_latency.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_latency_summary_reports_required_percentiles
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_local_refinement.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SyntheticLocalFrame, test_region_generation_single_candidate, test_region_generation_clamp_start, test_region_generation_clamp_end_with_duration, test_region_generation_overlapping_same_video, test_region_generation_touching_windows, test_region_generation_separate_same_video, test_region_generation_cross_video_isolation, test_max_regions_applied_after_merging, test_max_regions_truncates_to_strongest, test_timestamp_generation_exact_intervals, test_timestamp_generation_non_divisible_end, test_timestamp_generation_deterministic_no_duplicates, test_refinement_selects_highest_similarity_frame, test_refinement_tie_break_earliest_timestamp, test_provider_called_once_per_merged_region, test_max_default_work_bound, test_config_validation_rejections
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_m13_5_corpus.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** write_corpus, test_valid_corpus_and_statistics, test_invalid_queries, test_duplicate_candidate_id, test_missing_image_path
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_m22_end_to_end_benchmark.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_benchmark_marks_unconfigured_stages_unavailable
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_metadata_loader.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_load_metadata_fixture, test_missing_file_raises, test_invalid_name_raises_without_fallback, test_fallback_only_when_allowed
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_model_cache.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module, test_visual_cached_and_missing, test_asr_cached_and_missing, test_model_cache_dir_precedence, test_prepare_uses_provider_resolvers, test_resolve_siglip2_and_whisper_snapshot_revisions, test_siglip2_encoder_identity_uses_resolved_revision
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_model_scorer.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, test_deterministic_scorer_batch_association_and_backend, test_siglip_dual_encoder_batches_images_and_names_backend
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_multimodal_retrieval_v2.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_lexical_score_precision, test_long_query_is_not_diluted_below_candidate_threshold, test_single_overlap_in_long_noisy_evidence_stays_below_threshold, test_focused_phrase_outscores_generic_single_term_for_long_query, test_stopword_only_query_has_no_lexical_signal, test_exact_phrase_receives_full_relevance_amid_extra_text, test_lexical_score_is_always_bounded, test_multimodal_weight_isolation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_operations.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_memory_guard_refuses_low_available_memory, test_resource_limits_are_conservative, test_resource_preflight_and_run_manifest
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_projectctl.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** args, test_env_json_reports_runtime, test_doctor_reports_optional_blockers, test_search_json_and_export, test_missing_ocr_fails_actionably, test_competition_evaluate_missing_data_is_clear, test_dataset_report_does_not_require_ground_truth, test_preprocess_preflight_only_stops_before_all_stages, test_preflight_failure_is_reported_and_nonzero, test_normal_preprocess_preserves_stage_order, test_preprocess_keeps_optional_modalities_fail_open, inventory, test_models_help, test_models_inventory_json, test_models_selective_prepare, test_models_dry_run_does_not_prepare, test_offline_verification_fails_for_missing_model, test_preprocess_checks_visual_before_ingest
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_projectctl_qa.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MockArgs, test_command_qa_decomposition, test_qa_query_decomposer
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qa_answer_synthesizer.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _Response, _synth, test_extractive_is_default_and_preserves_fallback, test_max_tokens_uses_configurable_budget_and_sends_it, test_max_tokens_floor_and_env_default, test_remote_sends_only_bounded_evidence_and_parses_answer, test_remote_failure_falls_back_without_raising, test_remote_abstention_keeps_remote_provenance, test_remote_empty_response_uses_extractive_fallback, test_default_remote_top_n_is_five, test_remote_top_n_clamped_to_safe_range, test_no_remote_call_when_not_configured
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qa_generalized_validation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_classify_question, test_unseen_synthetic_who_adversarial, test_valid_who_names, test_unseen_synthetic_where_adversarial, test_valid_where_locations, test_how_many_numeric_validation, test_directional_attribute_gating, test_proper_noun_constraint_gating, test_extractive_answerer_abstains_on_unsupported_adversarial, test_extractive_answerer_answers_supported_evidence, test_configured_qa_does_not_copy_evidence_between_candidates
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qa_query_decomposition.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_removes_dangling_vietnamese_copula_without_losing_constraints, test_preserves_vietnamese_subject_action_and_location, test_removes_unknown_action_but_keeps_subject_and_location, test_removes_unknown_topic_scaffold, test_preserves_internal_vietnamese_copula, test_preserves_wh_shaped_token_at_start_of_proper_name, test_preserves_wh_shaped_token_when_entity_starts_question, test_removes_capitalized_who_pronoun_at_start_of_question, test_preserves_english_holding_action_and_location, test_removes_unknown_english_doing_action, test_removes_english_fronted_auxiliary_but_keeps_constraints, test_removes_dangling_english_copula, test_yes_no_question_is_not_rewritten_as_wh_question, test_output_contract_and_empty_decomposition_fallback_are_preserved
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_query_focus_generalization.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_search_intent_cleanup_does_not_consume_a_noun_prefix, test_exact_text_cleanup_does_not_damage_a_containing_proper_name, test_qa_cleanup_preserves_proper_noun_that_starts_like_a_wh_word, test_long_query_prefers_multi_term_focus_over_a_generic_single_overlap
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_query_refiner.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_exact_string_license_plate, test_exact_string_generic_patterns, test_vietnamese_path_preserved, test_cultural_term_preservation, test_cultural_terms_require_whole_phrase_matches, test_polysemous_compounds_do_not_emit_unrelated_object, test_standalone_object_meaning_is_still_extracted, test_object_extraction_prefers_specific_compound, test_visual_query_keeps_semantic_focus_without_search_or_ocr_instructions, test_search_intent_does_not_consume_prefix_of_semantic_word, test_search_intent_strips_complete_media_phrase, test_exact_removal_preserves_larger_words_and_names, test_quoted_labelled_exact_removes_complete_text_constraint, test_text_label_without_exact_value_is_not_removed_as_dangling, test_qa_visual_query_removes_question_scaffolding, test_qa_who_rewrite_preserves_title_case_proper_noun, test_no_hallucination, test_invalid_json_fallback
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qwen_runtime_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _sha256, _canonical_uid, _write_generation, _write_spool, StubEncoder, runtime, _search, _touch_model, test_configured_and_readiness, test_readiness_cache_rechecks_model_presence, test_readiness_reports_missing_model_and_missing_root, test_refuses_siglip_index, test_kis_search_returns_verified_visual_top, test_ocr_evidence_expands_candidates, test_video_level_text_evidence_attached_to_every_row, test_qa_uses_same_pipeline_and_empty_query_rejected, test_trake_success_returns_ordered_frames, test_trake_impossible_sequence_errors
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_ranking_metrics.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_perfect_and_reversed_ranking, test_partial_empty_and_nonpositive_k, test_duplicates_do_not_inflate_metrics
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_run_dev.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** serving, test_proxy_bounds_stalled_upstream, test_proxy_network_error_closes_upstream
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_samplers.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_sampling_config, TestFixedFPSStrategy, TestShotPlusFixedFPSStrategy, TestAdaptiveDenseStrategy, TestFrameIdGeneration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_sampling_metadata.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_frames, test_sampling_reason_periodic_only, test_sampling_reason_shot_only, test_sampling_reason_periodic_plus_shot_overlap, test_multiple_shots_assigns_stable_zero_based_shot_ids, test_dedup_alignment_with_retained_metadata, test_old_artifact_backward_compatibility, test_index_publication_payload_preserves_sampling_metadata
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_semantic_reranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** candidates, test_callback_is_used_and_metadata_preserved, test_dot_product_fallback_and_top_k, test_batch_scoring_and_equal_score_ties_are_deterministic, test_model_failure_falls_back_to_retrieval_order
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_shot_aware_sampler.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_frames, MockShotDetector, test_short_shot_between_periodic_samples_retained, test_midpoint_overlaps_periodic_sample_exact_dedup, test_multiple_shots_coverage_invariant, test_chronological_ordering_and_no_duplicates, test_boundary_shots_near_video_start_and_end, test_invalid_detector_output_handled_gracefully, test_sparse_shot_determinism, test_pipeline_legacy_mode_does_not_invoke_detector
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_siglip2.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TestSigLIP2Encoder
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_siglip2_long_text.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeProcessor, FakeTokenizer, FakeModel, make_encoder, test_long_text_chunks_are_aggregated_back_to_each_query, test_short_text_is_unchanged_by_chunk_mode_when_not_normalized, test_chunk_cap_samples_across_full_query_including_tail, test_invalid_long_text_configuration_is_rejected, test_processor_without_tokenizer_is_rejected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_sparse_periodic_sampler.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_frames, test_legacy_mode_default_1s_sampling, test_sparse_3s_mode_sampling, test_sparse_5s_mode_sampling, test_non_divisible_duration_behavior, test_sampling_determinism, test_reject_invalid_sampler_interval, test_video_ingest_config_modes, test_video_ingest_config_from_env
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_temporal_nms.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** apply_temporal_nms, test_temporal_nms_dedup
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_temporal_refiner.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** create_synthetic_video, SyntheticColorEncoder, test_frame_identity_invariant_preserves_exact_pyav_ordinals, test_short_event_sampling_recovers_missing_sparse_frame, test_ordered_trake_monotonic_sequence_alignment, test_region_generation_and_overlapping_merge, test_max_region_limits_safety, test_cache_reuse_with_sentinel_encoder, test_cache_corruption_safe_rebuild, test_safe_fallback_on_refinement_error
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_text_backends.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_tesseract_is_default_and_cpu, test_faster_whisper_uses_cuda_index, test_easyocr_gpu_flag_comes_from_policy
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_trake_coherence.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyResult, test_close_valid_sequence, test_large_gap_valid_sequence_remains_valid, test_non_monotonic_sequence, test_empty_sequence, test_single_frame_sequence, test_tie_break_mode_determinism, test_diagnostic_mode_preserves_higher_semantic_score_despite_larger_gap
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_validation_annotation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_validate_ground_truth_template, test_reject_duplicate_ids, test_reject_unknown_video_id, test_reject_malformed_and_inverted_frame_ranges, test_unlabeled_template_validation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_video_decoder.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_inspects_and_decodes_cfr_fixture_in_display_order, test_sequential_roundtrip_beginning_middle_and_end
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_video_qa_m26_1.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_classify_how_many, test_classify_where, test_classify_disease, test_classify_who, answerer, test_abstain_on_empty_evidence, test_abstain_on_zero_evidence_support, test_abstain_stopword_location, test_abstain_bare_number_no_context, test_abstain_garbled_ocr_who, test_abstain_unsupported_question, test_answer_disease_from_asr, test_answer_how_many_with_unit, test_answer_proper_location, test_fusion_visual_query_no_text_needed, test_fusion_formula_bounded, test_fusion_formula_text_intent, test_fusion_negative_visual_score
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_video_source.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _clean_env, test_valid_video_id, test_resolve_from_cache, test_resolve_from_source_dir_serves_in_place, test_resolve_prefers_cache_over_source, _serve, test_lazy_download_from_url_template, test_lazy_download_is_atomic_on_failure, test_rejects_non_http_template, test_rejects_malformed_http_template, test_not_configured_raises, test_invalid_id_rejected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tools/__init__.py`
**Role:** Committed operations file for tools; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tools/benchmark_retrieval.py`
**Role:** Committed operations file for tools; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** BenchmarkQueryInput, ConcentrationMetrics, compute_hhi, compute_concentration, compute_rank_metrics, compute_latency_stats, _matches_ground_truth, _stage_has_ground_truth, localize_failure, simulate_diversity_soft_cap, simulate_round_robin_diversification, ProductionBenchmarkRunner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tools/prepare_validation_annotation.py`
**Role:** Committed operations file for tools; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ValidationReport, validate_ground_truth_file
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.
