# Environment variable reference

This appendix is generated from exact environment access patterns (`os.getenv`, `os.environ.get`, direct environment indexing, Compose/shell interpolation and `.env.example`). Uppercase constants without environment access are excluded.

## `AIC_BIND_IP`
- Source: `.env.example:10`
- Consumer: .env.example
- Default/requirement: `127.0.0.1`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:11`, `docker-compose.cpu.yml:12`, `docker-compose.gpu.yml:12`, `docker-compose.gpu.yml:13`, `docker-compose.release.yml:8`, `docker-compose.release.yml:9`, `docker-compose.yml:15`

## `AIC_CACHE_DIR`
- Source: `.env.example:17`
- Consumer: .env.example
- Default/requirement: `./cache`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:36`, `deploy/install.sh:40`, `docker-compose.yml:44`, `docker-compose.yml:71`

## `AIC_CACHE_ROOT`
- Source: `docker-compose.cpu.yml:38`
- Consumer: Compose/shell interpolation
- Default/requirement: `/home/hermes/aic/cache/videos`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:44`, `docker-compose.release.yml:34`, `ops/docker/release/compose.cpu.yml:34`, `ops/docker/release/compose.gpu.yml:34`

## `AIC_DATA_DIR`
- Source: `.env.example:15`
- Consumer: .env.example
- Default/requirement: `./data`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:34`, `deploy/install.sh:40`, `docker-compose.yml:42`, `docker-compose.yml:69`

## `AIC_DATA_ROOT`
- Source: `docker-compose.cpu.yml:35`
- Consumer: Compose/shell interpolation
- Default/requirement: `/home/hermes/aic/data/aic-db-v1/runtime`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:41`, `docker-compose.release.yml:31`, `ops/docker/release/compose.cpu.yml:31`, `ops/docker/release/compose.gpu.yml:31`

## `AIC_LOGS_DIR`
- Source: `.env.example:18`
- Consumer: .env.example
- Default/requirement: `./logs`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:37`, `deploy/install.sh:40`, `docker-compose.yml:45`, `docker-compose.yml:72`

## `AIC_MODELS_DIR`
- Source: `.env.example:16`
- Consumer: .env.example
- Default/requirement: `./models`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:35`, `deploy/install.sh:40`, `docker-compose.yml:43`, `docker-compose.yml:70`

## `AIC_MODEL_ROOT`
- Source: `docker-compose.cpu.yml:36`
- Consumer: Compose/shell interpolation
- Default/requirement: `/home/hermes/aic/models/Qwen3-VL-Embedding-2B`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:42`, `docker-compose.release.yml:32`, `ops/docker/release/compose.cpu.yml:32`, `ops/docker/release/compose.gpu.yml:32`

## `AIC_PORT`
- Source: `.env.example:11`
- Consumer: .env.example
- Default/requirement: `8000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.yml:15`

## `AIC_VIDEO_ROOT`
- Source: `docker-compose.cpu.yml:37`
- Consumer: Compose/shell interpolation
- Default/requirement: `/video/video`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:43`, `docker-compose.release.yml:33`, `ops/docker/release/compose.cpu.yml:33`, `ops/docker/release/compose.gpu.yml:33`

## `ALLOWED_ORIGINS`
- Source: `.env.example:59`
- Consumer: .env.example
- Default/requirement: `http://localhost:3000,http://127.0.0.1:3000,http://localhost:8000,http://127.0.0.1:8000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/main.py:240`, `docker-compose.cpu.yml:27`, `docker-compose.gpu.yml:28`, `docker-compose.release.yml:24`, `ops/docker/release/compose.cpu.yml:24`, `ops/docker/release/compose.gpu.yml:27`

## `ASR_CONCURRENCY`
- Source: `backend/app/runtime/operations.py:37`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `ASR_WEIGHT`
- Source: `scripts/eval_m27.py:10`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `BACKEND_URL`
- Source: `ops/finals_smoke.sh:5`
- Consumer: Compose/shell interpolation
- Default/requirement: `http://127.0.0.1:8000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `BM25_ENABLED`
- Source: `.env.example:91`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `DEBUG_API_ERRORS`
- Source: `backend/app/main.py:36`
- Consumer: Python os.getenv
- Default/requirement: `"false"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `DEBUG_QUERY_PLAN`
- Source: `.env.example:121`
- Consumer: .env.example
- Default/requirement: `false`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:67`, `backend/app/main.py:196`

## `DECODE_WORKERS`
- Source: `backend/app/runtime/operations.py:35`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `DOCKERFILE`
- Source: `docker-compose.cpu.yml:6`
- Consumer: Compose/shell interpolation
- Default/requirement: `Dockerfile`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:6`

## `E5_ENABLED`
- Source: `.env.example:90`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `FASTER_WHISPER_MODEL`
- Source: `.env.example:100`
- Consumer: .env.example
- Default/requirement: `small`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `FRONTEND_URL`
- Source: `ops/finals_smoke.sh:6`
- Consumer: Compose/shell interpolation
- Default/requirement: `http://127.0.0.1:3000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `HF_HOME`
- Source: `.env.example:23`
- Consumer: .env.example
- Default/requirement: `/cache/huggingface`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `HF_HUB_OFFLINE`
- Source: `.env.example:127`
- Consumer: .env.example
- Default/requirement: `0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:31`, `docker-compose.gpu.yml:32`, `docker-compose.release.yml:28`, `ops/docker/release/compose.cpu.yml:28`, `ops/docker/release/compose.gpu.yml:28`

## `HF_TOKEN`
- Source: `.env.example:134`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `IMAGE_REPOSITORY`
- Source: `docker-compose.cpu.yml:3`
- Consumer: Compose/shell interpolation
- Default/requirement: `gianguyen14/aic-retrieval`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:3`, `docker-compose.release.yml:3`, `ops/docker/release/compose.cpu.yml:3`, `ops/docker/release/compose.gpu.yml:3`

## `IMAGE_TAG`
- Source: `docker-compose.cpu.yml:3`
- Consumer: Compose/shell interpolation
- Default/requirement: `finals-20260917`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:3`, `docker-compose.release.yml:3`, `ops/docker/release/compose.cpu.yml:3`, `ops/docker/release/compose.gpu.yml:3`

## `LOCAL_REFINE_ENABLED`
- Source: `.env.example:70`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:49`, `backend/app/core/config.py:82`

## `LOCAL_REFINE_INTERVAL_SECONDS`
- Source: `.env.example:72`
- Consumer: .env.example
- Default/requirement: `0.5`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:53`, `backend/app/core/config.py:84`

## `LOCAL_REFINE_MAX_REGIONS`
- Source: `.env.example:73`
- Consumer: .env.example
- Default/requirement: `5`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:54`, `backend/app/core/config.py:85`

## `LOCAL_REFINE_WINDOW_SECONDS`
- Source: `.env.example:71`
- Consumer: .env.example
- Default/requirement: `10.0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:52`, `backend/app/core/config.py:83`

## `M14_9ROUTER_API_KEY`
- Source: `backend/app/retrieval/ninerouter_vision_scorer.py:68`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `MAX_MEMORY_FRACTION`
- Source: `backend/app/runtime/operations.py:24`
- Consumer: Python os.getenv
- Default/requirement: `"0.75"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/runtime/operations.py:33`

## `MAX_WORKERS`
- Source: `backend/app/runtime/operations.py:34`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `MIN_AVAILABLE_MEMORY_BYTES`
- Source: `backend/app/runtime/operations.py:25`
- Consumer: Python os.getenv
- Default/requirement: `str(2 * 1024 ** 3`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `MODEL_CACHE_DIR`
- Source: `.env.example:22`
- Consumer: .env.example
- Default/requirement: `/models`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `.env.example:34`, `backend/app/embeddings/qwen3_vl.py:36`, `backend/app/model_cache.py:8`, `docker-compose.yml:23`

## `OCR_BACKEND`
- Source: `.env.example:94`
- Consumer: .env.example
- Default/requirement: `auto`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:19`, `docker-compose.gpu.yml:38`, `projectctl.py:344`, `projectctl.py:760`

## `OCR_CPU_BACKEND`
- Source: `.env.example:95`
- Consumer: .env.example
- Default/requirement: `tesseract`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:20`

## `OCR_FALLBACK_BACKEND`
- Source: `backend/app/core/config.py:22`
- Consumer: Python os.getenv
- Default/requirement: `"tesseract"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_FALLBACK_ON_EMPTY`
- Source: `backend/app/core/config.py:25`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_FALLBACK_ON_ERROR`
- Source: `backend/app/core/config.py:26`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_FALLBACK_ON_LOW_CONFIDENCE`
- Source: `backend/app/core/config.py:27`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_GPU_BACKEND`
- Source: `.env.example:96`
- Consumer: .env.example
- Default/requirement: `paddleocr`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:21`, `docker-compose.gpu.yml:39`

## `OCR_PADDLE_DEVICE`
- Source: `backend/app/core/config.py:23`
- Consumer: Python os.getenv
- Default/requirement: `"auto"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_PADDLE_MIN_CONFIDENCE`
- Source: `.env.example:97`
- Consumer: .env.example
- Default/requirement: `0.50`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:24`

## `OCR_WEIGHT`
- Source: `scripts/eval_m27.py:9`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_WORKERS`
- Source: `backend/app/runtime/operations.py:36`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OPENAI_API_KEY`
- Source: `.env.example:133`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `PRETTY_NAME`
- Source: `ops/docker/diagnose.sh:4`
- Consumer: Compose/shell interpolation
- Default/requirement: `unknown`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `PYTHONUNBUFFERED`
- Source: `Dockerfile:13`
- Consumer: Docker ENV
- Default/requirement: `1`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `QA_ANSWER_API_KEY`
- Source: `.env.example:106`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:35`, `backend/app/services/qa_answer_synthesizer.py:62`, `docker-compose.yml:29`

## `QA_ANSWER_BACKEND`
- Source: `.env.example:102`
- Consumer: .env.example
- Default/requirement: `extractive`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:32`, `docker-compose.cpu.yml:20`, `docker-compose.gpu.yml:21`, `docker-compose.release.yml:17`, `docker-compose.yml:26`, `ops/docker/release/compose.cpu.yml:17`, `ops/docker/release/compose.gpu.yml:17`

## `QA_ANSWER_MAX_EVIDENCE_CHARS`
- Source: `.env.example:108`
- Consumer: .env.example
- Default/requirement: `12000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:37`, `docker-compose.yml:33`

## `QA_ANSWER_MAX_TOKENS`
- Source: `.env.example:110`
- Consumer: .env.example
- Default/requirement: `1024`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:43`, `docker-compose.yml:30`

## `QA_ANSWER_MODEL`
- Source: `.env.example:104`
- Consumer: .env.example
- Default/requirement: `agent-lite`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:34`, `docker-compose.yml:28`

## `QA_ANSWER_REMOTE_TOP_N`
- Source: `.env.example:113`
- Consumer: .env.example
- Default/requirement: `5`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:38`, `docker-compose.yml:32`

## `QA_ANSWER_TIMEOUT_SECONDS`
- Source: `.env.example:107`
- Consumer: .env.example
- Default/requirement: `8`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:36`, `docker-compose.yml:31`

## `QA_ANSWER_URL`
- Source: `.env.example:103`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:33`, `docker-compose.yml:27`

## `QUERY_REFINER_BACKEND`
- Source: `.env.example:116`
- Consumer: .env.example
- Default/requirement: `auto`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:62`

## `QUERY_REFINER_CACHE_ENABLED`
- Source: `.env.example:119`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:65`

## `QUERY_REFINER_ENABLED`
- Source: `backend/app/core/config.py:61`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/configured_search.py:87`, `docker-compose.cpu.yml:21`, `docker-compose.gpu.yml:22`, `docker-compose.release.yml:18`, `ops/docker/release/compose.cpu.yml:18`, `ops/docker/release/compose.gpu.yml:18`

## `QUERY_REFINER_MAX_VISUAL_VARIANTS`
- Source: `.env.example:118`
- Consumer: .env.example
- Default/requirement: `4`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:64`

## `QUERY_REFINER_MODEL`
- Source: `.env.example:117`
- Consumer: .env.example
- Default/requirement: `Qwen/Qwen2.5-1.5B-Instruct`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:63`

## `QUERY_REFINER_RRF_K`
- Source: `.env.example:120`
- Consumer: .env.example
- Default/requirement: `60`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:66`

## `QWEN3_VL_MODEL_DIR`
- Source: `.env.example:41`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/embeddings/qwen3_vl.py:33`, `docker-compose.yml:25`

## `QWEN_MODEL_DIR`
- Source: `backend/app/embeddings/qwen3_vl.py:33`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `RERANKER_ENABLED`
- Source: `.env.example:123`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:70`, `backend/app/services/configured_search.py:88`, `docker-compose.cpu.yml:24`, `docker-compose.gpu.yml:25`, `docker-compose.release.yml:21`, `ops/docker/release/compose.cpu.yml:21`, `ops/docker/release/compose.gpu.yml:21`

## `RERANKER_PROFILE`
- Source: `backend/app/services/candidate_reranker.py:105`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `ROOT_DIR`
- Source: `deploy/install.sh:9`
- Consumer: Compose/shell interpolation
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/rollback.sh:10`, `deploy/status.sh:9`, `deploy/update.sh:9`

## `RUN_M13_REAL_MODEL`
- Source: `tests/integration/test_m13_siglip_real.py:13`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `RUN_M14_REAL_MODEL`
- Source: `tests/integration/test_m14_9router_real.py:13`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `RUN_M15_REAL_MODEL`
- Source: `tests/integration/test_m15_siglip2_real.py:16`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `SCRIPT_DIR`
- Source: `deploy/install.sh:8`
- Consumer: Compose/shell interpolation
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/rollback.sh:9`, `deploy/status.sh:8`, `deploy/update.sh:8`

## `SEARCH_BACKEND`
- Source: `.env.example:32`
- Consumer: .env.example
- Default/requirement: `qwen3_vl`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/main.py:111`, `docker-compose.cpu.yml:19`, `docker-compose.gpu.yml:20`, `docker-compose.release.yml:16`, `docker-compose.yml:24`, `docs/SEARCH_BACKENDS.md:151`, `ops/docker/release/compose.cpu.yml:16`

## `SEARCH_ENABLE_ASR`
- Source: `backend/app/services/configured_search.py:86`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/qwen_runtime_search.py:183`, `docker-compose.cpu.yml:23`, `docker-compose.gpu.yml:24`, `docker-compose.release.yml:20`, `ops/docker/release/compose.cpu.yml:20`, `ops/docker/release/compose.gpu.yml:20`, `scripts/debug_qa.py:13`

## `SEARCH_ENABLE_OCR`
- Source: `backend/app/services/configured_search.py:85`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/qwen_runtime_search.py:182`, `docker-compose.cpu.yml:22`, `docker-compose.gpu.yml:23`, `docker-compose.release.yml:19`, `ops/docker/release/compose.cpu.yml:19`, `ops/docker/release/compose.gpu.yml:19`, `scripts/debug_qa.py:12`

## `SEARCH_ENCODER`
- Source: `backend/app/main.py:111`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docs/SEARCH_BACKENDS.md:151`

## `SIGLIP2_MODEL`
- Source: `.env.example:84`
- Consumer: .env.example
- Default/requirement: `google/siglip2-base-patch16-224`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `SIGLIP_ENABLED`
- Source: `.env.example:83`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `SIGLIP_LONG_TEXT_MODE`
- Source: `.env.example:85`
- Consumer: .env.example
- Default/requirement: `chunk_mean`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:8`

## `SIGLIP_TEXT_CHUNK_STRIDE`
- Source: `.env.example:87`
- Consumer: .env.example
- Default/requirement: `8`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:10`

## `SIGLIP_TEXT_MAX_CHUNKS`
- Source: `.env.example:88`
- Consumer: .env.example
- Default/requirement: `8`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:11`

## `SIGLIP_TEXT_MAX_LENGTH`
- Source: `.env.example:86`
- Consumer: .env.example
- Default/requirement: `64`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:9`

## `TARGET_REVISION`
- Source: `deploy/rollback.sh:21`
- Consumer: Compose/shell interpolation
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/rollback.sh:25`, `deploy/rollback.sh:26`, `deploy/rollback.sh:37`

## `TORCH_EXTRA_INDEX_URL`
- Source: `Dockerfile:10`
- Consumer: Docker ARG
- Default/requirement: `https://download.pytorch.org/whl/cpu`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `TORCH_HOME`
- Source: `.env.example:25`
- Consumer: .env.example
- Default/requirement: `/cache/torch`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `TORCH_INDEX_URL`
- Source: `Dockerfile:9`
- Consumer: Docker ARG
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:33`, `docker-compose.gpu.yml:8`, `docker-compose.gpu.yml:34`

## `TRAKE_COHERENCE_MODE`
- Source: `.env.example:124`
- Consumer: .env.example
- Default/requirement: `diagnostic`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:73`

## `TRAKE_TEMPORAL_REFINE_CACHE_ENABLED`
- Source: `backend/app/core/config.py:58`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:69`

## `TRAKE_TEMPORAL_REFINE_ENABLED`
- Source: `backend/app/core/config.py:52`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/configured_search.py:814`, `backend/app/services/temporal_refiner.py:63`

## `TRAKE_TEMPORAL_REFINE_MAX_FRAMES_PER_REGION`
- Source: `backend/app/core/config.py:57`
- Consumer: Python os.getenv
- Default/requirement: `"50"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:68`

## `TRAKE_TEMPORAL_REFINE_MAX_REGIONS_PER_VIDEO`
- Source: `backend/app/core/config.py:55`
- Consumer: Python os.getenv
- Default/requirement: `"3"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:66`

## `TRAKE_TEMPORAL_REFINE_MAX_TOTAL_REGIONS`
- Source: `backend/app/core/config.py:56`
- Consumer: Python os.getenv
- Default/requirement: `"6"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:67`

## `TRAKE_TEMPORAL_REFINE_SAMPLE_FPS`
- Source: `backend/app/core/config.py:54`
- Consumer: Python os.getenv
- Default/requirement: `"5.0"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:65`

## `TRAKE_TEMPORAL_REFINE_WINDOW_SECONDS`
- Source: `backend/app/core/config.py:53`
- Consumer: Python os.getenv
- Default/requirement: `"2.5"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:64`

## `TRANSFORMERS_CACHE`
- Source: `.env.example:24`
- Consumer: .env.example
- Default/requirement: `/cache/huggingface`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `TRANSFORMERS_OFFLINE`
- Source: `.env.example:128`
- Consumer: .env.example
- Default/requirement: `0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:32`, `docker-compose.gpu.yml:33`, `docker-compose.release.yml:29`, `ops/docker/release/compose.cpu.yml:29`, `ops/docker/release/compose.gpu.yml:29`

## `VIDEOS_DIR`
- Source: `projectctl.py:645`
- Consumer: Python os.getenv
- Default/requirement: `"data/test-videos"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_CACHE_DIR`
- Source: `.env.example:56`
- Consumer: .env.example
- Default/requirement: `data/videos`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/video_source.py:42`, `docker-compose.yml:36`

## `VIDEO_EMBED_BATCH_SIZE`
- Source: `backend/app/config/video_ingest_config.py:96`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_FRAME_FORMAT`
- Source: `backend/app/config/video_ingest_config.py:94`
- Consumer: Python os.getenv
- Default/requirement: `"jpg"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_FRAME_ID_POLICY`
- Source: `backend/app/config/video_ingest_config.py:93`
- Consumer: Python os.getenv
- Default/requirement: `"zero_based"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_INDEX_TYPE`
- Source: `backend/app/config/video_ingest_config.py:99`
- Consumer: Python os.getenv
- Default/requirement: `"flat"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `projectctl.py:746`

## `VIDEO_INGEST_DEVICE`
- Source: `backend/app/config/video_ingest_config.py:97`
- Consumer: Python os.getenv
- Default/requirement: `os.getenv("COMPUTE_DEVICE", "auto"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `projectctl.py:272`

## `VIDEO_INGEST_ENABLED`
- Source: `backend/app/config/video_ingest_config.py:90`
- Consumer: Python os.getenv
- Default/requirement: `"false"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_JPEG_QUALITY`
- Source: `backend/app/config/video_ingest_config.py:95`
- Consumer: Python os.getenv
- Default/requirement: `"90"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_PROCESSED_ROOT`
- Source: `.env.example:21`
- Consumer: .env.example
- Default/requirement: `/data/processed`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:91`, `backend/app/services/configured_search.py:76`, `backend/app/services/qwen_runtime_search.py:177`, `docker-compose.yml:22`, `projectctl.py:99`, `projectctl.py:154`, `projectctl.py:456`

## `VIDEO_RAW_ROOT`
- Source: `backend/app/services/temporal_refiner.py:195`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_RESUME`
- Source: `backend/app/config/video_ingest_config.py:98`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_SAMPLE_INTERVAL_SECONDS`
- Source: `backend/app/config/video_ingest_config.py:92`
- Consumer: Python os.getenv
- Default/requirement: `"1.0"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_SOURCE_DIR`
- Source: `.env.example:52`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/video_source.py:46`, `docker-compose.yml:34`

## `VIDEO_SOURCE_DIR_CONTAINER`
- Source: `.env.example:54`
- Consumer: .env.example
- Default/requirement: `/videos`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.yml:48`

## `VIDEO_SOURCE_DIR_HOST`
- Source: `.env.example:53`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.yml:48`

## `VIDEO_SOURCE_URL_TEMPLATE`
- Source: `.env.example:55`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/video_source.py:51`, `docker-compose.yml:35`

## `VISUAL_BATCH_SIZE`
- Source: `backend/app/runtime/operations.py:38`
- Consumer: Python os.getenv
- Default/requirement: `"auto"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VISUAL_DEDUP_ENABLED`
- Source: `.env.example:66`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:102`, `backend/app/core/config.py:78`

## `VISUAL_DEDUP_THRESHOLD`
- Source: `.env.example:67`
- Consumer: .env.example
- Default/requirement: `0.97`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:83`, `backend/app/core/config.py:79`

## `VISUAL_GLOBAL_SAMPLE_SECONDS`
- Source: `.env.example:65`
- Consumer: .env.example
- Default/requirement: `5.0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:77`, `backend/app/core/config.py:77`

## `VISUAL_SAMPLING_MODE`
- Source: `.env.example:64`
- Consumer: .env.example
- Default/requirement: `sparse_shot`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:100`, `backend/app/core/config.py:76`

## `VISUAL_WEIGHT`
- Source: `scripts/eval_m27.py:8`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references:
