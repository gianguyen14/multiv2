# Command reference

```bash
# Native help and checks
python3 projectctl.py --help
python3 projectctl.py env --check
python3 projectctl.py smoke
python3 projectctl.py status

# Native servers
python3 projectctl.py backend --host 127.0.0.1 --port 8000
python3 run_dev.py

# Search CLI modes
python3 projectctl.py kis "query" --top-k 10
python3 projectctl.py qa "question" --top-k 10
python3 projectctl.py trake 'event one|event two' --top-k 30
python3 projectctl.py image-search /path/query.png --top-k 10

# Docker source-build path
docker build --pull -t aic:local .
docker compose -f docker-compose.yml config
docker compose -f docker-compose.yml up -d

# Image-first path (verify tag and mounts first)
docker compose -f docker-compose.release.yml config
docker compose -f docker-compose.release.yml pull
docker compose -f docker-compose.release.yml up -d
docker compose -f docker-compose.release.yml ps
docker compose -f docker-compose.release.yml logs --tail=100 aic

# Runtime diagnostics
curl -f http://127.0.0.1:8000/health/ready
ss -lntp | grep -E ':3000|:8000'
docker stats
docker top aic-retrieval
free -h
df -h
```

Never run current `projectctl.py ingest` with `/home/hermes/aic/data/aic-db-v1/runtime` as output: it creates SigLIP2-oriented artifacts and the active production DB is Qwen 1024-D.
