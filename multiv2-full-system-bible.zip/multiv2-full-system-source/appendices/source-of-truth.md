# Source-of-truth matrix

| Topic | Authoritative source | Secondary/documented sources |
|---|---|---|
| backend selection | `backend/app/main.py:_build_configured_search` | `.env.example`, docs/SEARCH_BACKENDS.md |
| Qwen query contract | `backend/app/embeddings/qwen3_vl.py` + external model script | docs/ARCHITECTURE.md |
| SigLIP2 ingest | `backend/app/video/ingest.py` | docs/archive/milestones/m15_video_ingestion.md |
| index publication | `backend/app/video/frame_index.py` | docs/DATA_CONTRACT.md |
| active production DB | external `CURRENT` + generation.json | docs/ARCHITECTURE.md |
| API routes | `backend/app/main.py` | docs/API_REFERENCE.md |
| environment | exact os.getenv consumers + Compose | `.env.example`, docs/RUNTIME_CONFIG.md |
| container | `Dockerfile`, docker-entrypoint.sh | DOCKER.md |
| deployment | selected Compose file | deploy scripts/ops guides |
| CI | `.github/workflows/*.yml` | README/docs |
| frontend | `frontend/src/*`, `run_dev.py` | frontend/README.md |
| tests | `tests/` and CI command | pytest.ini |
