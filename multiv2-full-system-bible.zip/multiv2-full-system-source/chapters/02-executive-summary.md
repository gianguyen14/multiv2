# 2. Executive summary

AIC is a Python/FastAPI multimodal video retrieval service for three query modes: Known-Item Search (KIS), Question Answering (QA), and Temporal Retrieval of Actions and Key Events (TRAKE). A vanilla HTML/CSS/JavaScript frontend is served directly by the FastAPI application in production; a standard-library development runner separately serves port 3000 and proxies API requests to a backend on port 8000.

The current production/default online path is Qwen3-VL-Embedding-2B text-query search over an external, read-only Qwen-built 1024-dimensional FAISS `IndexFlatIP` generation. OCR and ASR are precomputed JSON evidence spools. Qwen encodes the query, FAISS recalls visual frame candidates, lexical evidence is fused, and the provider implements QA extraction and ordered TRAKE.

The repository is not Qwen-only. The legacy `ConfiguredSearch` and `SigLIP2Encoder` remain active code. `backend/app/video/ingest.py` constructs SigLIP2 for offline video ingest, and the legacy configured backend owns image search and temporal/refinement paths. Current Qwen search explicitly reports image capability false. A Qwen frame-image ingest contract and production-compatible Qwen image-query path were not verified on current main. The correct state is `CURRENT_QWEN_PRIMARY_VALIDATED`; Qwen-only migration is NOT COMPLETED.

Deployment is available in several overlapping forms: generic local-build Compose, CPU/GPU/release Compose variants, source-build deploy scripts, and image-first Docker Hub operator guides. The repository has no SQL database, object-storage adapter, queue, scheduler, authentication/authorization layer, rate limiting, metrics backend, or repository-native backup service. Persistent DB/model/video/cache resources are expected to be mounted externally.

Major operational risks are unauthenticated API/media exposure, unpinned dependencies, multiple Compose/release workflows, the SigLIP2 ingest/Qwen production-index mismatch, missing historical `eval.*` modules causing full test collection failure, and pending GPU competition validation.
