# 18. CI/CD

`ci.yml` triggers on push and pull request to main plus manual dispatch, grants `contents: read`, cancels superseded runs and uses Ubuntu Python 3.12. It installs ffmpeg/Tesseract language packs, installs `.[dev]`, runs `projectctl.py env --check` and `smoke`, then filtered CPU pytest excluding slow/real-model/network/GPU and selected missing historical modules. A Docker job builds `aic-retrieval:ci` and verifies imports. It does not push an image or deploy.

`defender-for-devops.yml` triggers on push/PR main and a weekly cron, runs Windows Microsoft Security DevOps and uploads SARIF through CodeQL action. It is a security scan, not deployment.

No committed workflow performs Docker Hub login/push, release creation, migration, database deployment or production restart. Image-first publishing was performed operationally outside these workflows and is documented by ops guides.
