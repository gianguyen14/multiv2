# 5. Source-code walkthrough

## Composition root: `backend/app/main.py`

`SearchRequest` defines the public search schema. `_build_configured_search()` selects Qwen or legacy SigLIP2. `create_app()` installs security headers, frontend static routes, health/live/readiness, `/api/search`, image upload routing, frame serving and range-aware video routes. It resolves media source paths through `video_source.py`; it validates upload format/size with Pillow and rejects wildcard CORS when credentials are enabled.

## Qwen provider: `backend/app/services/qwen_runtime_search.py`

`QwenRuntimeSearch` owns the configured processed root, model path, optional OCR/ASR enablement, lazy provider state, bundle, timelines, evidence records and metrics. `_initialize()` loads the active generation, checks encoder backend identity against Qwen names, creates the Qwen encoder and loads evidence. `readiness()` checks CURRENT, model presence, generation identity and positive dimension. `search_single()` encodes one text query, recalls candidates, normalizes visual scores, merges lexical OCR/ASR hits and creates stable sorted rows. `search_trake()` searches each event then enforces one video and strictly increasing source-frame indices. QA adds extractive or optional remote synthesis fields without changing retrieval ordering. `search_image()` intentionally raises an explicit unsupported error.

## Legacy provider: `backend/app/services/configured_search.py`

This is the large historical/compatibility path. It constructs `SigLIP2Encoder`, loads the shared frame index, rejects Qwen encoder metadata, handles OCR/ASR expansion, query refinement, candidate reranking, legacy QA/TRAKE and image search. It remains relevant and is not dead code merely because Qwen is the default.

## Embedding adapters

`qwen3_vl.py` dynamically loads the official script from the external model directory. It uses Qwen's `process()` output, pools/truncates/normalizes and returns NumPy float32. Current main's adapter exposes `encode_query` and `encode_text`, not a verified `encode_image`. `siglip2.py` exposes image/text operations, model caching, device policy and long-text chunking.

## Ingest/index

`projectctl.py` dispatches `ingest` to `command_ingest`; `backend/app/video/ingest.py` discovers video files, builds `VideoIngestConfig`, constructs `SigLIP2Encoder`, runs `VideoIngestionPipeline`, and calls `build_frame_index`. `m15_ingestion_pipeline.py` stages metadata, sequential frame sampling/storage and embeddings with resumable manifests. `frame_index.py` writes staged `frames.faiss`, `mapping.json`, `payloads.json`, `generation.json`, validates hashes/cardinality/identity, renames the generation into `generations/`, then atomically publishes `CURRENT`.

## Text evidence

`m16_text_pipeline.py` fingerprints OCR/ASR settings and source state, validates/resumes per-video caches, extracts OCR from stored frame images, transcribes audio, maps ASR segment endpoints to nearest decoded frame ordinals and persists JSON plus metadata.

## Runtime/support modules

`runtime/device_policy.py` resolves CPU/CUDA policy; `model_cache.py` inventories/prepares models; `video_source.py` resolves local/cache/HTTP sources; `atomic_io.py` provides atomic writes/fsync; retrieval modules contain legacy pipelines, ranking, temporal refinement, distributed abstractions and competition scoring. The test inventory maps the concrete test functions to components.
