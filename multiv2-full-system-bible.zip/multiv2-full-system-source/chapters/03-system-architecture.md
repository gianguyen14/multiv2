# 3. System architecture

## Logical architecture

The main runtime is a single FastAPI application. `backend/app/main.py:create_app()` creates routes, middleware and a configured search provider. Backend selection reads `SEARCH_BACKEND`, then legacy `SEARCH_ENCODER`, then defaults to `qwen3_vl`. Qwen aliases are routed to `QwenRuntimeSearch`; exact `siglip2` routes to `ConfiguredSearch`; unknown values raise at startup.

## Process model

Docker starts exactly one Uvicorn worker (`--workers 1`) on container port 8000. This avoids duplicating the model in multiple worker processes. Generic Compose also has an optional `aic-cli` tools profile, but it is not part of the service process. `run_dev.py` starts a backend child process plus one threaded standard-library frontend server, both on loopback by default.

## Request lifecycle

1. Client calls static UI, health or API route.
2. FastAPI middleware adds `X-Content-Type-Options`, `X-Frame-Options` and `Referrer-Policy`. CORS is explicit-origin with credentials enabled.
3. Pydantic validates `/api/search` body: query length, query type, events and top_k bounds.
4. Search handler calls the selected provider. Qwen lazily loads the local official model wrapper, validates the current generation, encodes text and searches FAISS.
5. OCR/ASR rows are loaded into memory and scored lexically. Results receive deterministic score fusion, evidence and mode-specific processing.
6. Video/media routes resolve local or lazy URL sources and support byte ranges.

## Trust boundaries

- Browser/client to unauthenticated HTTP API: untrusted input and potentially public media exposure.
- Application to external read-only DB/model/video mounts: filesystem boundary; model and DB should be read-only.
- Application to optional remote QA URL/video URL: outbound network boundary; URL and egress must be controlled.
- GitHub/Docker Hub/Hugging Face: supply-chain and availability boundaries.

## Architecture diagrams

See `architecture/overall.mmd`, `runtime.mmd`, `request-lifecycle.mmd`, `search-pipeline.mmd`, `indexing-pipeline.mmd`, `docker.mmd`, `deployment.mmd`, `cicd.mmd`, `data-flow.mmd` and `rollback.mmd`. Each diagram describes only components evidenced in source/config.
