# 11. Frontend

`frontend/src/index.html` is the application shell. `frontend/src/scripts/api.js` handles API requests; `app.js` owns UI state, query controls, rendering and result interactions; `shortcuts.js` owns keyboard shortcuts; `styles/main.css` provides visual layout. The frontend is vanilla HTML/CSS/ES6 and has no Node package manifest or build step.

Production FastAPI serves `/`, `/styles/{filename}` and `/scripts/{filename}` directly. Development `run_dev.py` serves the directory on loopback 3000 and proxies `/api/*` to backend loopback 8000, forwarding non-hop-by-hop headers and bounded request timeouts. Relative API URLs avoid standard same-origin CORS in the combined app.

UI features evidenced by source/docs include KIS/QA/TRAKE controls, result rendering, OCR/ASR evidence, raw video playback with range requests, frame/media links, image upload route handling and keyboard shortcuts. The backend remains authoritative for validation and AI; frontend does not load Qwen/SigLIP models.
