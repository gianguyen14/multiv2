# 17. Defensive security review

| ID | Severity | Evidence | Impact | Recommendation | Confidence |
|---|---|---|---|---|---|
| SEC-01 | High | `main.py` routes have no auth middleware | Any network-reachable client can search/read media | Put behind VPN/authenticated reverse proxy/firewall before LAN/public exposure | High |
| SEC-02 | Medium | CORS `allow_credentials=True`, wildcard headers, explicit origin list | Browser trust boundary depends on correct origins | Keep exact origins; do not use `*`; pair with auth | High |
| SEC-03 | Medium | `DEBUG_API_ERRORS` can include exception type/text | Paths/config details may leak | false in production; sanitize logs/access | High |
| SEC-04 | Medium | `video_source.py` supports HTTP URL templates/lazy downloads | Operator-controlled URLs can create SSRF/egress risk | allowlist hosts/schemes, restrict egress, validate IDs | Medium |
| SEC-05 | Medium | `QA_ANSWER_API_KEY` sent to external OpenAI-compatible endpoint | Secret and evidence leave host if enabled | extractive default; restrict endpoint and rotate key | High |
| SEC-06 | Medium | requirements/pyproject versions broadly unconstrained | Dependency drift/supply-chain reproducibility risk | lock/hash production dependencies and scan images | High |
| SEC-07 | Medium | no rate limiting/auth quotas | expensive model queries can exhaust CPU/RAM | add reverse-proxy/application limits | High |
| SEC-08 | Low | container runs non-root but cache is writable | cache mount ownership/data integrity risk | keep DB/model/videos ro; scope cache permissions | High |
| SEC-09 | Low | Docker base/dependencies not digest locked | build reproducibility risk | pin base digest and dependency hashes | High |

Input validation is comparatively strong: image size/type checks, Pydantic bounds, filename/path resolution and symlink escape tests exist. No SQL database, SQL queries, JWT/OAuth, session or password handling exists in tracked application source.
