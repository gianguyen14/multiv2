# 8. Data and index contract

## Active production DB v1

The external runtime inspected in prior validation contains `index/CURRENT` pointing to `gen-A-b531063ff8ce48e1b0d62739fb290c23`. Its generation metadata records Qwen3-VL-Embedding-2B, backend `qwen3_vl_embedding_2b`, revision `9f2f7e710d6d81056aa5c0a4f04764fec6bb7bda`, 1024 dimensions, L2 normalization, `IndexFlatIP`, 47,430 vectors and 873 videos at a coarse 10-second cadence. The verified cardinality invariant is FAISS ntotal = mapping count = payload count = 47,430.

Expected layout:

```text
<processed-root>/
  index/CURRENT
  index/generations/<generation-id>/
    frames.faiss
    mapping.json
    payloads.json
    generation.json
  <video-id>/metadata.json, frames.json, embeddings.npy, manifest.json
  <video-id>/ocr.json, ocr_meta.json, asr.json, asr_meta.json
```

The active serving container mounts DB v1 read-only. The service does not ingest, rewrite or publish generations online.

## Identity

Frame UID is canonical `{video_id}:{source_frame_index_zero_based:09d}`. The authoritative frame index is the sequential PyAV display-order ordinal. Timestamp is retained as observed PTS/time-base-derived seconds. Timestamp multiplied by FPS is not authoritative.

## Generation publication

`frame_index.validate_generation()` requires four files, schema version 1, path/generation identity, declared SHA-256 artifacts, valid FAISS/mapping, payload identity equality, vector count and canonical UID format. `build_frame_index()` stages under `.staging`, validates before rename, fsyncs the generations directory, and atomically writes `CURRENT`. Previous generations remain available for rollback.

## DB v2

DB v2/dense artifacts are experimental branches/artifacts and are not the active production source. The current-main serving code uses `VIDEO_PROCESSED_ROOT/index` and Qwen DB v1 metadata. Do not substitute DB v2 without a separately validated runtime contract.
