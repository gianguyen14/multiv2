# 20. Git history and architecture evolution

Relevant evolution:

- `852b938`/`26c9848`: introduced deterministic SigLIP2 encoder.
- `6e546c9`: production Docker deployment.
- `12be42f`, `023f05f`, `571c2bc`: visual encoder/index identity work and Qwen/SigLIP rollback architecture.
- `e5454af`: Qwen packed-DB runtime adapter.
- `82a5e01`: consolidated Qwen3-VL production search stack.
- `73fc6fe`: Qwen image-search experimental branch, not merged into main.
- `5e20013`, `1b87c4f`, `bd4d049`: video preview and per-video OCR/ASR evidence.
- `c39bea5`, `0565800`: optional remote QA synthesis and bounded calls.
- `8337437`, `4c4c9d8`, `ffb5c45`: CPU/GPU Docker finals configuration.
- `5b80413`, `1813223`: added/installed torchvision with torch to make Qwen query imports work in CPU image.
- `16386cb`: made Docker Hub deployment documentation image-first and added release compose examples.

`1813223` changed only Dockerfile dependency installation; it installs torch and torchvision together and excludes both from the general dependency pass. `16386cb` changed only operational docs/examples and release compose files; it did not change application runtime or index semantics. Later `245e508` on the migration branch adds only the documentation ZIP/checksum.
