# 15. Testing

Tracked tests: 96 files including unit, integration, support and one video fixture. `inventories/tests.csv` records test groups and model/data/GPU/Docker requirements. The suite covers frame identity/sampling/deduplication, ingest resume/publication, OCR/ASR, Qwen runtime guards/search/QA/TRAKE, SigLIP2, image API contracts, frontend/media routes, distributed legacy retrieval, device policy, model cache, query refiner, ranking and operational CLI.

## Evidence timeline

1. A first full `python -m pytest -q` attempt with the generic `python` command failed because no `python` executable was on PATH; this was an invocation/environment issue.
2. The corrected `python3 -m pytest -q` attempt reached collection and failed with five exact missing imports: `eval.m12_hard_negative_dataset`, `eval.m13_5_corpus`, `eval.m14_9router_quality`, `eval.m13_5_corpus` (second test) and `eval.m22_end_to_end_benchmark`.
3. `python3 projectctl.py test` invokes the same full pytest command and has the same baseline collection problem.
4. `python3 projectctl.py env --check` independently reported missing `faster-whisper` and host Tesseract in this audit environment.

These are baseline/environment limitations, not migration regressions: no migration source was applied. CI intentionally filters/excludes historical missing modules, slow/real-model/network/GPU tests and performs a narrower CPU gate.

The test suite has strong contract coverage but lacks a clean full collection on this checkout. No claim of all tests passing is made.
