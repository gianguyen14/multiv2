# 4. Repository structure

The tracked tree contains 409 files. The complete tree is `metadata/repository-tree.txt`; descriptive per-file rows are in `inventories/file-inventory.csv`; important-file narrative records are in `appendices/file-reference.md`.

## Top-level ownership

| Area | Role |
|---|---|
| `backend/` | Python application, retrieval, model adapters, ingestion, validation and runtime policy |
| `frontend/` | Vanilla static UI assets and frontend README |
| `tests/` | unit/integration/smoke tests and one committed video fixture |
| `docs/` | API, architecture, contracts, deployment, runtime config, archived milestones/ADRs |
| `scripts/`, `eval/` | query, artifact, benchmark and evaluation utilities |
| `ops/`, `deploy/` | Docker guides/scripts, finals qualification/smoke and install/update/rollback |
| `.github/workflows/` | CPU CI/Docker gate and Microsoft Security DevOps workflow |
| root Docker/Compose files | image build and deployment profiles |
| `artifacts/` | committed experiment/evaluation artifacts, not application source |
| `data/` | tracked placeholders; production DB/model are external |

`artifacts/` is source-controlled research output and may be large or stale; `.dockerignore` excludes it from release build context. `node_modules`, `.runtime`, caches and external model/video directories are not part of tracked source.
