# 13. Hardware runtime

## CPU development/audit environment

Observed host: Intel Core i3-3217U 1.80GHz, 2 physical cores/4 logical CPUs, 9.0 GiB RAM, no NVIDIA GPU, AVX/F16C but no AVX2/AVX-512 BF16 flags observed. Native Qwen runtime loads on CPU and returns HTTP 200 KIS/QA. It is a functional correctness environment, not a competition performance target.

Current Qwen adapter defaults to bfloat16 in `Qwen3VlLocalEmbedder`; the official model script selects device based on CUDA availability. Actual prior CPU runtime validation used CPU torch and was healthy. Runtime thread policy reports two torch threads in the validated serving environment.

## Measured CPU sample

Five fixed API requests previously recorded: 55.4602s, 30.4724s, 23.8827s, 26.1936s, 22.7434s. Mean 31.7505s, median/p50 26.1936s, min 22.7434s, max 55.4602s, sample standard deviation 13.3630s. With linear percentile interpolation `(n-1)p`, p90 = 45.4646s and p95 = 50.4626s. This is an exploratory n=5 sample, not a reliable production percentile estimate. A point RSS observation was about 3.34 GiB; peak RSS was not measured.

## GPU target

GPU Docker supplies a CUDA torch index and Compose reserves NVIDIA devices. Expected invariant is same Qwen model/checkpoint, instruction, tokenization/max length, 1024-D MRL, normalization, FAISS DB and ranking pipeline. No GPU exists in this audit environment; status is `PENDING_GPU_VALIDATION`, not failed. Competition validation must measure device placement/no CPU fallback, model load, first/warm latency, P50/P95, throughput, utilization, peak VRAM, KIS/QA/TRAKE and CPU/GPU top-k consistency.
