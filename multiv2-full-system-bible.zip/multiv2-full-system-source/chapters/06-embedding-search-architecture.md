# 6. Embedding and search architecture

## Qwen production/default

- Model family: `Qwen/Qwen3-VL-Embedding-2B`.
- Model loading: `Qwen3VLEmbedder` dynamically loaded from `<QWEN3_VL_MODEL_DIR>/scripts/qwen3_vl_embedding.py`; weights remain external.
- Instruction: `Retrieve the video frame that best matches the described visual scene.`
- Query max length in current adapter: 256 by constructor default.
- Pooling: official script pools last attended hidden state.
- MRL: output is sliced to active index dimension; production DB is 1024.
- Normalization: float32 L2 after truncation; FAISS inner product corresponds to cosine for unit vectors.
- Runtime device: official script selects CUDA if `torch.cuda.is_available()`; current CPU audit uses CPU. The Docker GPU profile installs a CUDA torch wheel and requests NVIDIA devices, but no GPU validation was possible.
- Index guard: Qwen provider refuses active generation metadata whose backend is not one of the Qwen backend names.

## SigLIP2

- Code: `backend/app/embeddings/siglip2.py`; model default `google/siglip2-base-patch16-224`; legacy dimension is 768 in the source/test/docs context.
- Search role: `ConfiguredSearch` explicitly constructs it and owns image search, legacy query refinement/reranking/temporal behavior.
- Ingest role: `backend/app/video/ingest.py` constructs it for `projectctl.py ingest`.
- Test role: many tests cover real or stub SigLIP2 behavior, index wrapper and long-text chunking.
- Compatibility role: `ConfiguredSearch._guard_index_backend()` refuses a Qwen-built index, preventing silent wrong-space queries.
- Removal status: blocked. Current Qwen image query is explicitly unsupported and no verified Qwen frame-image ingest contract exists on main.

## Embedding-space rule

A 1024-D shape alone is insufficient to establish semantic compatibility. The generation metadata encoder identity, model revision, instruction, preprocessing, pooling, normalization and sampling provenance must match. Never run `projectctl ingest` against the active Qwen production DB.
