# 10. Search modes

## KIS

`POST /api/search` with `query_type=kis`. Qwen text embedding is the visual retrieval signal; OCR/ASR lexical rows can expand candidates and contribute fixed fusion weights. Response rows identify exact video/frame UID and timestamp. Current production Qwen path is text-to-indexed-frame, not image query.

## QA

Uses the same retrieval path then adds extractive evidence-derived answers by default. `QA_ANSWER_BACKEND=remote_llm` can call an OpenAI-compatible endpoint sequentially for bounded top-N rows, but it is optional/experimental and requires URL/key. Missing remote configuration/failure falls back to extractive.

## TRAKE

`events` is an ordered list. Qwen provider searches each event, groups candidates by video and selects a sequence whose source frame indices strictly increase. No valid single-video sequence returns 400. This is a hard ordering contract rather than a generic top-k list. Legacy provider also has temporal refinement controls.

## Image search

The route exists and legacy `ConfiguredSearch`/SigLIP2 owns it. Current Qwen status reports `image=false` and `QwenRuntimeSearch.search_image()` raises a clear runtime error. Qwen image migration is therefore UNVERIFIED and SigLIP2 cannot be deleted safely.
