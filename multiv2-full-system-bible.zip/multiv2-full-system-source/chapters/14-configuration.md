# 14. Configuration

Configuration sources are `backend/app/core/config.py`, runtime modules using `os.getenv`, `.env.example`, Dockerfile ENV/ARG, Compose interpolation/environment blocks, workflows and shell scripts. The exact extracted environment table is `inventories/environment-variables.csv`; narrative explanations are `appendices/environment-reference.md`.

Important groups:

- Backend/storage: `SEARCH_BACKEND`, legacy `SEARCH_ENCODER`, `VIDEO_PROCESSED_ROOT`, `MODEL_CACHE_DIR`, `QWEN3_VL_MODEL_DIR`, `QWEN_MODEL_DIR`.
- Evidence: `SEARCH_ENABLE_OCR`, `SEARCH_ENABLE_ASR`, OCR backend/fallback/device/confidence variables, `FASTER_WHISPER_MODEL`.
- QA: `QA_ANSWER_BACKEND`, URL/model/API key, timeout, evidence/token/remote-top-N limits.
- Query/ranking: query refiner, RERANKER, DEBUG_QUERY_PLAN, TRAKE settings, visual sampling/refinement.
- Media: `VIDEO_SOURCE_DIR`, URL template, cache, host/container mount variables.
- Runtime/security: `ALLOWED_ORIGINS`, `DEBUG_API_ERRORS`, offline flags, AIC bind/port, torch/cache variables.

Defaults vary between generic Compose, release Compose and `.env.example`; operators must choose one deployment profile and inspect rendered config. Secrets are runtime-only and must not be placed in images, committed env examples or logs.
