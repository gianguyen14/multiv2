# 12. Docker and Compose

## Dockerfile

`Dockerfile` uses `python:3.12-slim`, build argument `TORCH_INDEX_URL`, CPU torch index fallback, apt packages build-essential/gcc/g++/git/ffmpeg/tesseract language packs/libgl/curl, non-root `appuser` UID/GID 1000, `/app` workdir and writable cache/data/log directories. It copies dependency manifests first, installs torch/torchvision separately, installs remaining requirements, copies entrypoint/backend/frontend/projectctl, chowns `/app`, exposes 3000/8000, and executes one Uvicorn worker on 0.0.0.0:8000.

`.dockerignore` excludes `.git`, env/credentials, data/models/artifacts/logs/cache/tests/docs/scripts, research files, archives and frontend dependency directories. This keeps external production data out of image context.

## Compose differences

- `docker-compose.yml`: local build `aic:latest`, one `aic` service plus tools profile, generic writable host mounts, loopback default and liveness healthcheck.
- `docker-compose.cpu.yml`: image/build CPU profile, Qwen defaults, external read-only DB/model/video mounts, writable video cache, host 3000 and 8000 both mapped to container 8000, readiness healthcheck, json-file rotation.
- `docker-compose.gpu.yml`: same single service with CUDA torch index, CUDA env, NVIDIA device reservation and GPU OCR settings.
- `docker-compose.cuda.yml`: fragment with `backend` and `worker` services/devices; it does not match the single-service release topology and must not be treated as a complete standalone file.
- `docker-compose.release.yml`: image-first single service with production mount defaults and Qwen/extractive defaults.
- `ops/docker/release/compose.*`: operator-facing image-first release compose variants.

Compose plugin runtime validation was not possible on this host (`docker compose` unavailable). YAML and source were inspected; treat command execution as UNVERIFIED.
