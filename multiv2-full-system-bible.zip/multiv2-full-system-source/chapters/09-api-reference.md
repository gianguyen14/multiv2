# 9. Full API reference

Authentication for all routes: NONE in application code. Put the service behind network/auth controls before exposure.

## GET `/`

Source/handler: `backend/app/main.py:create_app().index`. Purpose: returns `frontend/src/index.html`. Parameters/body: none. Success: HTTP 200 file response. Errors: filesystem/server errors can produce 500. Dependencies: frontend source path in repository. Side effects: none.

## GET `/styles/{filename}`

Handler: `style` → `_frontend_asset("styles", filename)`. Parameters: filename must not contain slash/backslash/`..`; resolved file must exist below frontend root. Success: 200 CSS file. Invalid/missing assets: 404.

## GET `/scripts/{filename}`

Same safety and response contract as styles, serving `frontend/src/scripts`.

## GET `/health` and `/health/live`

Handler: `health`. Request body: none. Success JSON includes `status=ok`, `search_configured`, `processed_root`, provider `search` status and `compute` runtime summary. No model inference is required by the route itself, but provider status may be initialized depending lifecycle. Errors: normal server errors only.

## GET `/health/ready`

Handler: `ready`. Request body: none. Success 200 adds `status=ready`, `search_readiness`. Qwen readiness checks configured root, CURRENT, model weights, generation metadata/backend and positive dimension. If unavailable, HTTP 503 with `detail` containing status/reason/payload. This is the deployment healthcheck endpoint in release Compose.

## POST `/api/search`

Handler: `search`. Content-Type: `application/json`. Pydantic `SearchRequest`:

```json
{"query":"string, max 2000","query_type":"kis|qa|trake","events":["string, max 20"],"top_k":100,"temporal_refine":true,"query_refine":true,"rerank":true,"debug_query_plan":false}
```

`events` entries must be non-empty and <=2000 characters. `top_k` is 1..1000. Empty query with no events: 400. Pydantic violations: 422.

KIS/QA require non-empty query. Qwen returns ranked rows with rank, video_id, frame_id, source_frame_index_zero_based, frame_uid, timestamp_seconds, score, visual_score, OCR/ASR scores/evidence and video URL/evidence fields. QA adds answer, answer_backend/model/status; extractive is default. TRAKE requires ordered events and returns one row with frame_ids/events when a single video satisfies strict increasing frame order. Impossible TRAKE: 400. Unsupported mode: 400. Missing/unreadable model/index: 503 with sanitized error unless `DEBUG_API_ERRORS=true`; unexpected exceptions can be 500.

Side effects: lazy in-memory model/index/evidence initialization; no DB writes. Runtime dependencies: Qwen model, current generation, OCR/ASR spools.

Example:

```bash
curl -sS -H 'Content-Type: application/json' --data '{"query":"một người phụ nữ đang nấu ăn","query_type":"kis","top_k":3}' http://127.0.0.1:8000/api/search
```

## POST `/api/search/image`

Handler validates content type (`image/jpeg`, `image/png`, `image/webp` or multipart/form-data), max body 15 MiB, multipart file field `file`, and decodes with Pillow. Query parameter `top_k` is 1..1000; `raw` disables deduplication for providers that support it. 415 invalid content type, 413 oversized, 400 empty/corrupt/invalid multipart, 422 invalid query parameters, 503 unconfigured/unsupported/provider failure. The current Qwen provider explicitly raises unsupported image search; legacy SigLIP2 provider supports image search.

## GET/HEAD `/api/video/{video_id}`

Handler resolves local/cache/HTTP source via `video_source.resolve_video_path`. Video ID validation is performed by source resolver. No request body. Without Range: 200 `video/mp4`, Content-Length and Accept-Ranges. With one `Range: bytes=start-end` or suffix range: 206 with Content-Range and Content-Length. Multiple/invalid ranges: 416. Missing video: 404; source errors: 503. HEAD follows the same route. Cache writes can occur for lazy remote sources; local serving is read-only.

## GET `/api/frames/{video_id}/{filename}`

Filename must use jpg/webp/png, have no traversal separators, resolve under `<media_root>/<video_id>/frames` and be a file. Success: 200 FileResponse with public max-age cache header. Invalid/missing/symlink escape: 404.
