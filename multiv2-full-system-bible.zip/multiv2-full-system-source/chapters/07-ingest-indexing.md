# 7. Offline ingest and indexing

## Actual current command

`python3 projectctl.py ingest <path> ...` eventually calls `backend/app/video/ingest.py:main()`. It defaults to output `data/processed/videos`, sample interval 1.0, batch size 8, CPU device and resume enabled. It constructs `SigLIP2Encoder` at line 87. This is not a Qwen production ingest path.

## Current pipeline

`discover_videos()` accepts mp4/mov/mkv/webm/avi and sorts directory paths. Duplicate stems are rejected. `VideoIngestionPipeline` inspects video metadata, sequentially decodes frames through PyAV, creates authoritative display-order frame records, samples according to `VideoIngestConfig`, writes frame artifacts/manifests atomically, embeds with the supplied SigLIP2 encoder and resumes from valid stage fingerprints.

`build_frame_index()` concatenates completed per-video embeddings, creates `FaissSigLIPIndex`, persists FAISS/mapping, writes payloads and generation metadata into `.staging/gen-*`, validates checksums and canonical identities, moves the generation into `generations/`, and atomically writes `CURRENT`.

## OCR/ASR

M16 operates after frame artifacts. OCR reads stored frame images through the selected backend and saves per-video `ocr.json` plus `ocr_meta.json`. ASR transcribes the source video, maps segment start/end timestamps to nearest sequential decoded frame ordinals and saves `asr.json` plus `asr_meta.json`. Resume is fingerprint-based and corrupt/changed caches are invalidated.

## Compatibility hazard

The active production DB v1 is Qwen 1024-D, while current source ingest constructs SigLIP2. The shared index schema can hold either identity, so metadata guards are essential. Qwen runtime rejects non-Qwen identity; legacy runtime rejects Qwen identity. However, there is no explicit `ingest-qwen` command and no current-main proof that the historical production Qwen frame vectors can be reproduced. The safe operational rule is: do not run current `ingest` with production output root.
