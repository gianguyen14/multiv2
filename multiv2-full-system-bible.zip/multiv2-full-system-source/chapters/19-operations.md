# 19. Operations and release model

The repository has two release axes that must not be conflated:

- `aic-db-v1` / `aic-db-v2`: data/index generations/releases; DB compatibility is determined by encoder metadata/dimension/normalization and external artifacts.
- application Docker images: `gianguyen14/aic-retrieval:<tag>`; deployment pulls image and mounts external resources.
- documentation/audit artifact releases: independent GitHub assets or branch files; they do not change runtime.

Production image-first flow is GitHub source/build validation → Docker Hub → production host `docker compose pull` → `up -d` → readiness/KIS/QA/TRAKE/media smoke. Source-build deploy scripts remain in repo and have different behavior. Keep immutable image tag, external model/DB paths and CORS/env backup together.

The branch currently also contains the documentation artifact commit; it is not a source migration. `main` remains at the requested source baseline in the audit history.
