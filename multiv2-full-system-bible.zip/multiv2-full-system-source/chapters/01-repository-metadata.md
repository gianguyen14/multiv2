# 1. Repository metadata and audit boundary

| Field | Verified value |
|---|---|
| Repository | `gianguyen14/multiv2` |
| Remote | `git@github.com:gianguyen14/multiv2.git` |
| Default branch | `main` |
| Requested baseline | `16386cbccf207977fa408dd2c8db614642583d3c` |
| Actual HEAD | `245e50860c800de1e33fbfc8e9a846c82525e7c0` |
| Audit branch | `migration/qwen-only-search` |
| Audit timestamp | `2026-09-19T10:31:31Z` UTC |
| Dirty tree | YES; 23 untracked items |
| Tracked files | 409 |
| Git | 2.47.3 |
| Python | 3.13.5 |
| OS | Debian GNU/Linux 13 (trixie) |
| CPU | Intel Core i3-3217U @ 1.80GHz |
| RAM | 9.0 GiB |
| GPU | none detected |
| Docker | 26.1.5 |
| Docker Compose plugin | not available in audit environment |

The actual HEAD differs from the requested baseline because commit `245e50860c800de1e33fbfc8e9a846c82525e7c0` was later created to add the documentation ZIP and checksum to the migration branch. `git diff 16386cbccf207977fa408dd2c8db614642583d3c..HEAD` contains only those two artifact files; application source is unchanged. The current working tree additionally contains untracked experiment/rescue files and the earlier documentation directory; these are explicitly excluded from the tracked-source audit.

## Status vocabulary

- VERIFIED: observed directly in tracked source, configuration, Git metadata, or a live local HTTP/runtime check.
- DERIVED: calculated from verified evidence.
- DOCUMENTED: stated by repository docs but not independently exercised.
- UNVERIFIED: not established; not used as a success claim.
- NOT PRESENT: no implementation found in the audited tracked tree.
