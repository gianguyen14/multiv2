# 16. Observability

Health: `/health` and `/health/live` report status, provider configuration/status and compute summary; `/health/ready` validates model/index readiness and returns 503 detail when not ready. Qwen provider records last query metrics including backend, generation and total query milliseconds, optionally exposed through debug query plan response.

Logging uses Python/Uvicorn log output. `main.py` logs search/video/image exceptions; `DEBUG_API_ERRORS` controls raw exception detail in selected 503 messages. Docker release Compose uses json-file logs with 10 MiB max size and 3 files.

No Prometheus metrics route, OpenTelemetry tracing, centralized log shipper, alerting integration, external error tracker or GPU metrics collector is present. Operators must use `docker logs`, `docker stats`, `docker top`, `ps`, `free`, `df`, `ss`, health endpoints and application response timings.
