# FULL SYSTEM BIBLE — multiv2

This is the standalone source documentation package. It was generated from tracked source at actual audit commit 245e50860c800de1e33fbfc8e9a846c82525e7c0. The audit state is `CURRENT_QWEN_PRIMARY_VALIDATED`; Qwen-only migration is NOT COMPLETED.

# 1. Repository metadata and audit boundary

| Field | Verified value |
|---|---|
| Repository | `gianguyen14/multiv2` |
| Remote | `git@github.com:gianguyen14/multiv2.git` |
| Default branch | `main` |
| Requested baseline | `16386cbccf207977fa408dd2c8db614642583d3c` |
| Actual HEAD | `245e50860c800de1e33fbfc8e9a846c82525e7c0` |
| Audit branch | `migration/qwen-only-search` |
| Audit timestamp | `2026-09-19T10:31:31Z` UTC |
| Dirty tree | YES; 23 untracked items |
| Tracked files | 409 |
| Git | 2.47.3 |
| Python | 3.13.5 |
| OS | Debian GNU/Linux 13 (trixie) |
| CPU | Intel Core i3-3217U @ 1.80GHz |
| RAM | 9.0 GiB |
| GPU | none detected |
| Docker | 26.1.5 |
| Docker Compose plugin | not available in audit environment |

The actual HEAD differs from the requested baseline because commit `245e50860c800de1e33fbfc8e9a846c82525e7c0` was later created to add the documentation ZIP and checksum to the migration branch. `git diff 16386cbccf207977fa408dd2c8db614642583d3c..HEAD` contains only those two artifact files; application source is unchanged. The current working tree additionally contains untracked experiment/rescue files and the earlier documentation directory; these are explicitly excluded from the tracked-source audit.

## Status vocabulary

- VERIFIED: observed directly in tracked source, configuration, Git metadata, or a live local HTTP/runtime check.
- DERIVED: calculated from verified evidence.
- DOCUMENTED: stated by repository docs but not independently exercised.
- UNVERIFIED: not established; not used as a success claim.
- NOT PRESENT: no implementation found in the audited tracked tree.

# 2. Executive summary

AIC is a Python/FastAPI multimodal video retrieval service for three query modes: Known-Item Search (KIS), Question Answering (QA), and Temporal Retrieval of Actions and Key Events (TRAKE). A vanilla HTML/CSS/JavaScript frontend is served directly by the FastAPI application in production; a standard-library development runner separately serves port 3000 and proxies API requests to a backend on port 8000.

The current production/default online path is Qwen3-VL-Embedding-2B text-query search over an external, read-only Qwen-built 1024-dimensional FAISS `IndexFlatIP` generation. OCR and ASR are precomputed JSON evidence spools. Qwen encodes the query, FAISS recalls visual frame candidates, lexical evidence is fused, and the provider implements QA extraction and ordered TRAKE.

The repository is not Qwen-only. The legacy `ConfiguredSearch` and `SigLIP2Encoder` remain active code. `backend/app/video/ingest.py` constructs SigLIP2 for offline video ingest, and the legacy configured backend owns image search and temporal/refinement paths. Current Qwen search explicitly reports image capability false. A Qwen frame-image ingest contract and production-compatible Qwen image-query path were not verified on current main. The correct state is `CURRENT_QWEN_PRIMARY_VALIDATED`; Qwen-only migration is NOT COMPLETED.

Deployment is available in several overlapping forms: generic local-build Compose, CPU/GPU/release Compose variants, source-build deploy scripts, and image-first Docker Hub operator guides. The repository has no SQL database, object-storage adapter, queue, scheduler, authentication/authorization layer, rate limiting, metrics backend, or repository-native backup service. Persistent DB/model/video/cache resources are expected to be mounted externally.

Major operational risks are unauthenticated API/media exposure, unpinned dependencies, multiple Compose/release workflows, the SigLIP2 ingest/Qwen production-index mismatch, missing historical `eval.*` modules causing full test collection failure, and pending GPU competition validation.

# 3. System architecture

## Logical architecture

The main runtime is a single FastAPI application. `backend/app/main.py:create_app()` creates routes, middleware and a configured search provider. Backend selection reads `SEARCH_BACKEND`, then legacy `SEARCH_ENCODER`, then defaults to `qwen3_vl`. Qwen aliases are routed to `QwenRuntimeSearch`; exact `siglip2` routes to `ConfiguredSearch`; unknown values raise at startup.

## Process model

Docker starts exactly one Uvicorn worker (`--workers 1`) on container port 8000. This avoids duplicating the model in multiple worker processes. Generic Compose also has an optional `aic-cli` tools profile, but it is not part of the service process. `run_dev.py` starts a backend child process plus one threaded standard-library frontend server, both on loopback by default.

## Request lifecycle

1. Client calls static UI, health or API route.
2. FastAPI middleware adds `X-Content-Type-Options`, `X-Frame-Options` and `Referrer-Policy`. CORS is explicit-origin with credentials enabled.
3. Pydantic validates `/api/search` body: query length, query type, events and top_k bounds.
4. Search handler calls the selected provider. Qwen lazily loads the local official model wrapper, validates the current generation, encodes text and searches FAISS.
5. OCR/ASR rows are loaded into memory and scored lexically. Results receive deterministic score fusion, evidence and mode-specific processing.
6. Video/media routes resolve local or lazy URL sources and support byte ranges.

## Trust boundaries

- Browser/client to unauthenticated HTTP API: untrusted input and potentially public media exposure.
- Application to external read-only DB/model/video mounts: filesystem boundary; model and DB should be read-only.
- Application to optional remote QA URL/video URL: outbound network boundary; URL and egress must be controlled.
- GitHub/Docker Hub/Hugging Face: supply-chain and availability boundaries.

## Architecture diagrams

See `architecture/overall.mmd`, `runtime.mmd`, `request-lifecycle.mmd`, `search-pipeline.mmd`, `indexing-pipeline.mmd`, `docker.mmd`, `deployment.mmd`, `cicd.mmd`, `data-flow.mmd` and `rollback.mmd`. Each diagram describes only components evidenced in source/config.

# 4. Repository structure

The tracked tree contains 409 files. The complete tree is `metadata/repository-tree.txt`; descriptive per-file rows are in `inventories/file-inventory.csv`; important-file narrative records are in `appendices/file-reference.md`.

## Top-level ownership

| Area | Role |
|---|---|
| `backend/` | Python application, retrieval, model adapters, ingestion, validation and runtime policy |
| `frontend/` | Vanilla static UI assets and frontend README |
| `tests/` | unit/integration/smoke tests and one committed video fixture |
| `docs/` | API, architecture, contracts, deployment, runtime config, archived milestones/ADRs |
| `scripts/`, `eval/` | query, artifact, benchmark and evaluation utilities |
| `ops/`, `deploy/` | Docker guides/scripts, finals qualification/smoke and install/update/rollback |
| `.github/workflows/` | CPU CI/Docker gate and Microsoft Security DevOps workflow |
| root Docker/Compose files | image build and deployment profiles |
| `artifacts/` | committed experiment/evaluation artifacts, not application source |
| `data/` | tracked placeholders; production DB/model are external |

`artifacts/` is source-controlled research output and may be large or stale; `.dockerignore` excludes it from release build context. `node_modules`, `.runtime`, caches and external model/video directories are not part of tracked source.

# 5. Source-code walkthrough

## Composition root: `backend/app/main.py`

`SearchRequest` defines the public search schema. `_build_configured_search()` selects Qwen or legacy SigLIP2. `create_app()` installs security headers, frontend static routes, health/live/readiness, `/api/search`, image upload routing, frame serving and range-aware video routes. It resolves media source paths through `video_source.py`; it validates upload format/size with Pillow and rejects wildcard CORS when credentials are enabled.

## Qwen provider: `backend/app/services/qwen_runtime_search.py`

`QwenRuntimeSearch` owns the configured processed root, model path, optional OCR/ASR enablement, lazy provider state, bundle, timelines, evidence records and metrics. `_initialize()` loads the active generation, checks encoder backend identity against Qwen names, creates the Qwen encoder and loads evidence. `readiness()` checks CURRENT, model presence, generation identity and positive dimension. `search_single()` encodes one text query, recalls candidates, normalizes visual scores, merges lexical OCR/ASR hits and creates stable sorted rows. `search_trake()` searches each event then enforces one video and strictly increasing source-frame indices. QA adds extractive or optional remote synthesis fields without changing retrieval ordering. `search_image()` intentionally raises an explicit unsupported error.

## Legacy provider: `backend/app/services/configured_search.py`

This is the large historical/compatibility path. It constructs `SigLIP2Encoder`, loads the shared frame index, rejects Qwen encoder metadata, handles OCR/ASR expansion, query refinement, candidate reranking, legacy QA/TRAKE and image search. It remains relevant and is not dead code merely because Qwen is the default.

## Embedding adapters

`qwen3_vl.py` dynamically loads the official script from the external model directory. It uses Qwen's `process()` output, pools/truncates/normalizes and returns NumPy float32. Current main's adapter exposes `encode_query` and `encode_text`, not a verified `encode_image`. `siglip2.py` exposes image/text operations, model caching, device policy and long-text chunking.

## Ingest/index

`projectctl.py` dispatches `ingest` to `command_ingest`; `backend/app/video/ingest.py` discovers video files, builds `VideoIngestConfig`, constructs `SigLIP2Encoder`, runs `VideoIngestionPipeline`, and calls `build_frame_index`. `m15_ingestion_pipeline.py` stages metadata, sequential frame sampling/storage and embeddings with resumable manifests. `frame_index.py` writes staged `frames.faiss`, `mapping.json`, `payloads.json`, `generation.json`, validates hashes/cardinality/identity, renames the generation into `generations/`, then atomically publishes `CURRENT`.

## Text evidence

`m16_text_pipeline.py` fingerprints OCR/ASR settings and source state, validates/resumes per-video caches, extracts OCR from stored frame images, transcribes audio, maps ASR segment endpoints to nearest decoded frame ordinals and persists JSON plus metadata.

## Runtime/support modules

`runtime/device_policy.py` resolves CPU/CUDA policy; `model_cache.py` inventories/prepares models; `video_source.py` resolves local/cache/HTTP sources; `atomic_io.py` provides atomic writes/fsync; retrieval modules contain legacy pipelines, ranking, temporal refinement, distributed abstractions and competition scoring. The test inventory maps the concrete test functions to components.

# 6. Embedding and search architecture

## Qwen production/default

- Model family: `Qwen/Qwen3-VL-Embedding-2B`.
- Model loading: `Qwen3VLEmbedder` dynamically loaded from `<QWEN3_VL_MODEL_DIR>/scripts/qwen3_vl_embedding.py`; weights remain external.
- Instruction: `Retrieve the video frame that best matches the described visual scene.`
- Query max length in current adapter: 256 by constructor default.
- Pooling: official script pools last attended hidden state.
- MRL: output is sliced to active index dimension; production DB is 1024.
- Normalization: float32 L2 after truncation; FAISS inner product corresponds to cosine for unit vectors.
- Runtime device: official script selects CUDA if `torch.cuda.is_available()`; current CPU audit uses CPU. The Docker GPU profile installs a CUDA torch wheel and requests NVIDIA devices, but no GPU validation was possible.
- Index guard: Qwen provider refuses active generation metadata whose backend is not one of the Qwen backend names.

## SigLIP2

- Code: `backend/app/embeddings/siglip2.py`; model default `google/siglip2-base-patch16-224`; legacy dimension is 768 in the source/test/docs context.
- Search role: `ConfiguredSearch` explicitly constructs it and owns image search, legacy query refinement/reranking/temporal behavior.
- Ingest role: `backend/app/video/ingest.py` constructs it for `projectctl.py ingest`.
- Test role: many tests cover real or stub SigLIP2 behavior, index wrapper and long-text chunking.
- Compatibility role: `ConfiguredSearch._guard_index_backend()` refuses a Qwen-built index, preventing silent wrong-space queries.
- Removal status: blocked. Current Qwen image query is explicitly unsupported and no verified Qwen frame-image ingest contract exists on main.

## Embedding-space rule

A 1024-D shape alone is insufficient to establish semantic compatibility. The generation metadata encoder identity, model revision, instruction, preprocessing, pooling, normalization and sampling provenance must match. Never run `projectctl ingest` against the active Qwen production DB.

# 7. Offline ingest and indexing

## Actual current command

`python3 projectctl.py ingest <path> ...` eventually calls `backend/app/video/ingest.py:main()`. It defaults to output `data/processed/videos`, sample interval 1.0, batch size 8, CPU device and resume enabled. It constructs `SigLIP2Encoder` at line 87. This is not a Qwen production ingest path.

## Current pipeline

`discover_videos()` accepts mp4/mov/mkv/webm/avi and sorts directory paths. Duplicate stems are rejected. `VideoIngestionPipeline` inspects video metadata, sequentially decodes frames through PyAV, creates authoritative display-order frame records, samples according to `VideoIngestConfig`, writes frame artifacts/manifests atomically, embeds with the supplied SigLIP2 encoder and resumes from valid stage fingerprints.

`build_frame_index()` concatenates completed per-video embeddings, creates `FaissSigLIPIndex`, persists FAISS/mapping, writes payloads and generation metadata into `.staging/gen-*`, validates checksums and canonical identities, moves the generation into `generations/`, and atomically writes `CURRENT`.

## OCR/ASR

M16 operates after frame artifacts. OCR reads stored frame images through the selected backend and saves per-video `ocr.json` plus `ocr_meta.json`. ASR transcribes the source video, maps segment start/end timestamps to nearest sequential decoded frame ordinals and saves `asr.json` plus `asr_meta.json`. Resume is fingerprint-based and corrupt/changed caches are invalidated.

## Compatibility hazard

The active production DB v1 is Qwen 1024-D, while current source ingest constructs SigLIP2. The shared index schema can hold either identity, so metadata guards are essential. Qwen runtime rejects non-Qwen identity; legacy runtime rejects Qwen identity. However, there is no explicit `ingest-qwen` command and no current-main proof that the historical production Qwen frame vectors can be reproduced. The safe operational rule is: do not run current `ingest` with production output root.

# 8. Data and index contract

## Active production DB v1

The external runtime inspected in prior validation contains `index/CURRENT` pointing to `gen-A-b531063ff8ce48e1b0d62739fb290c23`. Its generation metadata records Qwen3-VL-Embedding-2B, backend `qwen3_vl_embedding_2b`, revision `9f2f7e710d6d81056aa5c0a4f04764fec6bb7bda`, 1024 dimensions, L2 normalization, `IndexFlatIP`, 47,430 vectors and 873 videos at a coarse 10-second cadence. The verified cardinality invariant is FAISS ntotal = mapping count = payload count = 47,430.

Expected layout:

```text
<processed-root>/
  index/CURRENT
  index/generations/<generation-id>/
    frames.faiss
    mapping.json
    payloads.json
    generation.json
  <video-id>/metadata.json, frames.json, embeddings.npy, manifest.json
  <video-id>/ocr.json, ocr_meta.json, asr.json, asr_meta.json
```

The active serving container mounts DB v1 read-only. The service does not ingest, rewrite or publish generations online.

## Identity

Frame UID is canonical `{video_id}:{source_frame_index_zero_based:09d}`. The authoritative frame index is the sequential PyAV display-order ordinal. Timestamp is retained as observed PTS/time-base-derived seconds. Timestamp multiplied by FPS is not authoritative.

## Generation publication

`frame_index.validate_generation()` requires four files, schema version 1, path/generation identity, declared SHA-256 artifacts, valid FAISS/mapping, payload identity equality, vector count and canonical UID format. `build_frame_index()` stages under `.staging`, validates before rename, fsyncs the generations directory, and atomically writes `CURRENT`. Previous generations remain available for rollback.

## DB v2

DB v2/dense artifacts are experimental branches/artifacts and are not the active production source. The current-main serving code uses `VIDEO_PROCESSED_ROOT/index` and Qwen DB v1 metadata. Do not substitute DB v2 without a separately validated runtime contract.

# 9. Full API reference

Authentication for all routes: NONE in application code. Put the service behind network/auth controls before exposure.

## GET `/`

Source/handler: `backend/app/main.py:create_app().index`. Purpose: returns `frontend/src/index.html`. Parameters/body: none. Success: HTTP 200 file response. Errors: filesystem/server errors can produce 500. Dependencies: frontend source path in repository. Side effects: none.

## GET `/styles/{filename}`

Handler: `style` → `_frontend_asset("styles", filename)`. Parameters: filename must not contain slash/backslash/`..`; resolved file must exist below frontend root. Success: 200 CSS file. Invalid/missing assets: 404.

## GET `/scripts/{filename}`

Same safety and response contract as styles, serving `frontend/src/scripts`.

## GET `/health` and `/health/live`

Handler: `health`. Request body: none. Success JSON includes `status=ok`, `search_configured`, `processed_root`, provider `search` status and `compute` runtime summary. No model inference is required by the route itself, but provider status may be initialized depending lifecycle. Errors: normal server errors only.

## GET `/health/ready`

Handler: `ready`. Request body: none. Success 200 adds `status=ready`, `search_readiness`. Qwen readiness checks configured root, CURRENT, model weights, generation metadata/backend and positive dimension. If unavailable, HTTP 503 with `detail` containing status/reason/payload. This is the deployment healthcheck endpoint in release Compose.

## POST `/api/search`

Handler: `search`. Content-Type: `application/json`. Pydantic `SearchRequest`:

```json
{"query":"string, max 2000","query_type":"kis|qa|trake","events":["string, max 20"],"top_k":100,"temporal_refine":true,"query_refine":true,"rerank":true,"debug_query_plan":false}
```

`events` entries must be non-empty and <=2000 characters. `top_k` is 1..1000. Empty query with no events: 400. Pydantic violations: 422.

KIS/QA require non-empty query. Qwen returns ranked rows with rank, video_id, frame_id, source_frame_index_zero_based, frame_uid, timestamp_seconds, score, visual_score, OCR/ASR scores/evidence and video URL/evidence fields. QA adds answer, answer_backend/model/status; extractive is default. TRAKE requires ordered events and returns one row with frame_ids/events when a single video satisfies strict increasing frame order. Impossible TRAKE: 400. Unsupported mode: 400. Missing/unreadable model/index: 503 with sanitized error unless `DEBUG_API_ERRORS=true`; unexpected exceptions can be 500.

Side effects: lazy in-memory model/index/evidence initialization; no DB writes. Runtime dependencies: Qwen model, current generation, OCR/ASR spools.

Example:

```bash
curl -sS -H 'Content-Type: application/json' --data '{"query":"một người phụ nữ đang nấu ăn","query_type":"kis","top_k":3}' http://127.0.0.1:8000/api/search
```

## POST `/api/search/image`

Handler validates content type (`image/jpeg`, `image/png`, `image/webp` or multipart/form-data), max body 15 MiB, multipart file field `file`, and decodes with Pillow. Query parameter `top_k` is 1..1000; `raw` disables deduplication for providers that support it. 415 invalid content type, 413 oversized, 400 empty/corrupt/invalid multipart, 422 invalid query parameters, 503 unconfigured/unsupported/provider failure. The current Qwen provider explicitly raises unsupported image search; legacy SigLIP2 provider supports image search.

## GET/HEAD `/api/video/{video_id}`

Handler resolves local/cache/HTTP source via `video_source.resolve_video_path`. Video ID validation is performed by source resolver. No request body. Without Range: 200 `video/mp4`, Content-Length and Accept-Ranges. With one `Range: bytes=start-end` or suffix range: 206 with Content-Range and Content-Length. Multiple/invalid ranges: 416. Missing video: 404; source errors: 503. HEAD follows the same route. Cache writes can occur for lazy remote sources; local serving is read-only.

## GET `/api/frames/{video_id}/{filename}`

Filename must use jpg/webp/png, have no traversal separators, resolve under `<media_root>/<video_id>/frames` and be a file. Success: 200 FileResponse with public max-age cache header. Invalid/missing/symlink escape: 404.

# 10. Search modes

## KIS

`POST /api/search` with `query_type=kis`. Qwen text embedding is the visual retrieval signal; OCR/ASR lexical rows can expand candidates and contribute fixed fusion weights. Response rows identify exact video/frame UID and timestamp. Current production Qwen path is text-to-indexed-frame, not image query.

## QA

Uses the same retrieval path then adds extractive evidence-derived answers by default. `QA_ANSWER_BACKEND=remote_llm` can call an OpenAI-compatible endpoint sequentially for bounded top-N rows, but it is optional/experimental and requires URL/key. Missing remote configuration/failure falls back to extractive.

## TRAKE

`events` is an ordered list. Qwen provider searches each event, groups candidates by video and selects a sequence whose source frame indices strictly increase. No valid single-video sequence returns 400. This is a hard ordering contract rather than a generic top-k list. Legacy provider also has temporal refinement controls.

## Image search

The route exists and legacy `ConfiguredSearch`/SigLIP2 owns it. Current Qwen status reports `image=false` and `QwenRuntimeSearch.search_image()` raises a clear runtime error. Qwen image migration is therefore UNVERIFIED and SigLIP2 cannot be deleted safely.

# 11. Frontend

`frontend/src/index.html` is the application shell. `frontend/src/scripts/api.js` handles API requests; `app.js` owns UI state, query controls, rendering and result interactions; `shortcuts.js` owns keyboard shortcuts; `styles/main.css` provides visual layout. The frontend is vanilla HTML/CSS/ES6 and has no Node package manifest or build step.

Production FastAPI serves `/`, `/styles/{filename}` and `/scripts/{filename}` directly. Development `run_dev.py` serves the directory on loopback 3000 and proxies `/api/*` to backend loopback 8000, forwarding non-hop-by-hop headers and bounded request timeouts. Relative API URLs avoid standard same-origin CORS in the combined app.

UI features evidenced by source/docs include KIS/QA/TRAKE controls, result rendering, OCR/ASR evidence, raw video playback with range requests, frame/media links, image upload route handling and keyboard shortcuts. The backend remains authoritative for validation and AI; frontend does not load Qwen/SigLIP models.

# 12. Docker and Compose

## Dockerfile

`Dockerfile` uses `python:3.12-slim`, build argument `TORCH_INDEX_URL`, CPU torch index fallback, apt packages build-essential/gcc/g++/git/ffmpeg/tesseract language packs/libgl/curl, non-root `appuser` UID/GID 1000, `/app` workdir and writable cache/data/log directories. It copies dependency manifests first, installs torch/torchvision separately, installs remaining requirements, copies entrypoint/backend/frontend/projectctl, chowns `/app`, exposes 3000/8000, and executes one Uvicorn worker on 0.0.0.0:8000.

`.dockerignore` excludes `.git`, env/credentials, data/models/artifacts/logs/cache/tests/docs/scripts, research files, archives and frontend dependency directories. This keeps external production data out of image context.

## Compose differences

- `docker-compose.yml`: local build `aic:latest`, one `aic` service plus tools profile, generic writable host mounts, loopback default and liveness healthcheck.
- `docker-compose.cpu.yml`: image/build CPU profile, Qwen defaults, external read-only DB/model/video mounts, writable video cache, host 3000 and 8000 both mapped to container 8000, readiness healthcheck, json-file rotation.
- `docker-compose.gpu.yml`: same single service with CUDA torch index, CUDA env, NVIDIA device reservation and GPU OCR settings.
- `docker-compose.cuda.yml`: fragment with `backend` and `worker` services/devices; it does not match the single-service release topology and must not be treated as a complete standalone file.
- `docker-compose.release.yml`: image-first single service with production mount defaults and Qwen/extractive defaults.
- `ops/docker/release/compose.*`: operator-facing image-first release compose variants.

Compose plugin runtime validation was not possible on this host (`docker compose` unavailable). YAML and source were inspected; treat command execution as UNVERIFIED.

# 13. Hardware runtime

## CPU development/audit environment

Observed host: Intel Core i3-3217U 1.80GHz, 2 physical cores/4 logical CPUs, 9.0 GiB RAM, no NVIDIA GPU, AVX/F16C but no AVX2/AVX-512 BF16 flags observed. Native Qwen runtime loads on CPU and returns HTTP 200 KIS/QA. It is a functional correctness environment, not a competition performance target.

Current Qwen adapter defaults to bfloat16 in `Qwen3VlLocalEmbedder`; the official model script selects device based on CUDA availability. Actual prior CPU runtime validation used CPU torch and was healthy. Runtime thread policy reports two torch threads in the validated serving environment.

## Measured CPU sample

Five fixed API requests previously recorded: 55.4602s, 30.4724s, 23.8827s, 26.1936s, 22.7434s. Mean 31.7505s, median/p50 26.1936s, min 22.7434s, max 55.4602s, sample standard deviation 13.3630s. With linear percentile interpolation `(n-1)p`, p90 = 45.4646s and p95 = 50.4626s. This is an exploratory n=5 sample, not a reliable production percentile estimate. A point RSS observation was about 3.34 GiB; peak RSS was not measured.

## GPU target

GPU Docker supplies a CUDA torch index and Compose reserves NVIDIA devices. Expected invariant is same Qwen model/checkpoint, instruction, tokenization/max length, 1024-D MRL, normalization, FAISS DB and ranking pipeline. No GPU exists in this audit environment; status is `PENDING_GPU_VALIDATION`, not failed. Competition validation must measure device placement/no CPU fallback, model load, first/warm latency, P50/P95, throughput, utilization, peak VRAM, KIS/QA/TRAKE and CPU/GPU top-k consistency.

# 14. Configuration

Configuration sources are `backend/app/core/config.py`, runtime modules using `os.getenv`, `.env.example`, Dockerfile ENV/ARG, Compose interpolation/environment blocks, workflows and shell scripts. The exact extracted environment table is `inventories/environment-variables.csv`; narrative explanations are `appendices/environment-reference.md`.

Important groups:

- Backend/storage: `SEARCH_BACKEND`, legacy `SEARCH_ENCODER`, `VIDEO_PROCESSED_ROOT`, `MODEL_CACHE_DIR`, `QWEN3_VL_MODEL_DIR`, `QWEN_MODEL_DIR`.
- Evidence: `SEARCH_ENABLE_OCR`, `SEARCH_ENABLE_ASR`, OCR backend/fallback/device/confidence variables, `FASTER_WHISPER_MODEL`.
- QA: `QA_ANSWER_BACKEND`, URL/model/API key, timeout, evidence/token/remote-top-N limits.
- Query/ranking: query refiner, RERANKER, DEBUG_QUERY_PLAN, TRAKE settings, visual sampling/refinement.
- Media: `VIDEO_SOURCE_DIR`, URL template, cache, host/container mount variables.
- Runtime/security: `ALLOWED_ORIGINS`, `DEBUG_API_ERRORS`, offline flags, AIC bind/port, torch/cache variables.

Defaults vary between generic Compose, release Compose and `.env.example`; operators must choose one deployment profile and inspect rendered config. Secrets are runtime-only and must not be placed in images, committed env examples or logs.

# 15. Testing

Tracked tests: 96 files including unit, integration, support and one video fixture. `inventories/tests.csv` records test groups and model/data/GPU/Docker requirements. The suite covers frame identity/sampling/deduplication, ingest resume/publication, OCR/ASR, Qwen runtime guards/search/QA/TRAKE, SigLIP2, image API contracts, frontend/media routes, distributed legacy retrieval, device policy, model cache, query refiner, ranking and operational CLI.

## Evidence timeline

1. A first full `python -m pytest -q` attempt with the generic `python` command failed because no `python` executable was on PATH; this was an invocation/environment issue.
2. The corrected `python3 -m pytest -q` attempt reached collection and failed with five exact missing imports: `eval.m12_hard_negative_dataset`, `eval.m13_5_corpus`, `eval.m14_9router_quality`, `eval.m13_5_corpus` (second test) and `eval.m22_end_to_end_benchmark`.
3. `python3 projectctl.py test` invokes the same full pytest command and has the same baseline collection problem.
4. `python3 projectctl.py env --check` independently reported missing `faster-whisper` and host Tesseract in this audit environment.

These are baseline/environment limitations, not migration regressions: no migration source was applied. CI intentionally filters/excludes historical missing modules, slow/real-model/network/GPU tests and performs a narrower CPU gate.

The test suite has strong contract coverage but lacks a clean full collection on this checkout. No claim of all tests passing is made.

# 16. Observability

Health: `/health` and `/health/live` report status, provider configuration/status and compute summary; `/health/ready` validates model/index readiness and returns 503 detail when not ready. Qwen provider records last query metrics including backend, generation and total query milliseconds, optionally exposed through debug query plan response.

Logging uses Python/Uvicorn log output. `main.py` logs search/video/image exceptions; `DEBUG_API_ERRORS` controls raw exception detail in selected 503 messages. Docker release Compose uses json-file logs with 10 MiB max size and 3 files.

No Prometheus metrics route, OpenTelemetry tracing, centralized log shipper, alerting integration, external error tracker or GPU metrics collector is present. Operators must use `docker logs`, `docker stats`, `docker top`, `ps`, `free`, `df`, `ss`, health endpoints and application response timings.

# 17. Defensive security review

| ID | Severity | Evidence | Impact | Recommendation | Confidence |
|---|---|---|---|---|---|
| SEC-01 | High | `main.py` routes have no auth middleware | Any network-reachable client can search/read media | Put behind VPN/authenticated reverse proxy/firewall before LAN/public exposure | High |
| SEC-02 | Medium | CORS `allow_credentials=True`, wildcard headers, explicit origin list | Browser trust boundary depends on correct origins | Keep exact origins; do not use `*`; pair with auth | High |
| SEC-03 | Medium | `DEBUG_API_ERRORS` can include exception type/text | Paths/config details may leak | false in production; sanitize logs/access | High |
| SEC-04 | Medium | `video_source.py` supports HTTP URL templates/lazy downloads | Operator-controlled URLs can create SSRF/egress risk | allowlist hosts/schemes, restrict egress, validate IDs | Medium |
| SEC-05 | Medium | `QA_ANSWER_API_KEY` sent to external OpenAI-compatible endpoint | Secret and evidence leave host if enabled | extractive default; restrict endpoint and rotate key | High |
| SEC-06 | Medium | requirements/pyproject versions broadly unconstrained | Dependency drift/supply-chain reproducibility risk | lock/hash production dependencies and scan images | High |
| SEC-07 | Medium | no rate limiting/auth quotas | expensive model queries can exhaust CPU/RAM | add reverse-proxy/application limits | High |
| SEC-08 | Low | container runs non-root but cache is writable | cache mount ownership/data integrity risk | keep DB/model/videos ro; scope cache permissions | High |
| SEC-09 | Low | Docker base/dependencies not digest locked | build reproducibility risk | pin base digest and dependency hashes | High |

Input validation is comparatively strong: image size/type checks, Pydantic bounds, filename/path resolution and symlink escape tests exist. No SQL database, SQL queries, JWT/OAuth, session or password handling exists in tracked application source.

# 18. CI/CD

`ci.yml` triggers on push and pull request to main plus manual dispatch, grants `contents: read`, cancels superseded runs and uses Ubuntu Python 3.12. It installs ffmpeg/Tesseract language packs, installs `.[dev]`, runs `projectctl.py env --check` and `smoke`, then filtered CPU pytest excluding slow/real-model/network/GPU and selected missing historical modules. A Docker job builds `aic-retrieval:ci` and verifies imports. It does not push an image or deploy.

`defender-for-devops.yml` triggers on push/PR main and a weekly cron, runs Windows Microsoft Security DevOps and uploads SARIF through CodeQL action. It is a security scan, not deployment.

No committed workflow performs Docker Hub login/push, release creation, migration, database deployment or production restart. Image-first publishing was performed operationally outside these workflows and is documented by ops guides.

# 19. Operations and release model

The repository has two release axes that must not be conflated:

- `aic-db-v1` / `aic-db-v2`: data/index generations/releases; DB compatibility is determined by encoder metadata/dimension/normalization and external artifacts.
- application Docker images: `gianguyen14/aic-retrieval:<tag>`; deployment pulls image and mounts external resources.
- documentation/audit artifact releases: independent GitHub assets or branch files; they do not change runtime.

Production image-first flow is GitHub source/build validation → Docker Hub → production host `docker compose pull` → `up -d` → readiness/KIS/QA/TRAKE/media smoke. Source-build deploy scripts remain in repo and have different behavior. Keep immutable image tag, external model/DB paths and CORS/env backup together.

The branch currently also contains the documentation artifact commit; it is not a source migration. `main` remains at the requested source baseline in the audit history.

# 20. Git history and architecture evolution

Relevant evolution:

- `852b938`/`26c9848`: introduced deterministic SigLIP2 encoder.
- `6e546c9`: production Docker deployment.
- `12be42f`, `023f05f`, `571c2bc`: visual encoder/index identity work and Qwen/SigLIP rollback architecture.
- `e5454af`: Qwen packed-DB runtime adapter.
- `82a5e01`: consolidated Qwen3-VL production search stack.
- `73fc6fe`: Qwen image-search experimental branch, not merged into main.
- `5e20013`, `1b87c4f`, `bd4d049`: video preview and per-video OCR/ASR evidence.
- `c39bea5`, `0565800`: optional remote QA synthesis and bounded calls.
- `8337437`, `4c4c9d8`, `ffb5c45`: CPU/GPU Docker finals configuration.
- `5b80413`, `1813223`: added/installed torchvision with torch to make Qwen query imports work in CPU image.
- `16386cb`: made Docker Hub deployment documentation image-first and added release compose examples.

`1813223` changed only Dockerfile dependency installation; it installs torch and torchvision together and excludes both from the general dependency pass. `16386cb` changed only operational docs/examples and release compose files; it did not change application runtime or index semantics. Later `245e508` on the migration branch adds only the documentation ZIP/checksum.


# 21. Full file reference appendix

Every tracked file is represented below. Important source files include symbols and operational implications; small artifacts are grouped by explicit path but still described.

## `.dockerignore`
**Role:** Committed container file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.env.example`
**Role:** Documented environment template for host paths, search backend, OCR/ASR, QA, refiner, networking and secrets placeholders.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.github/workflows/ci.yml`
**Role:** GitHub Actions workflow for CI or security scanning.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: name, on, push, branches, pull_request, branches, workflow_dispatch, permissions, contents, concurrency, group, cancel-in-progress
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.github/workflows/defender-for-devops.yml`
**Role:** GitHub Actions workflow for CI or security scanning.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: name, on, push, branches, pull_request, branches, schedule, jobs, MSDO, runs-on, steps
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `.gitignore`
**Role:** Committed configuration file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `AGENTS.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ARCHITECTURE.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `DOCKER.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `Dockerfile`
**Role:** Single-stage Python 3.12 production image; installs CPU/CUDA-selectable torch, OS media/OCR packages, source and one-worker Uvicorn.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** FROM, ARG, ENV, RUN, COPY, USER, ENTRYPOINT, CMD
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `README.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `README.vi.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `SECURITY.md`
**Role:** Committed documentation file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/ablation_results.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/autonomous_m27_m31_state.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/benchmark_patched_results.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/final_engineering_stabilization_state.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/frame_sampling_benchmark_matrix.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/frame_sampling_final_report.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/frame_sampling_legacy_baseline.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/m27_three_video_query_results.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/m31_final_report.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/real_sample_validation.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V004.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V005.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V006.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V007.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V008.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V009.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V010.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V011.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V012.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V013.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V014.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V015.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V016.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V017.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio/L22_V018.mp4.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V001.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V001.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V001.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V002.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V002.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V002.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V003.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V003.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V003.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V004.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V004.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V004.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V005.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V005.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V005.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V006.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V006.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V006.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V007.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V007.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V007.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V008.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V008.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V008.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V009.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V009.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V009.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V010.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V010.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V010.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V011.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V011.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V011.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V012.mp4_300.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V012.mp4_600.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/tmp_audio2/L22_V012.mp4_900.wav`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/video_audit.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/video_transcripts_sample.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `artifacts/video_transcripts_sampled_windows.json`
**Role:** Committed experiment/evaluation artifact; not a runtime dependency unless a script explicitly loads it.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/__init__.py`
**Role:** Committed application-source file for backend; purpose inferred from path and file header.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/api/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/api/advanced_search_api.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** configure_advanced_search_service, _get_service, _response, search_text_advanced, search_image_advanced, search_hybrid
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/api/search_api.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** configure_search_service, _get_search_service, search_text_endpoint, search_image_endpoint
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/competition_data.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** KISGroundTruth, QAGroundTruth, TRAKEGroundTruth, validate_dataset, dataset_report, load_jsonl, _validate, OrganizerAdapter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/competition_evaluation.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** evaluate_competition, _mean_report
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/local_refine_config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** LocalRefineConfig
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/retrieval_config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RetrievalConfig
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/config/video_ingest_config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _fingerprint, VideoIngestConfig
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/core/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/core/config.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/dataset_ops.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** verify_media
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QueryCache
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/centroid_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShardCentroidIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/coordinator.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DistributedCoordinator
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m10_cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M10QueryCache
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m10_coordinator.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M10Coordinator
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m10_merge.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** merge_normalized
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m11_centroid_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MultiCentroidIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m11_merge.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** merge_zscore, merge_hybrid
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/m11_router.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M11SemanticRouter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/merge.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** merge_results
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/router.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShardRouter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/routing_policy.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RoutingPolicy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/rpc.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ThreadRPC
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/semantic_router.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SemanticShardRouter
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/distributed/worker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FaissWorker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/embeddings/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/embeddings/qwen3_vl.py`
**Role:** Local Qwen3-VL text-query adapter with instruction, pooling, MRL truncation and float32 L2 normalization.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** resolve_model_dir, model_script_path, weights_available, Qwen3VlLocalEmbedder
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/embeddings/siglip2.py`
**Role:** SigLIP2 dual-encoder adapter for legacy text and image embeddings, long-text handling and model identity.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** resolve_siglip2_revision, SigLIP2Encoder, get_siglip2_encoder
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/advanced_faiss_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AdvancedFaissIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/benchmark.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** generate_synthetic_embeddings, get_process_memory_mb, benchmark_index_suite
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/faiss_siglip_index.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FaissSigLIPIndex
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/indexes/index_factory.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** IndexFactory
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/loaders/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/loaders/aic_loader.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AICLoader, create_loader
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/loaders/metadata_loader.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MetadataError, _run_ffprobe, _fallback_from_filename, load_metadata
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/main.py`
**Role:** FastAPI composition root: backend selection, health, search, frontend assets, frame serving and HTTP range video routes.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _iter_file_range, _debug_api_errors_enabled, _unavailable_detail, _read_limited_body, _multipart_file, _decode_image, SearchRequest, _build_configured_search, create_app
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/model_cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** model_cache_dir, visual_model_name, asr_model_name, _status, visual_status, _download_asr, asr_status, paddleocr_status, prepare_paddleocr, prepare_visual, prepare_asr, query_refiner_model_name, query_refiner_status, prepare_query_refiner, inventory
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/pipelines/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/async_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AsyncFaissRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/batch_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** BatchFaissRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/cache.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** EmbeddingCache
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/candidate_resolver.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CandidateResolver, MappingCandidateResolver, PersistentCandidateResolver, candidate_id, resolve_candidates
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/competition_scoring.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** kis_r_score, qa_r_score, trake_r_score, competition_score, diversify
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/cross_encoder_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CrossEncoderReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/distributed_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DistributedRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/hybrid_ranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** HybridRanker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/hybrid_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** HybridSigLIPRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/kis_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** KISResult, DenseTemporalRefiner, KISPipeline, frame_interval_hit
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/local_refinement.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CoarseCandidate, MergedRegion, RefinedCandidate, generate_candidate_regions, generate_local_timestamps, refine_coarse_candidates
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/m12_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M12RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/m13_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M13RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/m14_pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** M14RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/model_scorer.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** validate_scores, ModelScorer, DeterministicTestScorer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/ninerouter_vision_scorer.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** NineRouterError, NineRouterHTTPError, _default_transport, NineRouterVisionScorer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/pipeline.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RetrievalPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/qa_query_decomposition.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QAQueryDecomposer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/query_planner.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Plan, QueryPlanner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/ranking_metrics.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _relevance, _unique_at_k, recall_at_k, precision_at_k, mrr_at_k, ndcg_at_k, ranking_metrics
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SimpleCosineReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SigLIPFaissRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/semantic_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SemanticReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/sharded_retriever.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShardedRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/siglip_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SigLIPSemanticScorer, create_siglip_reranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/trake.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** EventCandidate, TRAKEResult, TRAKEAligner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/video_multimodal.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _content_tokens, _query_features, _phrase_relevance, lexical_score, minmax, VideoSegmentCandidate, MultimodalVideoRetriever
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrieval/video_qa.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _classify_question, _is_valid_answer, _extract_proper_nouns, _evidence_support, VideoQAResult, ExtractiveAnswerer, VideoQAPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/retrievers/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/runtime/device_policy.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** RuntimeCapabilities, DeviceSelection, normalize_device, device_request, probe_torch, probe_ctranslate2, probe_paddle, resolve_device, _diagnostic_selection, runtime_summary
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/runtime/operations.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** memory_snapshot, memory_guard, resource_limits, resource_preflight, _get_git_provenance, write_run_manifest
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/samplers/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/samplers/base.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SamplingConfig, SamplingStrategy, FixedFPSStrategy, ShotPlusFixedFPSStrategy, AdaptiveDenseStrategy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/schemas/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/schemas/frame.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameData, ShotData
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/advanced_search_service.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** AdvancedSearchService
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/candidate_reranker.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** classify_exact_match, CandidateReranker
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/configured_search.py`
**Role:** Legacy SigLIP2 configured search provider including image search, query refinement, reranking and temporal refinement.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _read_modality_weight, _validated_modality_weight, _match_exact_term, ConfiguredSearch
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/qa_answer_synthesizer.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QAAnswerResult, QAAnswerSynthesizer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/query_refiner.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VisualQuery, TRAKEStagePlan, QueryPlan, LLMRefinementResponse, _phrase_pattern, _phrase_spans, _spans_overlap, validate_english_caption, DeterministicQueryParser, LocalLLMQueryRefiner, QueryPlanCache, QueryRefiner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/qwen_runtime_search.py`
**Role:** Qwen production text-query search provider: model encoding, FAISS recall, OCR/ASR fusion, QA and TRAKE.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** normalize_text, content_tokens, lexical_score, _prepared_lexical_score, build_timeline, nearest_uid, _best_text_evidence, _attach_video_evidence, QwenRuntimeSearch
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/search_service.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SearchService
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/temporal_refiner.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TemporalRefinerConfig, TemporalRegion, TemporalRefineCache, TemporalRefiner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/trake_coherence.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CoherenceDiagnostics, TRAKECoherenceAnalyzer
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/services/video_source.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _lock_for, cache_dir, source_dir, source_url_template, configured, video_url_for, valid_video_id, _download, resolve_video_path
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/shot_detection/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/shot_detection/base.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ShotDetector, TransNetV2Adapter, get_shot_detector, NullShotDetector
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/strategies/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/utils/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/utils/latency.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** LatencyRecorder
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/utils/profiling.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** timer, timing, measure_search_time, measure_batch_latency, memory_usage_estimate
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/validation/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/validation/dataset_validator.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** compute_file_sha256, get_process_rss_mb, create_subset_manifest, verify_frame_id_integrity, verify_artifact_integrity, run_query_batch_validation
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/__init__.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/atomic_io.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** fsync_directory, _replace, write_json_atomic, write_numpy_atomic
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_dedup.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** filter_near_duplicate_frames
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_id_policy.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameIdPolicy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_index.py`
**Role:** Immutable FAISS generation builder/validator and atomic CURRENT publication.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameIndexBundle, _sha256, current_generation_id, cleanup_stale_staging, _mapping_ids, validate_generation, load_current_frame_index, build_frame_index
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_neighborhood.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_frame_neighborhood, get_temporal_neighborhood
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_record.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameRecord
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_sampler.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FrameSamplingError, SampledFrame, iter_sample_frames, sample_frames, sample_sparse_shot_frames_with_protection, sample_sparse_shot_frames, iter_sample_sparse_shot_frames, extract_shot_representative_indices
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/frame_store.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** source_hash, ResumePlan, FrameStore
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/ingest.py`
**Role:** CLI and orchestration for offline video ingest; constructs SigLIP2Encoder and publishes FAISS generations.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** discover_videos, ingest_path, main
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/ingest_manifest.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** IngestManifest
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/m15_ingestion_pipeline.py`
**Role:** Per-video metadata/frame/embedding ingestion pipeline with checkpointed manifests and resume.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VideoIngestionPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/m16_text_pipeline.py`
**Role:** Offline OCR/ASR evidence extraction, fingerprinting, cache validation and frame-timeline projection.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _fingerprint_digest, compute_ocr_fingerprint, compute_asr_fingerprint, TextEvidenceStore, M16TextPipeline
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/text_backends.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** resolve_whisper_revision, OCRBackend, TesseractOCRBackend, PaddleOCRBackend, AdaptiveOCRBackend, EasyOCRBackend, create_ocr_backend, ASRBackend, FasterWhisperASRBackend, SidecarASRBackend
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/text_evidence.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** normalize_text, OCRRecord, ASRSegment
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/video_decoder.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VideoDecodeError, DecodedFrame, _optional_int, _optional_float, inspect_video, iter_frames, inspect_and_count_video, decode_frame_indices
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/app/video/video_metadata.py`
**Role:** Backend module implementing the component named by its path.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** VideoMetadata
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `backend/scripts/__init__.py`
**Role:** Committed application-source file for backend/scripts; purpose inferred from path and file header.
**Used by:** main application
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `data/indexes/.gitkeep`
**Role:** Committed data-placeholder file for data/indexes; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `data/logs/.gitkeep`
**Role:** Committed data-placeholder file for data/logs; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `data/processed/.gitkeep`
**Role:** Committed data-placeholder file for data/processed; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/install.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/rollback.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/status.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `deploy/update.sh`
**Role:** Source-build installation, update, status or rollback shell operation.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.cpu.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, build, container_name, restart, ports, environment, volumes, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.cuda.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, backend, environment, deploy, worker, environment, deploy
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.gpu.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, build, container_name, restart, ports, environment, volumes, deploy, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.release.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, container_name, restart, ports, environment, volumes, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-compose.yml`
**Role:** Compose profile or override defining image/build, mounts, env, ports, healthcheck and optional GPU resources.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, build, image, container_name, restart, ports, env_file, environment, volumes, healthcheck, aic-cli
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docker-entrypoint.sh`
**Role:** Committed container file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/.gitkeep`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/ADR-0005-qwen-backend.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/ADR-0006-qa-remote-llm.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ADR/ADR-0007-video-preview.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/API_REFERENCE.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/ARCHITECTURE.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/DATA_CONTRACT.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/DEPLOYMENT.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/QA_SYNTHESIS.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/QUICKSTART.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/RUNTIME_CONFIG.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/SEARCH_BACKENDS.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/autonomous_m27_m31_checkpoint.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m15_video_ingestion.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m16_text_evidence.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m27_representative_evaluation.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m27_three_video_evaluation.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m28_retrieval_quality_v2.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m29_temporal_refinement.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m30_qa_quality.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/milestones/m31_final_competition_readiness.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/RC_RELEASE.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/REAL_DATA_VALIDATION.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_deployment.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_hub_private_deployment.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_release_1.0.0.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/docker_release_1.1.0-rc1.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_engineering_freeze_report.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_engineering_stabilization_checkpoint.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_freeze_manifest.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_system_audit_and_architecture.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/final_worktree_inventory.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/real_data_validation_inventory.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/archive/releases_and_freezes/real_sample_validation.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/competition_data.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `docs/projectctl.md`
**Role:** Technical or milestone documentation; current-vs-archived authority is noted in consistency audit.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/__init__.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/faiss_siglip_benchmark.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** generate_synthetic_vectors, generate_frame_ids, percentile_95, benchmark_faiss_sigclip_index, main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/sampling_benchmark.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** estimate_storage_size, run_benchmark, main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/sampling_benchmark_results.json`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/siglip2_benchmark.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_memory_usage_mb, get_gpu_memory_mb, create_test_images, run_benchmark
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `eval/siglip2_benchmark_results.json`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/README.md`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/index.html`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/scripts/api.js`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/scripts/app.js`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/scripts/shortcuts.js`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `frontend/src/styles/main.css`
**Role:** Vanilla frontend asset used by FastAPI static hosting or run_dev.py.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `multiv2-qwen-system-documentation.zip`
**Role:** Committed other file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `multiv2-qwen-system-documentation.zip.sha256`
**Role:** Committed other file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/DOCKER_CPU_GUIDE.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/DOCKER_GPU_GUIDE.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/FINALS_HARDWARE_QUALIFICATION.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/FULL_SYSTEM_USAGE_GUIDE.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/.env.cpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/.env.gpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/README.md`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/build-cpu.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/build-gpu.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/diagnose.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/.env.cpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/.env.gpu.example`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/compose.cpu.yml`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, container_name, restart, ports, environment, volumes, healthcheck, logging
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/docker/release/compose.gpu.yml`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** top-level YAML keys: services, aic, image, container_name, restart, ports, environment, volumes, deploy, healthcheck
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/finals_smoke.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `ops/qualify_finals_hardware.sh`
**Role:** Operational guide/script for Docker, smoke checks, hardware qualification or external data/model support.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `projectctl.py`
**Role:** Operator CLI for env/doctor/status, model preparation, server startup, ingest, search, evaluation and cleanup.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** executable, tesseract_languages, _package_version, environment_report, command_env, command_dataset, command_smoke, model_inventory, readiness, _module, emit, configured_search, search_rows, command_doctor, _selected_models, command_models, _require_models, command_status
**Runtime impact:** high
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** can prevent startup/search/deployment
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `pyproject.toml`
**Role:** Committed configuration file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `pytest.ini`
**Role:** Committed configuration file for .; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/base.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/cpu.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/dev.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `requirements/gpu.txt`
**Role:** Python dependency profile for base/CPU/GPU/development environments.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `run_dev.py`
**Role:** Standard-library development runner: starts backend on 127.0.0.1:8000, serves/proxies frontend on 127.0.0.1:3000.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DevHTTPServer, DevRequestHandler, _backend_process, _stop_backend, _validate_layout, main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/ablation.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_ablation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/audit_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, run_audit_and_fix
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/build_gt_v1.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, build
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/build_gt_v2.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, build
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/build_m27_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_interval
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/create_m27_three_video_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** get_real_frame_index, build
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/debug_qa.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/eval_m27.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** evaluate
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/eval_mini_gt.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_eval
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/fusion_experiment.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** lexical_score_v2, strategy_d_visual_first_rerank
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/inspect_asr_ocr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/m26_1_trace.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** rank_of, init_searcher
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/make_contact_sheets.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/make_sparse_contacts.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/print_asr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/print_asr_v2_v3.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/prove_frames.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/run_queries.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/sample_asr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/sample_asr_windows.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** main
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/sample_text.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/subset_matrix.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/test_api.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/test_api_v2.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/test_fusion_v2.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_single_query
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/trace_fusion.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_traces
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/trace_qa.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/validate_artifacts.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/validate_ocr.py`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** validate
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `scripts/validate_rc2_gpu.sh`
**Role:** Offline evaluation, artifact inspection, query, benchmark or experiment script.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/__init__.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/fixtures/test_5s.mp4`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** repository/build/runtime context
**Important symbols:** document/script/config content
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_advanced_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, make_system, test_reranking_changes_order_and_shape, test_hybrid_and_single_modality_fallbacks, test_expansion_and_edge_cases
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_aic_loader.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TestAICLoaderIntegration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_candidate_reranker_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyIndex, DummyResolver, DummyEncoder, test_configured_search_reranker_integration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_configured_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** QueryEncoder, test_configured_app_lazily_opens_current_generation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_distributed_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Worker, test_routing_and_merge, test_distributed_correctness_cache_and_failure
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_faiss_siglip_index_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** siglip_encoder, sample_images, sample_frame_ids, TestFaissSigLIPIndexIntegration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m10_routing.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_semantic_routing_selects_closest_shards, test_merge_normalizes_and_deduplicates, test_cache_respects_routing_configuration, test_adaptive_policy_changes_behavior
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m11_ranking.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_multi_centroid_routing_and_recall, test_reranker_improves_ordering, test_hybrid_merge_and_zscore_dedup
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m12_quality.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, FakeRetriever, test_hard_negative_dataset_is_genuinely_difficult, test_candidate_generation_reranking_and_quality_gate, test_pipeline_survives_semantic_backend_failure
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m13_5_evaluation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, test_same_candidate_evaluation_reports_all_metrics, test_bootstrap_is_deterministic
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m13_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, FakeRetriever, FailingScorer, fixtures, test_retrieve_resolve_batch_score_and_same_candidate_invariant, test_model_failure_fails_open_to_retrieval_order, test_missing_payload_fails_open_without_dropping_results
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m13_siglip_real.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_real_siglip_dual_encoder_scores_local_images
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m14_9router_real.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_real_9router_model_accepts_image_and_returns_relevance_score
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m14_evaluation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Encoder, Scorer, test_m14_same_candidate_quality_signal_and_bootstrap_reporting, test_hard_negative_error_detects_negative_above_grade_three
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m14_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Encoder, Retriever, Scorer, pipeline, test_retrieves_once_scores_same_pool_preserves_metadata_and_stable_ties, test_invalid_score_or_exception_fails_open_for_entire_query, test_hybrid_uses_same_candidate_pool_and_final_k
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_config_invalidation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_config_invalidation_is_dependency_aware, test_manifest_claim_is_rejected_when_embedding_is_missing, test_index_type_change_rebuilds_only_index
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_corrupt_video_isolation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_corrupt_video_does_not_destroy_valid_dataset_ingestion
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_index_publication.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_failed_publication_preserves_previous_generation, test_current_replace_failure_preserves_active_generation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_interrupted_resume.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** logical_artifacts, test_forced_interruption_resumes_from_highest_valid_stage
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_multivideo_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_multivideo_search_resolves_original_frames
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_siglip2_real.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_real_siglip2_multivideo_search_mapping
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m15_video_ingestion.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, test_m15_ingestion_resume_index_and_resolution
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m16_text_evidence.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeOCR, FakeASR, ingest, test_ocr_asr_persistence_mapping_and_resume, test_modality_resume_does_not_suppress_later_asr, test_silent_no_text_and_failure_isolation, test_unicode_normalization_preserves_vietnamese, test_ocr_asr_fingerprint_invalidation_and_selective_rerun, test_corrupt_ocr_asr_json_safely_invalidates, test_legacy_ocr_asr_cache_without_meta_is_safely_accepted
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m17_multimodal_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** frame, test_each_modality_and_fusion_retrieve_their_evidence, test_multimodal_evaluation_has_complete_candidate_coverage
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m18_kis_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, FakeRetriever, test_dense_refinement_selects_exact_semantic_frame, test_dense_refinement_falls_back_and_enforces_budget
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m19_video_qa.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** KIS, record, test_qa_localizes_and_answers_from_ocr_evidence, test_qa_uses_asr_and_abstains_without_evidence
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m20_trake.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_trake_dynamic_programming_enforces_order, test_trake_rejects_wrong_order_and_impossible_gap, test_trake_impossible_intermediate_transition_no_spurious_path, test_trake_same_video_enforcement, test_trake_small_top_k_disjoint_candidates, test_trake_malformed_and_edge_case_events, test_trake_ties_are_deterministic, test_trake_cli_and_configured_search_consistency
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m21_competition_scoring.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_competition_cutoff_score_rewards_early_hits, test_qa_and_trake_scores_apply_full_conditions, test_diversification_removes_temporal_duplicates_and_caps_videos
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m23_operator_api.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_operator_ui_health_search_and_media, test_video_result_contract_and_player_assets, test_operator_page_contains_competition_controls, test_frontend_static_assets_are_served_and_traversal_rejected, test_unconfigured_search_and_path_traversal_are_rejected, test_frame_server_rejects_symlink_escape, test_cors_rejects_wildcard_with_credentials, test_security_headers_present_on_responses, test_search_endpoint_rejects_server_local_image_query
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_m8_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** Encoder, vectors, test_ivf_training_and_search, test_sharded_retrieval_and_pipeline, test_planner_decisions_and_config
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_ocr_routing_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MockIntegrationPrimaryPaddle, MockIntegrationFallbackTesseract, MockIntegrationFailingPaddle, test_adaptive_ocr_pipeline_integration_primary_success, test_adaptive_ocr_pipeline_integration_fallback_on_primary_error
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_performance_layer.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** CountingEncoder, test_batch_matches_loop_for_flat_and_hnsw, test_async_matches_loop, test_cache_reduces_encoder_work
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_query_refiner_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyIndex, DummyResolver, DummyEncoder, DummyBundle, test_dual_visual_retrieval_dedup, test_ocr_and_visual_fusion, test_trake_dp_preservation, test_kis_fallback_when_query_refine_disabled, test_image_search_does_not_invoke_query_refiner, test_cli_query_plan, test_api_debug_query_plan, test_query_cache_corruption_resilience, test_synthetic_ocr_and_asr_routing_and_provenance, test_trake_gap_diagnostics_preserves_monotonicity
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_retrieval_pipeline.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeSigLIP2Encoder, test_image_and_text_retrieval_pipeline, test_retrieval_edge_cases
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_siglip2_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TestSigLIP2Integration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_temporal_refiner_integration.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** make_test_video, MockEncoder, test_configured_search_trake_end_to_end, test_offline_temporal_refinement_execution, test_kis_qa_image_search_contracts_unaffected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/integration/test_video_preview.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _client_with_source, test_video_route_serves_mp4_and_head, test_video_route_supports_range_seek, test_video_route_rejects_invalid_or_missing_video, test_video_route_lazy_downloads_from_url
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/m15_support.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** create_video, MeanRGBEncoder
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/smoke_three_video.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** run_smoke
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_9router_vision_reranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** image_path, response, test_constructs_pairwise_multimodal_request_without_retrieval_signals, test_rejects_invalid_model_output, test_retries_only_transient_failures, test_does_not_retry_auth_failure, test_accepts_observed_route_to_canonical_model_normalization, test_rejects_upstream_model_switch
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_adaptive_ocr.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MockSentinelPaddleBackend, MockSentinelTesseractBackend, MockWorkingPaddleBackend, MockWorkingTesseractBackend, MockFailingPaddleBackend, test_auto_cpu_routing_selects_tesseract, test_auto_gpu_routing_selects_paddle_primary, test_paddle_success_does_not_call_tesseract, test_empty_paddle_result_triggers_tesseract_fallback, test_low_confidence_paddle_triggers_fallback, test_paddle_runtime_error_falls_back_gracefully, test_forced_tesseract_never_initializes_paddle, test_forced_paddle_device_error, test_cache_fingerprint_invalidation_on_backend_change, test_resume_sentinel_does_not_construct_ocr_backends, test_corrupt_cache_validation_fails_safely, test_unicode_vietnamese_preserved
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_benchmark_retrieval.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_hhi_calculation, test_concentration_empty_and_normal, test_rank_metrics_calculations, test_latency_stats_calculations, test_query_input_loading_json_and_jsonl, test_failure_localization_stages, test_diversity_simulations
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_candidate_reranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_visual_only_preserves_rrf_order, test_exact_ocr_match_priority, test_partial_match_distinct_from_full_exact, test_multi_channel_candidate_priority, test_reranker_disabled_returns_unchanged, test_reranker_exception_fallback, test_score_scale_independence, test_no_gt_specific_strings
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_candidate_reranker_profiling.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _base_candidates, _plan, _ocr_evidence, _asr_evidence, test_candidate_reranker_profiling
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_candidate_resolver.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_single_and_missing_resolution, test_batch_preserves_order_and_metadata, test_resolve_candidates_preserves_retrieval_fields
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_competition_data.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_loads_internal_ground_truth_contracts, test_rejects_invalid_intervals_and_event_alignment
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_competition_evaluation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_competition_evaluator_reports_all_cutoffs
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_configured_search_fusion_weights.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _Encoder, _Resolver, _search, _plan, _ocr, _asr, test_weighted_rrf_is_sorted_by_fused_rank, test_modality_weights_are_isolated_and_zero_disables_work, test_default_rrf_weights_preserve_existing_asr_weight, test_invalid_modality_weight_is_rejected, test_invalid_visual_variant_weight_is_rejected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_device_policy.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** capability, test_device_syntax, test_precedence_keeps_explicit_auto, test_auto_cpu_and_cuda_are_backend_specific, test_explicit_cuda_errors_and_index_selection, test_cpu_only_components_reject_cuda
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_evaluator_semantics.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** evaluate_kis_result, evaluate_qa_result, evaluate_trake_result, test_kis_evaluator, test_qa_evaluator, test_trake_evaluator
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_faiss_siglip_index.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** sample_vectors, sample_frame_ids, TestFaissSigLIPIndex
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_dedup.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyFrameRecord, _make_unit_vector, test_first_frame_always_retained, test_near_duplicate_removed_when_above_threshold, test_distinct_frame_retained_when_below_threshold, test_threshold_boundary_deterministic_drop_at_exact_equality, test_comparison_against_previous_retained_reference, test_protected_shot_representative_survives_near_duplicate, test_all_detected_shots_remain_represented, test_periodic_only_fallback, test_disabled_dedup_returns_all_candidates, test_reject_invalid_dedup_threshold, test_dedup_determinism
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_id_policy.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_zero_and_one_based_submission_policies_preserve_internal_index, test_rejects_invalid_frame_policy_and_index
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_pipeline_invariants.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_timeline, test_config_rollback_legacy, test_config_sparse_shot_resolution, test_config_invalid_values_rejection, test_sampler_empty_input_raises_error, test_sampler_single_frame, test_sampler_interval_shorter_than_duration, test_sampler_interval_longer_than_duration, test_sampler_indivisible_duration, test_shot_boundary_matrix_and_filtering, test_synthetic_shot_coverage_100_percent, test_provenance_rules_and_forbidden_states, test_multi_shot_same_frame_edge_case, test_dedup_threshold_and_previous_retained_behavior, test_dedup_malformed_embeddings_rejection, test_metadata_roundtrip_new_and_old_payloads, test_existing_index_read_only_contract, test_shot_detector_factory_call_path_mocked
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_record.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_frame_uid_is_deterministic_and_roundtrips
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_frame_sampler.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** frame, test_irregular_timestamps_preserve_original_source_indices, test_streaming_sampler_does_not_consume_ahead, test_missing_pts_is_not_reconstructed_from_fps
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_gpu_rc2_stabilization.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_provenance_without_git, test_command_status_without_git, test_ocr_fallback_reporting, test_paddleocr_status_diagnostics, test_siglip2_vocab_and_token_invariants, test_query_refiner_fallback_safety, test_entrypoint_script_executable
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_hybrid_ranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_normalization_and_configurable_weights, test_zero_variance_dedup_and_determinism, test_invalid_weights_and_nonpositive_top_k
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_image_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** StubConfiguredSearch, dummy_image, test_image_embedding_normalization, test_search_image_missing_file, test_search_image_unsupported_input_type, test_api_image_search_empty_body, test_api_image_search_corrupt_body, test_api_image_search_multipart_and_query_options, test_api_image_search_rejects_non_image_content_type, test_api_image_search_invalid_top_k, test_authoritative_frame_id_semantics
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_imports.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_backend_imports
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_latency.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_latency_summary_reports_required_percentiles
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_local_refinement.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** SyntheticLocalFrame, test_region_generation_single_candidate, test_region_generation_clamp_start, test_region_generation_clamp_end_with_duration, test_region_generation_overlapping_same_video, test_region_generation_touching_windows, test_region_generation_separate_same_video, test_region_generation_cross_video_isolation, test_max_regions_applied_after_merging, test_max_regions_truncates_to_strongest, test_timestamp_generation_exact_intervals, test_timestamp_generation_non_divisible_end, test_timestamp_generation_deterministic_no_duplicates, test_refinement_selects_highest_similarity_frame, test_refinement_tie_break_earliest_timestamp, test_provider_called_once_per_merged_region, test_max_default_work_bound, test_config_validation_rejections
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_m13_5_corpus.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** write_corpus, test_valid_corpus_and_statistics, test_invalid_queries, test_duplicate_candidate_id, test_missing_image_path
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_m22_end_to_end_benchmark.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_benchmark_marks_unconfigured_stages_unavailable
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_metadata_loader.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_load_metadata_fixture, test_missing_file_raises, test_invalid_name_raises_without_fallback, test_fallback_only_when_allowed
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_model_cache.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module, test_visual_cached_and_missing, test_asr_cached_and_missing, test_model_cache_dir_precedence, test_prepare_uses_provider_resolvers, test_resolve_siglip2_and_whisper_snapshot_revisions, test_siglip2_encoder_identity_uses_resolved_revision
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_model_scorer.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeEncoder, test_deterministic_scorer_batch_association_and_backend, test_siglip_dual_encoder_batches_images_and_names_backend
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_multimodal_retrieval_v2.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_lexical_score_precision, test_long_query_is_not_diluted_below_candidate_threshold, test_single_overlap_in_long_noisy_evidence_stays_below_threshold, test_focused_phrase_outscores_generic_single_term_for_long_query, test_stopword_only_query_has_no_lexical_signal, test_exact_phrase_receives_full_relevance_amid_extra_text, test_lexical_score_is_always_bounded, test_multimodal_weight_isolation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_operations.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_memory_guard_refuses_low_available_memory, test_resource_limits_are_conservative, test_resource_preflight_and_run_manifest
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_projectctl.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** args, test_env_json_reports_runtime, test_doctor_reports_optional_blockers, test_search_json_and_export, test_missing_ocr_fails_actionably, test_competition_evaluate_missing_data_is_clear, test_dataset_report_does_not_require_ground_truth, test_preprocess_preflight_only_stops_before_all_stages, test_preflight_failure_is_reported_and_nonzero, test_normal_preprocess_preserves_stage_order, test_preprocess_keeps_optional_modalities_fail_open, inventory, test_models_help, test_models_inventory_json, test_models_selective_prepare, test_models_dry_run_does_not_prepare, test_offline_verification_fails_for_missing_model, test_preprocess_checks_visual_before_ingest
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_projectctl_qa.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** MockArgs, test_command_qa_decomposition, test_qa_query_decomposer
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qa_answer_synthesizer.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _Response, _synth, test_extractive_is_default_and_preserves_fallback, test_max_tokens_uses_configurable_budget_and_sends_it, test_max_tokens_floor_and_env_default, test_remote_sends_only_bounded_evidence_and_parses_answer, test_remote_failure_falls_back_without_raising, test_remote_abstention_keeps_remote_provenance, test_remote_empty_response_uses_extractive_fallback, test_default_remote_top_n_is_five, test_remote_top_n_clamped_to_safe_range, test_no_remote_call_when_not_configured
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qa_generalized_validation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_classify_question, test_unseen_synthetic_who_adversarial, test_valid_who_names, test_unseen_synthetic_where_adversarial, test_valid_where_locations, test_how_many_numeric_validation, test_directional_attribute_gating, test_proper_noun_constraint_gating, test_extractive_answerer_abstains_on_unsupported_adversarial, test_extractive_answerer_answers_supported_evidence, test_configured_qa_does_not_copy_evidence_between_candidates
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qa_query_decomposition.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_removes_dangling_vietnamese_copula_without_losing_constraints, test_preserves_vietnamese_subject_action_and_location, test_removes_unknown_action_but_keeps_subject_and_location, test_removes_unknown_topic_scaffold, test_preserves_internal_vietnamese_copula, test_preserves_wh_shaped_token_at_start_of_proper_name, test_preserves_wh_shaped_token_when_entity_starts_question, test_removes_capitalized_who_pronoun_at_start_of_question, test_preserves_english_holding_action_and_location, test_removes_unknown_english_doing_action, test_removes_english_fronted_auxiliary_but_keeps_constraints, test_removes_dangling_english_copula, test_yes_no_question_is_not_rewritten_as_wh_question, test_output_contract_and_empty_decomposition_fallback_are_preserved
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_query_focus_generalization.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_search_intent_cleanup_does_not_consume_a_noun_prefix, test_exact_text_cleanup_does_not_damage_a_containing_proper_name, test_qa_cleanup_preserves_proper_noun_that_starts_like_a_wh_word, test_long_query_prefers_multi_term_focus_over_a_generic_single_overlap
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_query_refiner.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_exact_string_license_plate, test_exact_string_generic_patterns, test_vietnamese_path_preserved, test_cultural_term_preservation, test_cultural_terms_require_whole_phrase_matches, test_polysemous_compounds_do_not_emit_unrelated_object, test_standalone_object_meaning_is_still_extracted, test_object_extraction_prefers_specific_compound, test_visual_query_keeps_semantic_focus_without_search_or_ocr_instructions, test_search_intent_does_not_consume_prefix_of_semantic_word, test_search_intent_strips_complete_media_phrase, test_exact_removal_preserves_larger_words_and_names, test_quoted_labelled_exact_removes_complete_text_constraint, test_text_label_without_exact_value_is_not_removed_as_dangling, test_qa_visual_query_removes_question_scaffolding, test_qa_who_rewrite_preserves_title_case_proper_noun, test_no_hallucination, test_invalid_json_fallback
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_qwen_runtime_search.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _sha256, _canonical_uid, _write_generation, _write_spool, StubEncoder, runtime, _search, _touch_model, test_configured_and_readiness, test_readiness_cache_rechecks_model_presence, test_readiness_reports_missing_model_and_missing_root, test_refuses_siglip_index, test_kis_search_returns_verified_visual_top, test_ocr_evidence_expands_candidates, test_video_level_text_evidence_attached_to_every_row, test_qa_uses_same_pipeline_and_empty_query_rejected, test_trake_success_returns_ordered_frames, test_trake_impossible_sequence_errors
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_ranking_metrics.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_perfect_and_reversed_ranking, test_partial_empty_and_nonpositive_k, test_duplicates_do_not_inflate_metrics
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_run_dev.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** serving, test_proxy_bounds_stalled_upstream, test_proxy_network_error_closes_upstream
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_samplers.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_sampling_config, TestFixedFPSStrategy, TestShotPlusFixedFPSStrategy, TestAdaptiveDenseStrategy, TestFrameIdGeneration
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_sampling_metadata.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_frames, test_sampling_reason_periodic_only, test_sampling_reason_shot_only, test_sampling_reason_periodic_plus_shot_overlap, test_multiple_shots_assigns_stable_zero_based_shot_ids, test_dedup_alignment_with_retained_metadata, test_old_artifact_backward_compatibility, test_index_publication_payload_preserves_sampling_metadata
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_semantic_reranker.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** candidates, test_callback_is_used_and_metadata_preserved, test_dot_product_fallback_and_top_k, test_batch_scoring_and_equal_score_ties_are_deterministic, test_model_failure_falls_back_to_retrieval_order
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_shot_aware_sampler.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_frames, MockShotDetector, test_short_shot_between_periodic_samples_retained, test_midpoint_overlaps_periodic_sample_exact_dedup, test_multiple_shots_coverage_invariant, test_chronological_ordering_and_no_duplicates, test_boundary_shots_near_video_start_and_end, test_invalid_detector_output_handled_gracefully, test_sparse_shot_determinism, test_pipeline_legacy_mode_does_not_invoke_detector
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_siglip2.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** TestSigLIP2Encoder
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_siglip2_long_text.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** FakeProcessor, FakeTokenizer, FakeModel, make_encoder, test_long_text_chunks_are_aggregated_back_to_each_query, test_short_text_is_unchanged_by_chunk_mode_when_not_normalized, test_chunk_cap_samples_across_full_query_including_tail, test_invalid_long_text_configuration_is_rejected, test_processor_without_tokenizer_is_rejected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_sparse_periodic_sampler.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _create_synthetic_frames, test_legacy_mode_default_1s_sampling, test_sparse_3s_mode_sampling, test_sparse_5s_mode_sampling, test_non_divisible_duration_behavior, test_sampling_determinism, test_reject_invalid_sampler_interval, test_video_ingest_config_modes, test_video_ingest_config_from_env
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_temporal_nms.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** apply_temporal_nms, test_temporal_nms_dedup
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_temporal_refiner.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** create_synthetic_video, SyntheticColorEncoder, test_frame_identity_invariant_preserves_exact_pyav_ordinals, test_short_event_sampling_recovers_missing_sparse_frame, test_ordered_trake_monotonic_sequence_alignment, test_region_generation_and_overlapping_merge, test_max_region_limits_safety, test_cache_reuse_with_sentinel_encoder, test_cache_corruption_safe_rebuild, test_safe_fallback_on_refinement_error
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_text_backends.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_tesseract_is_default_and_cpu, test_faster_whisper_uses_cuda_index, test_easyocr_gpu_flag_comes_from_policy
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_trake_coherence.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** DummyResult, test_close_valid_sequence, test_large_gap_valid_sequence_remains_valid, test_non_monotonic_sequence, test_empty_sequence, test_single_frame_sequence, test_tie_break_mode_determinism, test_diagnostic_mode_preserves_higher_semantic_score_despite_larger_gap
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_validation_annotation.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_validate_ground_truth_template, test_reject_duplicate_ids, test_reject_unknown_video_id, test_reject_malformed_and_inverted_frame_ranges, test_unlabeled_template_validation
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_video_decoder.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_inspects_and_decodes_cfr_fixture_in_display_order, test_sequential_roundtrip_beginning_middle_and_end
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_video_qa_m26_1.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** test_classify_how_many, test_classify_where, test_classify_disease, test_classify_who, answerer, test_abstain_on_empty_evidence, test_abstain_on_zero_evidence_support, test_abstain_stopword_location, test_abstain_bare_number_no_context, test_abstain_garbled_ocr_who, test_abstain_unsupported_question, test_answer_disease_from_asr, test_answer_how_many_with_unit, test_answer_proper_location, test_fusion_visual_query_no_text_needed, test_fusion_formula_bounded, test_fusion_formula_text_intent, test_fusion_negative_visual_score
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tests/unit/test_video_source.py`
**Role:** Automated test coverage for the named subsystem; detailed names are in inventories/tests.csv.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** _clean_env, test_valid_video_id, test_resolve_from_cache, test_resolve_from_source_dir_serves_in_place, test_resolve_prefers_cache_over_source, _serve, test_lazy_download_from_url_template, test_lazy_download_is_atomic_on_failure, test_rejects_non_http_template, test_rejects_malformed_http_template, test_not_configured_raises, test_invalid_id_rejected
**Runtime impact:** low
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tools/__init__.py`
**Role:** Committed operations file for tools; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** module-level code
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tools/benchmark_retrieval.py`
**Role:** Committed operations file for tools; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** BenchmarkQueryInput, ConcentrationMetrics, compute_hhi, compute_concentration, compute_rank_metrics, compute_latency_stats, _matches_ground_truth, _stage_has_ground_truth, localize_failure, simulate_diversity_soft_cap, simulate_round_robin_diversification, ProductionBenchmarkRunner
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.

## `tools/prepare_validation_annotation.py`
**Role:** Committed operations file for tools; purpose inferred from path and file header.
**Used by:** operator/developer workflow
**Depends on:** imports and adjacent configuration visible in source
**Important symbols:** ValidationReport, validate_ground_truth_file
**Runtime impact:** medium
**Configuration:** environment/config references are listed in `inventories/environment-variables.csv`; no hidden values included.
**Failure implications:** test/documentation/artifact or component-specific failure
**Notes:** tracked at audited commit; untracked working-tree files are excluded.


# 22. Full environment appendix

This appendix is generated from exact environment access patterns (`os.getenv`, `os.environ.get`, direct environment indexing, Compose/shell interpolation and `.env.example`). Uppercase constants without environment access are excluded.

## `AIC_BIND_IP`
- Source: `.env.example:10`
- Consumer: .env.example
- Default/requirement: `127.0.0.1`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:11`, `docker-compose.cpu.yml:12`, `docker-compose.gpu.yml:12`, `docker-compose.gpu.yml:13`, `docker-compose.release.yml:8`, `docker-compose.release.yml:9`, `docker-compose.yml:15`

## `AIC_CACHE_DIR`
- Source: `.env.example:17`
- Consumer: .env.example
- Default/requirement: `./cache`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:36`, `deploy/install.sh:40`, `docker-compose.yml:44`, `docker-compose.yml:71`

## `AIC_CACHE_ROOT`
- Source: `docker-compose.cpu.yml:38`
- Consumer: Compose/shell interpolation
- Default/requirement: `/home/hermes/aic/cache/videos`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:44`, `docker-compose.release.yml:34`, `ops/docker/release/compose.cpu.yml:34`, `ops/docker/release/compose.gpu.yml:34`

## `AIC_DATA_DIR`
- Source: `.env.example:15`
- Consumer: .env.example
- Default/requirement: `./data`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:34`, `deploy/install.sh:40`, `docker-compose.yml:42`, `docker-compose.yml:69`

## `AIC_DATA_ROOT`
- Source: `docker-compose.cpu.yml:35`
- Consumer: Compose/shell interpolation
- Default/requirement: `/home/hermes/aic/data/aic-db-v1/runtime`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:41`, `docker-compose.release.yml:31`, `ops/docker/release/compose.cpu.yml:31`, `ops/docker/release/compose.gpu.yml:31`

## `AIC_LOGS_DIR`
- Source: `.env.example:18`
- Consumer: .env.example
- Default/requirement: `./logs`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:37`, `deploy/install.sh:40`, `docker-compose.yml:45`, `docker-compose.yml:72`

## `AIC_MODELS_DIR`
- Source: `.env.example:16`
- Consumer: .env.example
- Default/requirement: `./models`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/install.sh:35`, `deploy/install.sh:40`, `docker-compose.yml:43`, `docker-compose.yml:70`

## `AIC_MODEL_ROOT`
- Source: `docker-compose.cpu.yml:36`
- Consumer: Compose/shell interpolation
- Default/requirement: `/home/hermes/aic/models/Qwen3-VL-Embedding-2B`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:42`, `docker-compose.release.yml:32`, `ops/docker/release/compose.cpu.yml:32`, `ops/docker/release/compose.gpu.yml:32`

## `AIC_PORT`
- Source: `.env.example:11`
- Consumer: .env.example
- Default/requirement: `8000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.yml:15`

## `AIC_VIDEO_ROOT`
- Source: `docker-compose.cpu.yml:37`
- Consumer: Compose/shell interpolation
- Default/requirement: `/video/video`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:43`, `docker-compose.release.yml:33`, `ops/docker/release/compose.cpu.yml:33`, `ops/docker/release/compose.gpu.yml:33`

## `ALLOWED_ORIGINS`
- Source: `.env.example:59`
- Consumer: .env.example
- Default/requirement: `http://localhost:3000,http://127.0.0.1:3000,http://localhost:8000,http://127.0.0.1:8000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/main.py:240`, `docker-compose.cpu.yml:27`, `docker-compose.gpu.yml:28`, `docker-compose.release.yml:24`, `ops/docker/release/compose.cpu.yml:24`, `ops/docker/release/compose.gpu.yml:27`

## `ASR_CONCURRENCY`
- Source: `backend/app/runtime/operations.py:37`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `ASR_WEIGHT`
- Source: `scripts/eval_m27.py:10`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `BACKEND_URL`
- Source: `ops/finals_smoke.sh:5`
- Consumer: Compose/shell interpolation
- Default/requirement: `http://127.0.0.1:8000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `BM25_ENABLED`
- Source: `.env.example:91`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `DEBUG_API_ERRORS`
- Source: `backend/app/main.py:36`
- Consumer: Python os.getenv
- Default/requirement: `"false"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `DEBUG_QUERY_PLAN`
- Source: `.env.example:121`
- Consumer: .env.example
- Default/requirement: `false`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:67`, `backend/app/main.py:196`

## `DECODE_WORKERS`
- Source: `backend/app/runtime/operations.py:35`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `DOCKERFILE`
- Source: `docker-compose.cpu.yml:6`
- Consumer: Compose/shell interpolation
- Default/requirement: `Dockerfile`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:6`

## `E5_ENABLED`
- Source: `.env.example:90`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `FASTER_WHISPER_MODEL`
- Source: `.env.example:100`
- Consumer: .env.example
- Default/requirement: `small`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `FRONTEND_URL`
- Source: `ops/finals_smoke.sh:6`
- Consumer: Compose/shell interpolation
- Default/requirement: `http://127.0.0.1:3000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `HF_HOME`
- Source: `.env.example:23`
- Consumer: .env.example
- Default/requirement: `/cache/huggingface`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `HF_HUB_OFFLINE`
- Source: `.env.example:127`
- Consumer: .env.example
- Default/requirement: `0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:31`, `docker-compose.gpu.yml:32`, `docker-compose.release.yml:28`, `ops/docker/release/compose.cpu.yml:28`, `ops/docker/release/compose.gpu.yml:28`

## `HF_TOKEN`
- Source: `.env.example:134`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `IMAGE_REPOSITORY`
- Source: `docker-compose.cpu.yml:3`
- Consumer: Compose/shell interpolation
- Default/requirement: `gianguyen14/aic-retrieval`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:3`, `docker-compose.release.yml:3`, `ops/docker/release/compose.cpu.yml:3`, `ops/docker/release/compose.gpu.yml:3`

## `IMAGE_TAG`
- Source: `docker-compose.cpu.yml:3`
- Consumer: Compose/shell interpolation
- Default/requirement: `finals-20260917`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.gpu.yml:3`, `docker-compose.release.yml:3`, `ops/docker/release/compose.cpu.yml:3`, `ops/docker/release/compose.gpu.yml:3`

## `LOCAL_REFINE_ENABLED`
- Source: `.env.example:70`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:49`, `backend/app/core/config.py:82`

## `LOCAL_REFINE_INTERVAL_SECONDS`
- Source: `.env.example:72`
- Consumer: .env.example
- Default/requirement: `0.5`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:53`, `backend/app/core/config.py:84`

## `LOCAL_REFINE_MAX_REGIONS`
- Source: `.env.example:73`
- Consumer: .env.example
- Default/requirement: `5`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:54`, `backend/app/core/config.py:85`

## `LOCAL_REFINE_WINDOW_SECONDS`
- Source: `.env.example:71`
- Consumer: .env.example
- Default/requirement: `10.0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/local_refine_config.py:52`, `backend/app/core/config.py:83`

## `M14_9ROUTER_API_KEY`
- Source: `backend/app/retrieval/ninerouter_vision_scorer.py:68`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `MAX_MEMORY_FRACTION`
- Source: `backend/app/runtime/operations.py:24`
- Consumer: Python os.getenv
- Default/requirement: `"0.75"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/runtime/operations.py:33`

## `MAX_WORKERS`
- Source: `backend/app/runtime/operations.py:34`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `MIN_AVAILABLE_MEMORY_BYTES`
- Source: `backend/app/runtime/operations.py:25`
- Consumer: Python os.getenv
- Default/requirement: `str(2 * 1024 ** 3`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `MODEL_CACHE_DIR`
- Source: `.env.example:22`
- Consumer: .env.example
- Default/requirement: `/models`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `.env.example:34`, `backend/app/embeddings/qwen3_vl.py:36`, `backend/app/model_cache.py:8`, `docker-compose.yml:23`

## `OCR_BACKEND`
- Source: `.env.example:94`
- Consumer: .env.example
- Default/requirement: `auto`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:19`, `docker-compose.gpu.yml:38`, `projectctl.py:344`, `projectctl.py:760`

## `OCR_CPU_BACKEND`
- Source: `.env.example:95`
- Consumer: .env.example
- Default/requirement: `tesseract`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:20`

## `OCR_FALLBACK_BACKEND`
- Source: `backend/app/core/config.py:22`
- Consumer: Python os.getenv
- Default/requirement: `"tesseract"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_FALLBACK_ON_EMPTY`
- Source: `backend/app/core/config.py:25`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_FALLBACK_ON_ERROR`
- Source: `backend/app/core/config.py:26`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_FALLBACK_ON_LOW_CONFIDENCE`
- Source: `backend/app/core/config.py:27`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_GPU_BACKEND`
- Source: `.env.example:96`
- Consumer: .env.example
- Default/requirement: `paddleocr`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:21`, `docker-compose.gpu.yml:39`

## `OCR_PADDLE_DEVICE`
- Source: `backend/app/core/config.py:23`
- Consumer: Python os.getenv
- Default/requirement: `"auto"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_PADDLE_MIN_CONFIDENCE`
- Source: `.env.example:97`
- Consumer: .env.example
- Default/requirement: `0.50`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:24`

## `OCR_WEIGHT`
- Source: `scripts/eval_m27.py:9`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OCR_WORKERS`
- Source: `backend/app/runtime/operations.py:36`
- Consumer: Python os.getenv
- Default/requirement: `"1"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `OPENAI_API_KEY`
- Source: `.env.example:133`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `PRETTY_NAME`
- Source: `ops/docker/diagnose.sh:4`
- Consumer: Compose/shell interpolation
- Default/requirement: `unknown`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `PYTHONUNBUFFERED`
- Source: `Dockerfile:13`
- Consumer: Docker ENV
- Default/requirement: `1`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `QA_ANSWER_API_KEY`
- Source: `.env.example:106`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:35`, `backend/app/services/qa_answer_synthesizer.py:62`, `docker-compose.yml:29`

## `QA_ANSWER_BACKEND`
- Source: `.env.example:102`
- Consumer: .env.example
- Default/requirement: `extractive`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:32`, `docker-compose.cpu.yml:20`, `docker-compose.gpu.yml:21`, `docker-compose.release.yml:17`, `docker-compose.yml:26`, `ops/docker/release/compose.cpu.yml:17`, `ops/docker/release/compose.gpu.yml:17`

## `QA_ANSWER_MAX_EVIDENCE_CHARS`
- Source: `.env.example:108`
- Consumer: .env.example
- Default/requirement: `12000`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:37`, `docker-compose.yml:33`

## `QA_ANSWER_MAX_TOKENS`
- Source: `.env.example:110`
- Consumer: .env.example
- Default/requirement: `1024`
- Secret: **yes**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:43`, `docker-compose.yml:30`

## `QA_ANSWER_MODEL`
- Source: `.env.example:104`
- Consumer: .env.example
- Default/requirement: `agent-lite`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:34`, `docker-compose.yml:28`

## `QA_ANSWER_REMOTE_TOP_N`
- Source: `.env.example:113`
- Consumer: .env.example
- Default/requirement: `5`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:38`, `docker-compose.yml:32`

## `QA_ANSWER_TIMEOUT_SECONDS`
- Source: `.env.example:107`
- Consumer: .env.example
- Default/requirement: `8`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:36`, `docker-compose.yml:31`

## `QA_ANSWER_URL`
- Source: `.env.example:103`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:33`, `docker-compose.yml:27`

## `QUERY_REFINER_BACKEND`
- Source: `.env.example:116`
- Consumer: .env.example
- Default/requirement: `auto`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:62`

## `QUERY_REFINER_CACHE_ENABLED`
- Source: `.env.example:119`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:65`

## `QUERY_REFINER_ENABLED`
- Source: `backend/app/core/config.py:61`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/configured_search.py:87`, `docker-compose.cpu.yml:21`, `docker-compose.gpu.yml:22`, `docker-compose.release.yml:18`, `ops/docker/release/compose.cpu.yml:18`, `ops/docker/release/compose.gpu.yml:18`

## `QUERY_REFINER_MAX_VISUAL_VARIANTS`
- Source: `.env.example:118`
- Consumer: .env.example
- Default/requirement: `4`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:64`

## `QUERY_REFINER_MODEL`
- Source: `.env.example:117`
- Consumer: .env.example
- Default/requirement: `Qwen/Qwen2.5-1.5B-Instruct`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:63`

## `QUERY_REFINER_RRF_K`
- Source: `.env.example:120`
- Consumer: .env.example
- Default/requirement: `60`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:66`

## `QWEN3_VL_MODEL_DIR`
- Source: `.env.example:41`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/embeddings/qwen3_vl.py:33`, `docker-compose.yml:25`

## `QWEN_MODEL_DIR`
- Source: `backend/app/embeddings/qwen3_vl.py:33`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `RERANKER_ENABLED`
- Source: `.env.example:123`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:70`, `backend/app/services/configured_search.py:88`, `docker-compose.cpu.yml:24`, `docker-compose.gpu.yml:25`, `docker-compose.release.yml:21`, `ops/docker/release/compose.cpu.yml:21`, `ops/docker/release/compose.gpu.yml:21`

## `RERANKER_PROFILE`
- Source: `backend/app/services/candidate_reranker.py:105`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `ROOT_DIR`
- Source: `deploy/install.sh:9`
- Consumer: Compose/shell interpolation
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/rollback.sh:10`, `deploy/status.sh:9`, `deploy/update.sh:9`

## `RUN_M13_REAL_MODEL`
- Source: `tests/integration/test_m13_siglip_real.py:13`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `RUN_M14_REAL_MODEL`
- Source: `tests/integration/test_m14_9router_real.py:13`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `RUN_M15_REAL_MODEL`
- Source: `tests/integration/test_m15_siglip2_real.py:16`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `SCRIPT_DIR`
- Source: `deploy/install.sh:8`
- Consumer: Compose/shell interpolation
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/rollback.sh:9`, `deploy/status.sh:8`, `deploy/update.sh:8`

## `SEARCH_BACKEND`
- Source: `.env.example:32`
- Consumer: .env.example
- Default/requirement: `qwen3_vl`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/main.py:111`, `docker-compose.cpu.yml:19`, `docker-compose.gpu.yml:20`, `docker-compose.release.yml:16`, `docker-compose.yml:24`, `docs/SEARCH_BACKENDS.md:151`, `ops/docker/release/compose.cpu.yml:16`

## `SEARCH_ENABLE_ASR`
- Source: `backend/app/services/configured_search.py:86`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/qwen_runtime_search.py:183`, `docker-compose.cpu.yml:23`, `docker-compose.gpu.yml:24`, `docker-compose.release.yml:20`, `ops/docker/release/compose.cpu.yml:20`, `ops/docker/release/compose.gpu.yml:20`, `scripts/debug_qa.py:13`

## `SEARCH_ENABLE_OCR`
- Source: `backend/app/services/configured_search.py:85`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/qwen_runtime_search.py:182`, `docker-compose.cpu.yml:22`, `docker-compose.gpu.yml:23`, `docker-compose.release.yml:19`, `ops/docker/release/compose.cpu.yml:19`, `ops/docker/release/compose.gpu.yml:19`, `scripts/debug_qa.py:12`

## `SEARCH_ENCODER`
- Source: `backend/app/main.py:111`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docs/SEARCH_BACKENDS.md:151`

## `SIGLIP2_MODEL`
- Source: `.env.example:84`
- Consumer: .env.example
- Default/requirement: `google/siglip2-base-patch16-224`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `SIGLIP_ENABLED`
- Source: `.env.example:83`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `SIGLIP_LONG_TEXT_MODE`
- Source: `.env.example:85`
- Consumer: .env.example
- Default/requirement: `chunk_mean`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:8`

## `SIGLIP_TEXT_CHUNK_STRIDE`
- Source: `.env.example:87`
- Consumer: .env.example
- Default/requirement: `8`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:10`

## `SIGLIP_TEXT_MAX_CHUNKS`
- Source: `.env.example:88`
- Consumer: .env.example
- Default/requirement: `8`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:11`

## `SIGLIP_TEXT_MAX_LENGTH`
- Source: `.env.example:86`
- Consumer: .env.example
- Default/requirement: `64`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:9`

## `TARGET_REVISION`
- Source: `deploy/rollback.sh:21`
- Consumer: Compose/shell interpolation
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `deploy/rollback.sh:25`, `deploy/rollback.sh:26`, `deploy/rollback.sh:37`

## `TORCH_EXTRA_INDEX_URL`
- Source: `Dockerfile:10`
- Consumer: Docker ARG
- Default/requirement: `https://download.pytorch.org/whl/cpu`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `TORCH_HOME`
- Source: `.env.example:25`
- Consumer: .env.example
- Default/requirement: `/cache/torch`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `TORCH_INDEX_URL`
- Source: `Dockerfile:9`
- Consumer: Docker ARG
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:33`, `docker-compose.gpu.yml:8`, `docker-compose.gpu.yml:34`

## `TRAKE_COHERENCE_MODE`
- Source: `.env.example:124`
- Consumer: .env.example
- Default/requirement: `diagnostic`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/core/config.py:73`

## `TRAKE_TEMPORAL_REFINE_CACHE_ENABLED`
- Source: `backend/app/core/config.py:58`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:69`

## `TRAKE_TEMPORAL_REFINE_ENABLED`
- Source: `backend/app/core/config.py:52`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/configured_search.py:814`, `backend/app/services/temporal_refiner.py:63`

## `TRAKE_TEMPORAL_REFINE_MAX_FRAMES_PER_REGION`
- Source: `backend/app/core/config.py:57`
- Consumer: Python os.getenv
- Default/requirement: `"50"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:68`

## `TRAKE_TEMPORAL_REFINE_MAX_REGIONS_PER_VIDEO`
- Source: `backend/app/core/config.py:55`
- Consumer: Python os.getenv
- Default/requirement: `"3"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:66`

## `TRAKE_TEMPORAL_REFINE_MAX_TOTAL_REGIONS`
- Source: `backend/app/core/config.py:56`
- Consumer: Python os.getenv
- Default/requirement: `"6"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:67`

## `TRAKE_TEMPORAL_REFINE_SAMPLE_FPS`
- Source: `backend/app/core/config.py:54`
- Consumer: Python os.getenv
- Default/requirement: `"5.0"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:65`

## `TRAKE_TEMPORAL_REFINE_WINDOW_SECONDS`
- Source: `backend/app/core/config.py:53`
- Consumer: Python os.getenv
- Default/requirement: `"2.5"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/temporal_refiner.py:64`

## `TRANSFORMERS_CACHE`
- Source: `.env.example:24`
- Consumer: .env.example
- Default/requirement: `/cache/huggingface`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `TRANSFORMERS_OFFLINE`
- Source: `.env.example:128`
- Consumer: .env.example
- Default/requirement: `0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.cpu.yml:32`, `docker-compose.gpu.yml:33`, `docker-compose.release.yml:29`, `ops/docker/release/compose.cpu.yml:29`, `ops/docker/release/compose.gpu.yml:29`

## `VIDEOS_DIR`
- Source: `projectctl.py:645`
- Consumer: Python os.getenv
- Default/requirement: `"data/test-videos"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_CACHE_DIR`
- Source: `.env.example:56`
- Consumer: .env.example
- Default/requirement: `data/videos`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/video_source.py:42`, `docker-compose.yml:36`

## `VIDEO_EMBED_BATCH_SIZE`
- Source: `backend/app/config/video_ingest_config.py:96`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_FRAME_FORMAT`
- Source: `backend/app/config/video_ingest_config.py:94`
- Consumer: Python os.getenv
- Default/requirement: `"jpg"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_FRAME_ID_POLICY`
- Source: `backend/app/config/video_ingest_config.py:93`
- Consumer: Python os.getenv
- Default/requirement: `"zero_based"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_INDEX_TYPE`
- Source: `backend/app/config/video_ingest_config.py:99`
- Consumer: Python os.getenv
- Default/requirement: `"flat"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `projectctl.py:746`

## `VIDEO_INGEST_DEVICE`
- Source: `backend/app/config/video_ingest_config.py:97`
- Consumer: Python os.getenv
- Default/requirement: `os.getenv("COMPUTE_DEVICE", "auto"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `projectctl.py:272`

## `VIDEO_INGEST_ENABLED`
- Source: `backend/app/config/video_ingest_config.py:90`
- Consumer: Python os.getenv
- Default/requirement: `"false"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_JPEG_QUALITY`
- Source: `backend/app/config/video_ingest_config.py:95`
- Consumer: Python os.getenv
- Default/requirement: `"90"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_PROCESSED_ROOT`
- Source: `.env.example:21`
- Consumer: .env.example
- Default/requirement: `/data/processed`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:91`, `backend/app/services/configured_search.py:76`, `backend/app/services/qwen_runtime_search.py:177`, `docker-compose.yml:22`, `projectctl.py:99`, `projectctl.py:154`, `projectctl.py:456`

## `VIDEO_RAW_ROOT`
- Source: `backend/app/services/temporal_refiner.py:195`
- Consumer: Python os.getenv
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_RESUME`
- Source: `backend/app/config/video_ingest_config.py:98`
- Consumer: Python os.getenv
- Default/requirement: `"true"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_SAMPLE_INTERVAL_SECONDS`
- Source: `backend/app/config/video_ingest_config.py:92`
- Consumer: Python os.getenv
- Default/requirement: `"1.0"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VIDEO_SOURCE_DIR`
- Source: `.env.example:52`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/video_source.py:46`, `docker-compose.yml:34`

## `VIDEO_SOURCE_DIR_CONTAINER`
- Source: `.env.example:54`
- Consumer: .env.example
- Default/requirement: `/videos`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.yml:48`

## `VIDEO_SOURCE_DIR_HOST`
- Source: `.env.example:53`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `docker-compose.yml:48`

## `VIDEO_SOURCE_URL_TEMPLATE`
- Source: `.env.example:55`
- Consumer: .env.example
- Default/requirement: `no inline default at this access`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/services/video_source.py:51`, `docker-compose.yml:35`

## `VISUAL_BATCH_SIZE`
- Source: `backend/app/runtime/operations.py:38`
- Consumer: Python os.getenv
- Default/requirement: `"auto"`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: 

## `VISUAL_DEDUP_ENABLED`
- Source: `.env.example:66`
- Consumer: .env.example
- Default/requirement: `true`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:102`, `backend/app/core/config.py:78`

## `VISUAL_DEDUP_THRESHOLD`
- Source: `.env.example:67`
- Consumer: .env.example
- Default/requirement: `0.97`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:83`, `backend/app/core/config.py:79`

## `VISUAL_GLOBAL_SAMPLE_SECONDS`
- Source: `.env.example:65`
- Consumer: .env.example
- Default/requirement: `5.0`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:77`, `backend/app/core/config.py:77`

## `VISUAL_SAMPLING_MODE`
- Source: `.env.example:64`
- Consumer: .env.example
- Default/requirement: `sparse_shot`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references: `backend/app/config/video_ingest_config.py:100`, `backend/app/core/config.py:76`

## `VISUAL_WEIGHT`
- Source: `scripts/eval_m27.py:8`
- Consumer: Python os.environ[]
- Default/requirement: `REQUIRED`
- Secret: **no**
- Use: runtime/build setting; inspect consumer for parsing and validation.
- Additional references:


# 23. Source-of-truth appendix

| Topic | Authoritative source | Secondary/documented sources |
|---|---|---|
| backend selection | `backend/app/main.py:_build_configured_search` | `.env.example`, docs/SEARCH_BACKENDS.md |
| Qwen query contract | `backend/app/embeddings/qwen3_vl.py` + external model script | docs/ARCHITECTURE.md |
| SigLIP2 ingest | `backend/app/video/ingest.py` | docs/archive/milestones/m15_video_ingestion.md |
| index publication | `backend/app/video/frame_index.py` | docs/DATA_CONTRACT.md |
| active production DB | external `CURRENT` + generation.json | docs/ARCHITECTURE.md |
| API routes | `backend/app/main.py` | docs/API_REFERENCE.md |
| environment | exact os.getenv consumers + Compose | `.env.example`, docs/RUNTIME_CONFIG.md |
| container | `Dockerfile`, docker-entrypoint.sh | DOCKER.md |
| deployment | selected Compose file | deploy scripts/ops guides |
| CI | `.github/workflows/*.yml` | README/docs |
| frontend | `frontend/src/*`, `run_dev.py` | frontend/README.md |
| tests | `tests/` and CI command | pytest.ini |


# 24. Command appendix

```bash
# Native help and checks
python3 projectctl.py --help
python3 projectctl.py env --check
python3 projectctl.py smoke
python3 projectctl.py status

# Native servers
python3 projectctl.py backend --host 127.0.0.1 --port 8000
python3 run_dev.py

# Search CLI modes
python3 projectctl.py kis "query" --top-k 10
python3 projectctl.py qa "question" --top-k 10
python3 projectctl.py trake 'event one|event two' --top-k 30
python3 projectctl.py image-search /path/query.png --top-k 10

# Docker source-build path
docker build --pull -t aic:local .
docker compose -f docker-compose.yml config
docker compose -f docker-compose.yml up -d

# Image-first path (verify tag and mounts first)
docker compose -f docker-compose.release.yml config
docker compose -f docker-compose.release.yml pull
docker compose -f docker-compose.release.yml up -d
docker compose -f docker-compose.release.yml ps
docker compose -f docker-compose.release.yml logs --tail=100 aic

# Runtime diagnostics
curl -f http://127.0.0.1:8000/health/ready
ss -lntp | grep -E ':3000|:8000'
docker stats
docker top aic-retrieval
free -h
df -h
```

Never run current `projectctl.py ingest` with `/home/hermes/aic/data/aic-db-v1/runtime` as output: it creates SigLIP2-oriented artifacts and the active production DB is Qwen 1024-D.


# 25. Audits and runbooks


# Configuration consistency audit

| ID | Documentation/config says | Code/runtime says | Impact | Recommendation |
|---|---|---|---|---|
| CFG-01 | Qwen is production default and SigLIP2 legacy in current docs | `main.py` matches; explicit SigLIP2 path still exists | Correctly Qwen-primary, not Qwen-only | Keep explicit wording and test both guards |
| CFG-02 | `.env.example` includes many legacy SigLIP/refinement flags | `core/config.py` and legacy provider consume many; Qwen ignores some | Configuration surface is larger than Qwen path | label/deprecate by backend without deleting needed compatibility |
| CFG-03 | generic Compose uses localhost and local build | release Compose uses Docker Hub and 0.0.0.0/dual host ports | Operators can choose inconsistent deployment model | require explicit profile in runbook |
| CFG-04 | older compose/script defaults contain historical finals tags | image-first docs expect immutable/current tags | stale image deployment risk | remove/update stale defaults in future source change |
| CFG-05 | CI filtered tests exclude missing historical eval modules | full local pytest collects them and fails | confidence differs between commands | repair/remove historical imports or publish exact supported test command |
| CFG-06 | docs describe Qwen DB dimensions | ingest command still creates SigLIP2 artifacts | production DB replacement hazard | add explicit ingest guard/command before any DB rebuild |
| CFG-07 | Docker release expects Compose v2 | audit host has no Compose plugin | deployment cannot be validated here | install/verify plugin on operator host |


# Technical debt

- TD-01: no verified current-main Qwen frame-image ingest; production DB provenance cannot be regenerated from the documented CLI.
- TD-02: Qwen text search and SigLIP2 legacy/image/ingest paths share generic index wrappers; metadata guards prevent some misuse but command-level output-root protection is missing.
- TD-03: current Qwen image query is explicit unsupported; Qwen-only removal is blocked.
- TD-04: 5 historical test modules import absent `eval.*` files at collection.
- TD-05: broad/unlocked dependency constraints and no lock/hash file reduce reproducibility.
- TD-06: multiple generic/release/CPU/GPU/CUDA Compose topologies increase operator error.
- TD-07: CPU Qwen sample latency is high on the 2-core audit host; GPU competition path remains unvalidated.
- TD-08: no auth, rate limiting, metrics, tracing, backup service or centralized logs.
- TD-09: docs contain archived/current overlap; code/config must remain source of truth.
- TD-10: peak RSS and CPU/GPU consistency benchmark are not captured.


# Risk register

| ID | Risk | Trigger | Probability | Impact | Detection | Mitigation | Owner area | Residual risk |
|---|---|---|---|---|---|---|---|---|
| R-01 | Wrong embedding space deployed | SigLIP ingest output published to Qwen DB root | Medium | Critical | readiness backend identity/dimension; smoke | separate output roots; immutable metadata; add CLI refusal | search/data | High until Qwen ingest exists |
| R-02 | API/media exposed without auth | bind 0.0.0.0 on untrusted network | Medium | High | firewall review/HTTP access logs | VPN/auth proxy/firewall | deployment/security | Medium |
| R-03 | GPU path fails at competition | CUDA/image/device mismatch | Medium | High | qualification script and real smoke | validate on actual NVIDIA host before release | platform | High pending hardware |
| R-04 | dependency compromise/drift | unpinned packages/base image | High | Medium/High | image scan/build diff | lock/hash/pin digest | build/security | Medium |
| R-05 | test confidence overstated | missing eval modules hidden by filtered CI | High | Medium | collection logs | repair test tree and publish supported gate | engineering | High |
| R-06 | data loss/corruption | disk/host failure or bad CURRENT | Medium | Critical | checksum/cardinality/readiness | external snapshots and restore rehearsal | SRE/data | High; no native backup |
| R-07 | disk exhaustion | CUDA build/cache/log growth | High on current host | Medium | df/docker system df | builder cache policy and capacity planning | DevOps | Medium |
| R-08 | remote URL SSRF/egress | unsafe VIDEO_SOURCE_URL_TEMPLATE | Medium | High | config/network audit | URL host allowlist and egress controls | security | Medium |


# Security review

## Findings

| ID | Severity | Evidence | Impact | Exploit prerequisites | Recommendation | Confidence |
|---|---|---|---|---|---|---|
| SEC-01 | High | `backend/app/main.py` has no auth middleware/routes | network client can search and retrieve media | network reachability | authenticated reverse proxy/VPN/firewall | High |
| SEC-02 | Medium | CORS credentials enabled and headers `*` | origin mistakes increase browser trust | browser access from allowed origin | explicit origins only; no wildcard; auth layer | High |
| SEC-03 | Medium | `DEBUG_API_ERRORS` exposes exception details when true | internal paths/config leak | operator enables flag | false in production | High |
| SEC-04 | Medium | `video_source.py` supports HTTP template/download | SSRF/egress and cache poisoning risk | attacker controls ID/config or template | allowlist scheme/host, block private networks, egress policy | Medium |
| SEC-05 | Medium | remote QA Authorization bearer header | evidence/key sent externally | remote backend configured | keep extractive default; secret management/rotation | High |
| SEC-06 | Medium | broad dependencies/base image | supply-chain drift | build/pull access | pin versions/digests, lock/hash, scan | High |
| SEC-07 | Medium | no rate limits/concurrency quotas | expensive inference DoS | network access | proxy/app quotas and queue/backpressure | High |
| SEC-08 | Low | cache writable, data/model mounts operator-controlled | tampering/permissions | host mount compromise | read-only sensitive mounts; least privilege | High |
| SEC-09 | Low | no TLS in app/Compose | plaintext traffic if exposed | network interception | terminate TLS at trusted proxy | High |

## Positive controls

Pillow format/size checks, Pydantic length/range validation, filename and resolved-path checks, symlink-escape tests, sanitized default error messages, explicit Qwen/SigLIP index guards, non-root Docker user and read-only production mounts are present. No SQL, password, JWT, OAuth, queue or arbitrary shell command endpoint was found in application routes.


# Deployment runbook

## Preconditions

Use a Linux host with Docker Engine and Compose v2, enough disk for image/model/DB/cache, external Qwen model and DB v1 paths, raw video source if preview is required, and firewall/auth controls. GPU competition host additionally needs NVIDIA driver/container runtime. The repository does not install Docker or provision data.

## Directories

```bash
sudo mkdir -p /opt/aic/{config,cache/videos,logs}
# Place/verify external DB, model and videos using your approved storage procedure.
ls -ld /home/hermes/aic/data/aic-db-v1/runtime /home/hermes/aic/models/Qwen3-VL-Embedding-2B /video/video
```

Do not copy model/DB/video into the image. Keep DB/model/video mounts read-only and cache writable.

## Image-first CPU

```bash
cd /opt/aic/config
cp /path/to/repo/ops/docker/release/.env.cpu.example .env
# Set IMAGE_TAG to a verified immutable CPU tag, AIC_DATA_ROOT, AIC_MODEL_ROOT, AIC_VIDEO_ROOT, AIC_CACHE_ROOT and ALLOWED_ORIGINS.
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env config
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env pull
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env up -d
docker compose -f /path/to/repo/ops/docker/release/compose.cpu.yml --env-file .env ps
curl -f http://127.0.0.1:8000/health/ready
curl -f http://127.0.0.1:3000/
```

Run KIS/QA/TRAKE and one video range request before opening LAN access. Verify `docker top`, mounts, image digest and readiness generation/backend.

## GPU

Use the GPU Compose file only on a host with working NVIDIA runtime. Set CUDA profile values, verify `nvidia-smi`, render Compose config and require no silent CPU fallback. GPU validation is pending in this audit.

## Reboot/post-deploy

`restart: unless-stopped` is configured in release compose. After reboot verify container status, mounts, readiness, logs, port listeners and a real query.


# Upgrade runbook

1. Record current `docker compose ps`, image ID/digest, env checksum, DB CURRENT and health payload.
2. Back up env/config and record previous immutable image tag.
3. Verify target image exists and its source/runtime contract is compatible with external Qwen DB v1.
4. Render Compose config; inspect ports, env and mount modes.
5. Pull target image; do not use `latest` or historical stale tags without explicit verification.
6. Recreate one service with `up -d`; do not rebuild or mutate external DB/model.
7. Wait for readiness; run KIS, QA, TRAKE, frontend and range checks.
8. If any mandatory check fails, use rollback immediately.

Never upgrade application image and embedding DB generation as unrelated changes. DB changes require separate compatibility validation.


# Rollback runbook

## Image/config rollback

```bash
docker compose -f <selected-compose.yml> down
IMAGE_TAG=<previous-verified-tag> docker compose -f <selected-compose.yml> pull
IMAGE_TAG=<previous-verified-tag> docker compose -f <selected-compose.yml> up -d
curl -f http://127.0.0.1:8000/health/ready
```

Verify the returned generation backend/dimension and run known KIS/QA/TRAKE/media smoke.

## DB generation rollback

Restore a previously validated immutable generation and atomically restore its compatible CURRENT pointer using the approved data procedure. Verify SHA-256, FAISS ntotal, mapping/payload cardinality, encoder identity, model revision and dimensions before serving.

## Embedding warning

Never point SigLIP2 runtime at a Qwen 1024-D DB or Qwen runtime at a SigLIP2 index. If code was removed in a future migration, rollback must use a prior compatible application image/commit, not an embedding-space switch.


# Backup and restore

## Backup set

- Git source revision and deployment compose/env template.
- Secret references/secret-manager records; never plaintext in the archive unless approved encrypted storage.
- DB v1 `index/CURRENT`, all active/rollback generation files and generation metadata.
- mapping/payload/FAISS artifact hashes.
- OCR/ASR spools and their metadata/fingerprints.
- External Qwen model files plus exact revision/identity.
- Raw videos if they cannot be rehydrated; cache is disposable.

## Procedure

Use filesystem snapshot or controlled `rsync`/archive to a separate protected location. Preserve modes and symlinks. Record SHA-256. Do not write into active runtime while serving.

## Restore verification

Restore to a new root first. Check `CURRENT` parses, generation validates, SHA-256 matches, FAISS ntotal equals mapping/payload counts, all UIDs are canonical and encoder backend/model/dimension match the runtime. Run readiness and KIS/QA/TRAKE smoke before cutover.

No repository-native backup command exists; operator storage tooling is required.


# Disaster recovery

| Scenario | Action |
|---|---|
| Host lost | provision Docker/Compose, restore config and external mounts, pull pinned image, run smoke |
| Docker Hub unavailable | use cached immutable image or approved mirror; do not build from unknown state |
| DB corrupted | stop traffic, restore validated generation to new root, verify checksums/cardinality, cut over |
| CURRENT invalid | restore previous valid pointer only after generation validation |
| Model missing | readiness should fail; restore exact Qwen model mount/revision |
| Disk full | inspect df/docker system df/logs; prune safe builder cache only; never delete DB/model/videos blindly |
| CUDA OOM | stop GPU rollout, capture logs/VRAM, return to validated profile; do not change embedding semantics silently |
| Network outage | restrict/restore local service; remote QA/video URL fallbacks may be unavailable |
| Wrong backend/index | stop immediately; restore compatible app/image/DB pair |
| Permissions | inspect UID 1000/cache ownership and mount modes; keep sensitive mounts read-only |


# Troubleshooting matrix

| Symptom | Probable causes | Diagnosis | Resolution/rollback |
|---|---|---|---|
| readiness 503 | missing model, CURRENT, invalid generation | `curl /health/ready`; logs | restore exact model/DB; validate before restart |
| dimension/backend mismatch | Qwen/SigLIP mix | inspect health generation metadata | use matching image/model/DB; never coerce dimension |
| no results/500 search | model load, FAISS, evidence parse | logs; repeat health then small KIS | repair external mount or rollback image |
| CPU very slow | 2-core host/model inference | timed requests, ps/free | functional mode only; use competition GPU |
| GPU OOM/fallback | insufficient VRAM/wrong runtime | nvidia-smi, torch CUDA summary, logs | stop rollout; qualify hardware/profile |
| frontend 404 | wrong working dir/static path | curl `/`, inspect image | correct image/source; no frontend AI inference |
| video 404 | source dir/template/cache | env/mount/path checks | correct read-only videos or URL allowlist |
| CORS error | ALLOWED_ORIGINS mismatch | browser devtools/curl Origin | exact origin; no wildcard with credentials |
| port conflict | existing listener | `ss -lntp` | change host mapping or stop approved conflicting process |
| Docker pull/auth failure | registry/network/tag | `docker pull`, digest inspect | authenticate/use verified cache/mirror |
| disk full | image/build/log/cache | `df -h`, `docker system df` | safe cache/log cleanup; preserve persistent data |
| full pytest collection fails | missing historical eval modules | run `python3 -m pytest -q` | repair test tree or use CI filtered gate with limitation |
| OCR/ASR absent | optional executable/model missing | `projectctl env --check`; readiness/evidence counts | prepare external deps or accept extractive/visual-only scope |


# Benchmark statistics methodology

Raw samples are preserved in `raw-results.csv`. Values are wall-clock seconds for five fixed native HTTP requests recorded against the current Qwen runtime; they are not a paired SigLIP quality benchmark and not a GPU benchmark.

Percentiles use linear interpolation on the sorted sample with rank `(n-1)*p` (equivalent to common NumPy linear method). Sample size is n=5; therefore p90/p95 are exploratory only and must not be interpreted as reliable production percentile estimates.

- Samples: [55.4602, 30.4724, 23.8827, 26.1936, 22.7434]
- Sorted: [22.7434, 23.8827, 26.1936, 30.4724, 55.4602]
- Mean: 31.7505s
- Median/p50: 26.1936s
- Min: 22.7434s
- Max: 55.4602s
- Sample standard deviation (n-1): 13.5802s
- p90: 45.4651s
- p95: 50.4626s
- Classification: exploratory measurement only


# Test evidence timeline

1. `python -m pytest -q`: could not start because the `python` executable was absent on PATH.
2. `python3 -m pytest -q`: reached collection; failed on five missing historical imports: `eval.m12_hard_negative_dataset`, `eval.m13_5_corpus` (two tests), `eval.m14_9router_quality`, `eval.m22_end_to_end_benchmark`.
3. `python3 projectctl.py test`: invokes full pytest and reached the same collection failure.
4. `python3 projectctl.py env --check`: returned nonzero because faster-whisper and host tesseract were absent.
5. Native Qwen service health/KIS/QA had previously been observed HTTP 200; no application source migration was applied.

Conclusion: baseline collection is not fully green. This is not a migration regression because no migration code was committed or applied.


# Docker evidence

Docker Engine 26.1.5 is installed. The Docker Compose plugin was unavailable, so `docker compose -f ... config` could not execute. Dockerfile and Compose source were inspected. CPU release image/runtime had been validated in earlier work, but no new image was built for this source-documentation task. GPU build/runtime: PENDING_GPU_VALIDATION.


# 26. Final audit checklist

- [x] actual commit and dirty state recorded
- [x] complete tracked tree exported
- [x] descriptive file inventory generated for every tracked file
- [x] exact environment access inventory generated
- [x] ports, dependencies, services, workflows and tests inventoried
- [x] Qwen/SigLIP2 roles and ingest mismatch documented
- [x] API route/error contracts documented
- [x] Docker/Compose/CI/CD and hardware paths documented
- [x] CPU benchmark raw samples and correct statistics preserved
- [x] security/config consistency/technical debt/risk reviews included
- [x] deployment/upgrade/rollback/backup/DR/troubleshooting runbooks included
- [x] GPU is marked PENDING_GPU_VALIDATION, not fabricated
- [x] image query is UNVERIFIED, not fabricated
- [x] no PDF produced by design
