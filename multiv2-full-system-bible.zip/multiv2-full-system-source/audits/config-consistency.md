# Configuration consistency audit

| ID | Documentation/config says | Code/runtime says | Impact | Recommendation |
|---|---|---|---|---|
| CFG-01 | Qwen is production default and SigLIP2 legacy in current docs | `main.py` matches; explicit SigLIP2 path still exists | Correctly Qwen-primary, not Qwen-only | Keep explicit wording and test both guards |
| CFG-02 | `.env.example` includes many legacy SigLIP/refinement flags | `core/config.py` and legacy provider consume many; Qwen ignores some | Configuration surface is larger than Qwen path | label/deprecate by backend without deleting needed compatibility |
| CFG-03 | generic Compose uses localhost and local build | release Compose uses Docker Hub and 0.0.0.0/dual host ports | Operators can choose inconsistent deployment model | require explicit profile in runbook |
| CFG-04 | older compose/script defaults contain historical finals tags | image-first docs expect immutable/current tags | stale image deployment risk | remove/update stale defaults in future source change |
| CFG-05 | CI filtered tests exclude missing historical eval modules | full local pytest collects them and fails | confidence differs between commands | repair/remove historical imports or publish exact supported test command |
| CFG-06 | docs describe Qwen DB dimensions | ingest command still creates SigLIP2 artifacts | production DB replacement hazard | add explicit ingest guard/command before any DB rebuild |
| CFG-07 | Docker release expects Compose v2 | audit host has no Compose plugin | deployment cannot be validated here | install/verify plugin on operator host |
