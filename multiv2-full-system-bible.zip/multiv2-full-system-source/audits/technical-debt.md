# Technical debt

- TD-01: no verified current-main Qwen frame-image ingest; production DB provenance cannot be regenerated from the documented CLI.
- TD-02: Qwen text search and SigLIP2 legacy/image/ingest paths share generic index wrappers; metadata guards prevent some misuse but command-level output-root protection is missing.
- TD-03: current Qwen image query is explicit unsupported; Qwen-only removal is blocked.
- TD-04: 5 historical test modules import absent `eval.*` files at collection.
- TD-05: broad/unlocked dependency constraints and no lock/hash file reduce reproducibility.
- TD-06: multiple generic/release/CPU/GPU/CUDA Compose topologies increase operator error.
- TD-07: CPU Qwen sample latency is high on the 2-core audit host; GPU competition path remains unvalidated.
- TD-08: no auth, rate limiting, metrics, tracing, backup service or centralized logs.
- TD-09: docs contain archived/current overlap; code/config must remain source of truth.
- TD-10: peak RSS and CPU/GPU consistency benchmark are not captured.
