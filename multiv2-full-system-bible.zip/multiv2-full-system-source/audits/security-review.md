# Security review

## Findings

| ID | Severity | Evidence | Impact | Exploit prerequisites | Recommendation | Confidence |
|---|---|---|---|---|---|---|
| SEC-01 | High | `backend/app/main.py` has no auth middleware/routes | network client can search and retrieve media | network reachability | authenticated reverse proxy/VPN/firewall | High |
| SEC-02 | Medium | CORS credentials enabled and headers `*` | origin mistakes increase browser trust | browser access from allowed origin | explicit origins only; no wildcard; auth layer | High |
| SEC-03 | Medium | `DEBUG_API_ERRORS` exposes exception details when true | internal paths/config leak | operator enables flag | false in production | High |
| SEC-04 | Medium | `video_source.py` supports HTTP template/download | SSRF/egress and cache poisoning risk | attacker controls ID/config or template | allowlist scheme/host, block private networks, egress policy | Medium |
| SEC-05 | Medium | remote QA Authorization bearer header | evidence/key sent externally | remote backend configured | keep extractive default; secret management/rotation | High |
| SEC-06 | Medium | broad dependencies/base image | supply-chain drift | build/pull access | pin versions/digests, lock/hash, scan | High |
| SEC-07 | Medium | no rate limits/concurrency quotas | expensive inference DoS | network access | proxy/app quotas and queue/backpressure | High |
| SEC-08 | Low | cache writable, data/model mounts operator-controlled | tampering/permissions | host mount compromise | read-only sensitive mounts; least privilege | High |
| SEC-09 | Low | no TLS in app/Compose | plaintext traffic if exposed | network interception | terminate TLS at trusted proxy | High |

## Positive controls

Pillow format/size checks, Pydantic length/range validation, filename and resolved-path checks, symlink-escape tests, sanitized default error messages, explicit Qwen/SigLIP index guards, non-root Docker user and read-only production mounts are present. No SQL, password, JWT, OAuth, queue or arbitrary shell command endpoint was found in application routes.
