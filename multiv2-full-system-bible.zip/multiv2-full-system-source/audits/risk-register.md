# Risk register

| ID | Risk | Trigger | Probability | Impact | Detection | Mitigation | Owner area | Residual risk |
|---|---|---|---|---|---|---|---|---|
| R-01 | Wrong embedding space deployed | SigLIP ingest output published to Qwen DB root | Medium | Critical | readiness backend identity/dimension; smoke | separate output roots; immutable metadata; add CLI refusal | search/data | High until Qwen ingest exists |
| R-02 | API/media exposed without auth | bind 0.0.0.0 on untrusted network | Medium | High | firewall review/HTTP access logs | VPN/auth proxy/firewall | deployment/security | Medium |
| R-03 | GPU path fails at competition | CUDA/image/device mismatch | Medium | High | qualification script and real smoke | validate on actual NVIDIA host before release | platform | High pending hardware |
| R-04 | dependency compromise/drift | unpinned packages/base image | High | Medium/High | image scan/build diff | lock/hash/pin digest | build/security | Medium |
| R-05 | test confidence overstated | missing eval modules hidden by filtered CI | High | Medium | collection logs | repair test tree and publish supported gate | engineering | High |
| R-06 | data loss/corruption | disk/host failure or bad CURRENT | Medium | Critical | checksum/cardinality/readiness | external snapshots and restore rehearsal | SRE/data | High; no native backup |
| R-07 | disk exhaustion | CUDA build/cache/log growth | High on current host | Medium | df/docker system df | builder cache policy and capacity planning | DevOps | Medium |
| R-08 | remote URL SSRF/egress | unsafe VIDEO_SOURCE_URL_TEMPLATE | Medium | High | config/network audit | URL host allowlist and egress controls | security | Medium |
