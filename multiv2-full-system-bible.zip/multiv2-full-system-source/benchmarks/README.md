# Benchmark evidence

This directory contains raw current-Qwen latency samples, correct programmatic statistics and methodology. Retrieval quality, SigLIP-vs-Qwen paired recall/MRR, GPU latency, peak RSS and CPU/GPU consistency are UNVERIFIED/PENDING_GPU_VALIDATION; no fabricated values are included.
