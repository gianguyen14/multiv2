# Benchmark statistics methodology

Raw samples are preserved in `raw-results.csv`. Values are wall-clock seconds for five fixed native HTTP requests recorded against the current Qwen runtime; they are not a paired SigLIP quality benchmark and not a GPU benchmark.

Percentiles use linear interpolation on the sorted sample with rank `(n-1)*p` (equivalent to common NumPy linear method). Sample size is n=5; therefore p90/p95 are exploratory only and must not be interpreted as reliable production percentile estimates.

- Samples: [55.4602, 30.4724, 23.8827, 26.1936, 22.7434]
- Sorted: [22.7434, 23.8827, 26.1936, 30.4724, 55.4602]
- Mean: 31.7505s
- Median/p50: 26.1936s
- Min: 22.7434s
- Max: 55.4602s
- Sample standard deviation (n-1): 13.5802s
- p90: 45.4651s
- p95: 50.4626s
- Classification: exploratory measurement only
