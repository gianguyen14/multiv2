# SigLIP2 → Qwen migration report

## Decision

`PASS_QWEN_PRIMARY`

Qwen3-VL is the verified production/default text-search backend. SigLIP2 is retained because current `main` still owns legacy ingest, image-search compatibility, and a broad test/module surface; a verified Qwen frame-image ingest contract and Qwen image-query production path were not available on `main`.

This is not `PASS_QWEN_ONLY`.

## Baseline

- Repository: `gianguyen14/multiv2`
- Requested baseline: `16386cbccf207977fa408dd2c8db614642583d3c`
- Actual audited commit: `16386cbccf207977fa408dd2c8db614642583d3c`
- Branch: `migration/qwen-only-search` (no migration code committed)
- Audit timestamp: `2026-09-19T09:24:39Z` UTC

## Evidence

- `backend/app/video/ingest.py:6,87` constructs `SigLIP2Encoder`; `projectctl.py ingest` therefore remains SigLIP2-oriented.
- `backend/app/services/qwen_runtime_search.py` loads the active Qwen text-query runtime and refuses non-Qwen index metadata.
- `backend/app/main.py:111-121` defaults to Qwen and keeps `siglip2` as explicit legacy mode.
- `backend/app/services/qwen_runtime_search.py` explicitly rejects image search; current Qwen capability reports `image: false`.
- `backend/app/services/configured_search.py` owns SigLIP2 image search and legacy multimodal/temporal paths.

## CPU validation

Host evidence:

- CPU: Intel Core i3-3217U @ 1.80GHz
- Physical cores: 2
- Logical CPUs: 4
- RAM: 9.0 GiB total; about 8.0 GiB available at observation
- CUDA: unavailable
- CPU flags include AVX and F16C; no AVX2 or AVX-512 BF16 observed

Current native Qwen runtime:

- readiness: HTTP 200
- backend: `qwen3_vl`
- generation: `gen-A-b531063ff8ce48e1b0d62739fb290c23`
- dimension: 1024
- KIS/QA requests: HTTP 200 with results
- measured five-query wall times: 22.7s, 23.9s, 26.2s, 30.5s, 55.5s
- measured warm P50: 26.2s
- measured sample P95 proxy: 30.5s
- process RSS observed during runtime: approximately 3.34 GiB; this is a point observation, not a peak-RSS experiment

These values establish CPU functional viability and operational cost. They do not reject Qwen; competition GPU validation remains required.

## Test status

Full `python3 -m pytest -q` and `python3 projectctl.py test` do not reach a normal suite result because five committed tests import absent historical modules under `eval/` (`eval.m12_hard_negative_dataset`, `eval.m13_5_corpus`, `eval.m14_9router_quality`, `eval.m22_end_to_end_benchmark`). This is a baseline repository failure, not a migration regression.

`python3 projectctl.py env --check` also reports missing `faster-whisper` and host OCR tools; the serving Qwen runtime itself is healthy.

## GPU status

`PENDING_GPU_VALIDATION`.

No NVIDIA GPU is present in the current environment. GPU absence is not evidence that the CUDA path is broken. Before competition release, validate CUDA placement, no silent CPU fallback, 1024-D normalized output, same FAISS DB/results, KIS/QA/TRAKE, GPU Docker, VRAM, throughput, and CPU/GPU ranking consistency.

## Image-query status

`UNVERIFIED_FOR_QWEN` / current production Qwen capability is `image: false`. Do not remove SigLIP2 image-search code until a Qwen image embedding contract is recovered, reproduced against stored vectors, and accepted.

## No migration commit

No production migration code was changed or committed. The migration branch remains at the baseline commit. This is the safe state because the mandatory image-query and Qwen image-ingest gates are not satisfied.
