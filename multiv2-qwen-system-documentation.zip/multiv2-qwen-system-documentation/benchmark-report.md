# Benchmark report

Status: MEASURED for current Qwen production runtime; no post-migration code was applied.

## Method

Five fixed API requests were sent to the already-running native runtime at `http://127.0.0.1:8000/api/search`, using KIS, QA, Vietnamese and English queries. The runtime was not restarted or modified. No GPU was available. No SigLIP-vs-Qwen quality comparison was claimed because the active production DB is Qwen 1024-D and no valid paired SigLIP index/query benchmark was available.

## Results

| Query type | HTTP | Results | Wall time |
|---|---:|---:|---:|
| KIS Vietnamese | 200 | 3 | 55.46 s |
| QA Vietnamese | 200 | 3 | 30.47 s |
| KIS Vietnamese | 200 | 3 | 23.88 s |
| KIS Vietnamese | 200 | 3 | 26.19 s |
| KIS English | 200 | 3 | 22.74 s |

Warm sample P50: 26.19 s.

Warm sample P95 proxy: 30.47 s.

Peak RSS: UNVERIFIED. Point RSS observation was approximately 3.34 GiB for the Uvicorn process after runtime warm-up.

GPU metrics: `PENDING_GPU_VALIDATION`.

Retrieval quality metrics: `UNVERIFIED`; no valid migration-paired ground truth comparison was run.

## Interpretation

The current Qwen CPU path is functionally usable for development and API validation, but slow on the 2-core/4-thread i3 host. This is not a competition-performance conclusion. GPU validation is mandatory before competition release.
