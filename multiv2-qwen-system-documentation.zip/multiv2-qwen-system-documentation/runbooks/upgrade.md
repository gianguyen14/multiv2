# Upgrade

1. Confirm new immutable image tag and digest.
2. Back up the deployment env and record current image digest.
3. Pull the new image.
4. Recreate the service.
5. Run `/health/ready`, KIS, QA, TRAKE and range smoke.
6. Keep the previous immutable tag for rollback.

The committed `deploy/update.sh` is a source-build workflow, while ops release guides describe Docker Hub image-first deployment. Treat these as different workflows and verify the selected compose file.
