# Troubleshooting

| Symptom | Diagnosis | Action |
|---|---|---|
| Readiness 503 | `curl /health/ready`; inspect mounts | Restore Qwen model, CURRENT, or valid DB generation. |
| Dimension mismatch | Inspect generation metadata and health | Keep Qwen 1024-D with Qwen runtime; do not use SigLIP2 index. |
| Slow CPU query | `ps`, `free -h`, timed API request | Expected on current i3 host; avoid concurrent load; validate GPU separately. |
| Port conflict | `ss -lntp` | Change host bind or stop conflicting service. |
| CORS failure | inspect `ALLOWED_ORIGINS` | Set exact frontend origin; avoid wildcard with credentials. |
| Video 404 | inspect `VIDEO_SOURCE_DIR`/template | Correct read-only video mount or source template. |
| Remote QA failure | check `QA_ANSWER_BACKEND` and URL | Use extractive default; remote backend is experimental. |
| CI collection failure | run filtered CI command | Missing historical eval modules are a known baseline issue. |
| Docker build failure | inspect disk and build logs | Reclaim safe build cache; preserve runtime assets. |
