# Rollback

Do not mix embedding spaces. Restore a previously validated image/config pair and the compatible Qwen DB generation. Do not point a SigLIP2 runtime at a Qwen 1024-D index.

```bash
docker compose -f ops/docker/release/compose.cpu.yml down
IMAGE_TAG=<previous-immutable-tag> docker compose -f ops/docker/release/compose.cpu.yml pull
IMAGE_TAG=<previous-immutable-tag> docker compose -f ops/docker/release/compose.cpu.yml up -d
curl -f http://127.0.0.1:8000/health/ready
```

The committed `deploy/rollback.sh` instead checks out a Git revision and rebuilds; it can change the working tree and is not the safest immutable-image rollback.
