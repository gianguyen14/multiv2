# Deployment runbook

## Verified image-first path

The repository documents Docker Hub image-first deployment. The active CPU image verified during prior release work was `gianguyen14/aic-retrieval:cpu-18132237cca7`; verify the registry tag/digest before use.

```bash
cp ops/docker/release/.env.cpu.example .env
# Edit host mount paths and ALLOWED_ORIGINS.
docker compose -f ops/docker/release/compose.cpu.yml --env-file .env pull
docker compose -f ops/docker/release/compose.cpu.yml --env-file .env up -d
docker compose -f ops/docker/release/compose.cpu.yml --env-file .env ps
curl -f http://127.0.0.1:8000/health/ready
```

Use read-only mounts for DB/model/videos, writable cache only. The API is unauthenticated; restrict network access.

Source: `ops/DOCKER_CPU_GUIDE.md`, `ops/docker/release/compose.cpu.yml`, `Dockerfile`.
