# Backup and restore

No repository-native backup/restore mechanism is present. External production assets requiring backup are: DB runtime/index generations and CURRENT, OCR/ASR spools, model provenance/configuration, compose env (without exposing secrets), and cache policy. Raw videos are external source data.

Use filesystem snapshots or a controlled copy to a separate host; verify checksums and cardinality (`ntotal == mapping == payloads`) before restore. Never restore by editing CURRENT to an unvalidated generation.
