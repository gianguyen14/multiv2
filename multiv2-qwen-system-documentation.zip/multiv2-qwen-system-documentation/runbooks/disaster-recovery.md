# Disaster recovery

- Container crash: inspect `docker ps -a`, logs, disk, mounts; recreate without deleting external data.
- Missing model/DB: readiness should fail; restore the external read-only mount.
- Corrupt index: restore a validated generation and CURRENT atomically.
- Registry outage: use a locally cached immutable image or private mirror; no offline registry procedure is committed.
- Disk full: inspect `df -h`, Docker system/build cache and logs; do not delete DB/model/videos blindly.
- Lost host: provision Docker, restore mounts/config, pull immutable image, run smoke.
