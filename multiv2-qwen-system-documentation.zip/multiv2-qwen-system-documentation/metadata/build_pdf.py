# PDF builder
from pathlib import Path
import sys,re
sys.path.insert(0,'/tmp/multiv2-docdeps')
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Preformatted, Table, TableStyle, KeepTogether
from reportlab.lib import colors
root=Path('/home/hermes/aic/multiv2-qwen-system-documentation')
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu-Bold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuMono','/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
md=(root/'multiv2-system-documentation.md').read_text(encoding='utf-8')
styles=getSampleStyleSheet(); styles.add(ParagraphStyle('BodyV',parent=styles['BodyText'],fontName='DejaVu',fontSize=8.3,leading=11,spaceAfter=4)); styles.add(ParagraphStyle('H1V',parent=styles['Heading1'],fontName='DejaVu-Bold',fontSize=17,leading=21,spaceBefore=12,spaceAfter=8,textColor=colors.HexColor('#123b5d'))); styles.add(ParagraphStyle('H2V',parent=styles['Heading2'],fontName='DejaVu-Bold',fontSize=12,leading=15,spaceBefore=9,spaceAfter=5,textColor=colors.HexColor('#176b87'))); styles.add(ParagraphStyle('H3V',parent=styles['Heading3'],fontName='DejaVu-Bold',fontSize=9.5,leading=12,spaceBefore=6,spaceAfter=3)); styles.add(ParagraphStyle('CodeV',parent=styles['Code'],fontName='DejaVuMono',fontSize=6.2,leading=7.5,backColor=colors.HexColor('#f3f5f7'),borderPadding=4)); styles.add(ParagraphStyle('Cover',parent=styles['Title'],fontName='DejaVu-Bold',fontSize=25,leading=31,alignment=TA_CENTER,textColor=colors.HexColor('#123b5d')))
def esc(s):
 return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def inline(s):
 s=esc(s); s=re.sub(r'`([^`]+)`',r'<font name="DejaVuMono">\1</font>',s); s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s); return s
story=[Spacer(1,45*mm),Paragraph('Multiv2 System Bible',styles['Cover']),Spacer(1,8*mm),Paragraph('Qwen migration, production architecture, operations and security audit',styles['H2V']),Spacer(1,8*mm),Paragraph('Repository: gianguyen14/multiv2<br/>Audited commit: 16386cbccf207977fa408dd2c8db614642583d3c<br/>Decision: PASS_QWEN_PRIMARY<br/>GPU status: PENDING_GPU_VALIDATION<br/>Audit date: 2026-09-19 UTC',styles['BodyV']),PageBreak()]
lines=md.splitlines(); i=0
while i<len(lines):
 line=lines[i]
 if line.startswith('# '): story.append(Paragraph(inline(line[2:]),styles['H1V']))
 elif line.startswith('## '): story.append(Paragraph(inline(line[3:]),styles['H2V']))
 elif line.startswith('### '): story.append(Paragraph(inline(line[4:]),styles['H3V']))
 elif line.startswith('```'):
  lang=line[3:]; i+=1; buf=[]
  while i<len(lines) and not lines[i].startswith('```'): buf.append(lines[i]); i+=1
  story.append(Preformatted(esc('\n'.join(buf)),styles['CodeV']))
 elif line.startswith('|'):
  table=[]
  while i<len(lines) and lines[i].startswith('|'):
   cells=[c.strip() for c in lines[i].strip('|').split('|')]
   if not all(set(c)<=set('-: ') for c in cells): table.append([Paragraph(inline(c),styles['BodyV']) for c in cells])
   i+=1
  if table:
   n=max(map(len,table)); table=[r+['']*(n-len(r)) for r in table]; t=Table(table,repeatRows=1,colWidths=[(A4[0]-30*mm)/n]*n); t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#d9edf7')),('GRID',(0,0),(-1,-1),.25,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTNAME',(0,0),(-1,-1),'DejaVu'),('FONTSIZE',(0,0),(-1,-1),6.3),('LEADING',(0,0),(-1,-1),7.5),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3)])); story.append(t); continue
 elif line.startswith('- '): story.append(Paragraph('• '+inline(line[2:]),styles['BodyV']))
 elif line.strip(): story.append(Paragraph(inline(line),styles['BodyV']))
 else: story.append(Spacer(1,2))
 i+=1
def footer(canvas,doc):
 canvas.saveState(); canvas.setFont('DejaVu',7); canvas.setFillColor(colors.grey); canvas.drawString(15*mm,10*mm,'multiv2 System Bible | source-traceable audit'); canvas.drawRightString(A4[0]-15*mm,10*mm,f'{doc.page}'); canvas.restoreState()
pdf=root/'multiv2-system-documentation.pdf'; SimpleDocTemplate(str(pdf),pagesize=A4,rightMargin=15*mm,leftMargin=15*mm,topMargin=15*mm,bottomMargin=16*mm,title='Multiv2 System Bible',author='Hermes Agent').build(story,onFirstPage=footer,onLaterPages=footer)
print(pdf,pdf.stat().st_size)
