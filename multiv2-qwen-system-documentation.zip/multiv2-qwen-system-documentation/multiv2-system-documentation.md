# Multiv2 System Bible

## Document metadata

Repository: `gianguyen14/multiv2`
Requested baseline: `16386cbccf207977fa408dd2c8db614642583d3c`
Audited commit: `16386cbccf207977fa408dd2c8db614642583d3c`
Runtime Docker commit: `18132237cca74877ce7a3e6ff9cf6b47e91a43ae`
Audited branch: `main`
Migration branch: `migration/qwen-only-search` (no migration changes committed)
Audit timestamp: `2026-09-19T09:24:39Z` UTC
Migration decision: `PASS_QWEN_PRIMARY`
GPU status: `PENDING_GPU_VALIDATION`

## Scope and evidence labels

Verified means read from committed source/config or exercised against the running runtime. Derived means calculated from verified facts. Documented means present in repository docs but not independently runtime-proven. Unknown/UNVERIFIED means not established and not used as a success claim. Runtime data, model weights, videos and untracked experiment files were not treated as repository source.

## Table of contents

1. Executive summary
2. Migration decision and gates
3. System architecture
4. Repository structure and inventory
5. Runtime components and startup
6. Search and embedding architecture
7. Data/index contract
8. API and frontend
9. Configuration and networking
10. Docker and Compose
11. Docker Hub and release lifecycle
12. CI/CD and testing
13. Observability and operations
14. Security review
15. Backup, disaster recovery and rollback
16. Technical debt and risk register
17. Source-of-truth matrix
18. Command reference
19. External services and dependencies
20. Git history and consistency audit
21. Final validation and limitations
22. Appendices

## 1. Executive summary

AIC is a multimodal video retrieval service for KIS, QA and TRAKE workflows. The current production serving path is a single FastAPI/Uvicorn process. It serves a vanilla static frontend, health endpoints, JSON search, image-upload routing, static frames and HTTP range video playback.

The active production search backend is `QwenRuntimeSearch`: Qwen3-VL-Embedding-2B encodes text queries into normalized 1024-dimensional vectors; FAISS `IndexFlatIP` recalls frames from a read-only published generation; OCR and ASR JSON spools provide lexical evidence; deterministic fusion, QA extraction and ordered TRAKE produce results. The production database and model are external mounts, not image contents.

The repository also contains a legacy SigLIP2 encoder, SigLIP2 ingest path, legacy configured search, image search, temporal refinement and tests. Current main does not provide a verified Qwen frame-image ingest command or a verified Qwen image-query production path. Therefore the safe decision is `PASS_QWEN_PRIMARY`, not Qwen-only.

## 2. Migration decision and gates

See `migration-report.md` and `benchmark-report.md`.

- CPU application/model/query/FAISS/API functional gate: PASS on current native runtime.
- CPU measured operation: 22.7–55.5 seconds for five sample API queries; sample P50 26.2 seconds.
- CPU host: Intel i3-3217U, 2 physical cores/4 logical, 9 GiB RAM, no CUDA.
- Full pytest: baseline collection failure due to missing historical `eval.*` modules; no migration regression claim.
- Qwen image-query production gate: UNVERIFIED/current backend reports `image: false`.
- Qwen frame-image ingest equivalence: UNVERIFIED; no implementation or exact provenance on main.
- GPU: PENDING_GPU_VALIDATION, not failed; no NVIDIA hardware exists here.
- No migration code was committed. Main/runtime were not changed.

## 3. System architecture

### Logical architecture

```mermaid
flowchart LR
 User[Browser / CLI] --> API[FastAPI Uvicorn]
 API --> QS[QwenRuntimeSearch]
 QS --> QE[Qwen3-VL text embedder]
 QS --> FAISS[FAISS IndexFlatIP 1024-D]
 QS --> OCR[OCR JSON spool]
 QS --> ASR[ASR JSON spool]
 API --> MEDIA[Raw video source + HTTP Range]
```

### Request lifecycle

1. Uvicorn starts `backend.app.main:app`.
2. `create_app()` selects backend from `SEARCH_BACKEND` or legacy `SEARCH_ENCODER`; default is Qwen.
3. readiness checks `CURRENT`, generation metadata, dimension and Qwen model presence.
4. `/api/search` validates Pydantic request fields.
5. Qwen lazily loads the official local embedder and encodes text.
6. FAISS recalls candidates; OCR/ASR lexical hits are projected to nearest frame UIDs.
7. Scores are fused, QA is extractive by default, and TRAKE enforces monotonic frames.
8. JSON response returns frame/video identity and evidence.

See `architecture/*.mmd` for source diagrams.

### Physical/deployment architecture

One application container/process can publish host ports 3000 and 8000 to container port 8000. External read-only mounts provide DB/model/videos; cache is writable. Native development can run a FastAPI backend on 8000 and `run_dev.py` frontend proxy on 3000.

No queue, background worker, SQL database, object-storage adapter, service mesh, TLS terminator, authentication provider, or metrics backend is present in the committed repository.

## 4. Repository structure and inventory

The committed tree contains 407 files: 117 backend files, 96 test files, 36 docs files, 30 scripts, 16 ops files, 64 artifact files, six frontend files, four deployment scripts, two workflows and build/config manifests. Full path inventory is `inventories/file-inventory.csv`; exact tree is `metadata/repository-tree.txt`.

Major areas:

- `backend/app/main.py`: FastAPI routes, CORS, headers, frontend/media serving.
- `backend/app/services/qwen_runtime_search.py`: production Qwen text retrieval.
- `backend/app/services/configured_search.py`: legacy SigLIP2 search and image path.
- `backend/app/embeddings/qwen3_vl.py`: text query adapter; current main has no `encode_image`.
- `backend/app/embeddings/siglip2.py`: legacy text/image encoder.
- `backend/app/video/ingest.py`, `m15_ingestion_pipeline.py`: legacy SigLIP2 offline ingestion and atomic index publication.
- `backend/app/video/m16_text_pipeline.py`, `text_backends.py`: OCR/ASR evidence production.
- `backend/app/video/frame_index.py`: generation, checksums, CURRENT publication and validation.
- `frontend/src`: vanilla HTML/CSS/JS UI.
- `Dockerfile`, Compose files, `docker-entrypoint.sh`: container build/runtime.
- `deploy/`, `ops/`: source-build and image-first operational scripts/guides.
- `.github/workflows`: CI and Microsoft Security DevOps scan.
- `tests/`: unit/integration/regression suites.

## 5. Runtime components and startup

### FastAPI

Entrypoint: `python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --workers 1` in Docker. Native command is exposed by `projectctl.py backend`/`dev`; defaults are `127.0.0.1` and 8000.

The one-worker choice avoids ML model duplication. Docker runs non-root `appuser`. The image contains application source only; model, DB, videos and cache are external.

### Frontend

`backend/app/main.py` directly serves `frontend/src/index.html`, styles and scripts. `run_dev.py` provides the separate 3000 development proxy. The frontend uses relative API paths and does not implement AI inference.

### Startup/readiness

No migration is run at startup. `health/live` reports process/application state. `health/ready` validates configured search readiness and model/index availability. `CURRENT` is the active generation pointer; no service writes the read-only production DB.

## 6. Search and embedding architecture

### Qwen production path

`Qwen3VlLocalEmbedder.encode_query()` loads `<model>/scripts/qwen3_vl_embedding.py`, applies the production instruction, pools the last token, truncates to the requested dimension (1024 in active DB), converts to float32 and L2-normalizes. QwenRuntimeSearch rejects an active generation whose `encoder_identity.backend` is not in its Qwen backend names.

FAISS recall depth is `max(top_k*2, 200)` bounded by ntotal. Visual scores are min-max normalized. OCR and ASR use normalized token Dice/phrase scoring. Production fixed fusion in Qwen runtime is visual 0.70, OCR 0.18, ASR 0.12. QA defaults to extractive; remote LLM is optional/experimental. TRAKE independently searches events and requires one video with strictly increasing source frame indices.

### SigLIP2 compatibility path

`ConfiguredSearch` constructs `SigLIP2Encoder` and owns legacy image search, thumbnails, broad query refinement, reranking and temporal refinement. It includes a guard refusing a Qwen-built index. `projectctl.py ingest` constructs SigLIP2Encoder and is not a Qwen production ingest command. Removing it before recovering/validating Qwen image/frame semantics would be unsafe.

## 7. Data/index contract

Active production DB v1 is external and read-only:

- generation: `gen-A-b531063ff8ce48e1b0d62739fb290c23`
- encoder: `Qwen/Qwen3-VL-Embedding-2B`
- backend identity: `qwen3_vl_embedding_2b`
- dimension: 1024
- normalization: float32 L2
- index: FAISS `IndexFlatIP`
- vector count: 47,430
- mapping count: 47,430
- payload count: 47,430
- sampling metadata: 10-second coarse production cadence
- authoritative frame identity: sequential display-order source frame index, not timestamp×FPS
- model revision recorded in generation metadata: `9f2f7e710d6d81056aa5c0a4f04764fec6bb7bda`

OCR and ASR spools are JSON records projected to frame timelines. DB v2/dense artifacts are experimental and not the active serving source. The repository does not contain a complete verified current-main Qwen frame ingest pipeline.

## 8. API and frontend

| Method | Route | Auth | Purpose | Source |
|---|---|---|---|---|
| GET | `/` | none | frontend index | `main.py` |
| GET | `/styles/{filename}` | none | safe CSS asset | `main.py` |
| GET | `/scripts/{filename}` | none | safe JS asset | `main.py` |
| GET | `/health`, `/health/live` | none | liveness/status | `main.py` |
| GET | `/health/ready` | none | readiness/index/model checks | `main.py` |
| POST | `/api/search` | none | KIS/QA/TRAKE | `main.py` |
| POST | `/api/search/image` | none | image route; Qwen current returns unsupported | `main.py`, Qwen service |
| GET/HEAD | `/api/video/{video_id}` | none | raw video/range stream | `main.py`, `video_source.py` |
| GET | `/api/frames/{video_id}/{filename}` | none | frame asset | `main.py` |

Search request limits query length to 2000, events to 20 entries and top_k to 1–1000. Image upload is limited to 15 MiB and JPEG/PNG/WebP. Path traversal protections validate filenames and resolved paths. The API has no auth or authorization.

## 9. Configuration and networking

Environment inventory is `inventories/environment-variables.csv`. Key variables:

- `SEARCH_BACKEND=qwen3_vl`; `SEARCH_ENCODER` is legacy alias.
- `VIDEO_PROCESSED_ROOT`; `QWEN3_VL_MODEL_DIR`; `MODEL_CACHE_DIR`.
- `SEARCH_ENABLE_OCR`, `SEARCH_ENABLE_ASR`; `QA_ANSWER_BACKEND=extractive`.
- `QUERY_REFINER_ENABLED`, `RERANKER_ENABLED`, TRAKE settings.
- `VIDEO_SOURCE_DIR` or `VIDEO_SOURCE_URL_TEMPLATE`; `VIDEO_CACHE_DIR`.
- `ALLOWED_ORIGINS`; `DEBUG_API_ERRORS`.
- `HF_HUB_OFFLINE`, `TRANSFORMERS_OFFLINE`.
- `AIC_BIND_IP`, `AIC_PORT` in generic compose; release compose publishes 3000 and 8000 to container 8000.
- `QA_ANSWER_API_KEY`, `OPENAI_API_KEY`, `HF_TOKEN`, and M14 key variables are secrets and must remain runtime-only.

Default generic compose binds unauthenticated API to 127.0.0.1. Release CPU/GPU compose defaults to 0.0.0.0 and requires network restriction/authentication before Internet exposure. Port details are in `inventories/ports.csv`.

## 10. Docker and Compose

`Dockerfile` is a single-stage Python 3.12-slim image. It installs OS video/OCR/runtime packages, installs CPU or CUDA-selected torch/torchvision, installs Python dependencies, copies backend/frontend/projectctl, switches to non-root `appuser`, and launches one Uvicorn worker. `.dockerignore` excludes git, env, credentials, data, models, artifacts, tests, docs, scripts and caches.

Compose variants:

- `docker-compose.yml`: local build, generic writable mounts, localhost default, optional `aic-cli` tools profile.
- `docker-compose.cpu.yml`: CPU image/build, external production mounts, ports 3000/8000→8000, Qwen defaults.
- `docker-compose.gpu.yml`: CUDA torch build argument and NVIDIA device reservation.
- `docker-compose.cuda.yml`: override fragment for a different backend/worker topology; not consistent with the single-service release compose and must not be blindly combined.
- `docker-compose.release.yml`: image-first single service, Qwen defaults and external mounts.
- `ops/docker/release/compose.*`: image-first operator compose files.

Docker Hub release identity is `gianguyen14/aic-retrieval`; tags must be immutable/explicit. Historical default tags in older compose/scripts exist and are a consistency risk; operators should override `IMAGE_TAG` with a verified current digest/tag.

## 11. Docker Hub and release lifecycle

The documented image-first flow is:

```text
GitHub main → build/validation → Docker Hub → production docker compose pull → up → health/smoke
```

The repository also retains source-build scripts (`deploy/install.sh`, `deploy/update.sh`, `deploy/rollback.sh`, `ops/docker/build-*.sh`). These workflows are not identical. `deploy/rollback.sh` checks out Git and rebuilds, while image-first rollback should use a previous immutable image tag plus compatible external DB/model.

## 12. CI/CD and testing

`ci.yml` triggers on push/pull request to main and manual dispatch. It runs Python 3.12, installs ffmpeg and tesseract, installs `.[dev]`, runs `projectctl.py env --check`, `projectctl.py smoke`, a filtered CPU pytest gate excluding slow/real-model/network/GPU and historical missing modules, then a Docker build/import gate.

`defender-for-devops.yml` runs on push/PR main and weekly schedule on Windows, executes Microsoft Security DevOps and uploads SARIF. It declares no application deployment.

Baseline local evidence: full pytest collection fails because five committed tests import missing historical `eval.*` modules. This is pre-existing baseline failure. `projectctl.py env --check` on this host reports missing faster-whisper and tesseract. Do not report the full suite as passed.

## 13. Observability and operations

Logging is standard Uvicorn/Python logging and Docker json-file logging with 10 MiB/3-file rotation in release compose. There is no Prometheus metrics endpoint, tracing backend, centralized log shipper or error reporting service. Use `docker compose logs`, `docker stats`, `docker top`, `ss -lntp`, `free -h`, `df -h`, and health endpoints.

## 14. Security review

See `audits/security-review.md`. Highest operational issue is unauthenticated API/media exposure. Use a VPN or authenticated reverse proxy and firewall. Keep CORS explicit, debug errors disabled, remote QA off unless required, mounts least-privilege and model/DB/video read-only. No SQL injection surface was found because no SQL database is present. Input path checks and upload size/type checks are implemented.

## 15. Backup, recovery and rollback

No backup mechanism is committed. Back up external DB generations/CURRENT, OCR/ASR, model revision metadata, raw source data and deployment configuration through controlled snapshots/checksum copies. Restore only validated artifacts; verify ntotal/mapping/payload cardinality and encoder identity. See runbooks.

## 16. Technical debt and risks

See `audits/technical-debt.md` and `audits/risk-register.md`. Key debt: legacy SigLIP2 remains, Qwen image ingest is missing, image query is unsupported in current Qwen, unpinned dependencies, baseline missing historical tests, overlapping Compose workflows, no auth/rate limiting/metrics/backup, and GPU validation pending.

## 17. Source-of-truth matrix

| Topic | Source of truth |
|---|---|
| API routes | `backend/app/main.py` |
| Active backend selection | `backend/app/main.py`, `qwen_runtime_search.py` |
| Qwen query contract | `backend/app/embeddings/qwen3_vl.py` + model script |
| Index publication | `backend/app/video/frame_index.py` |
| Frame identity | `backend/app/video/video_decoder.py`, `frame_record.py`, `frame_id_policy.py` |
| Runtime env | `backend/app/core/config.py`, `.env.example`, compose |
| Container | `Dockerfile`, entrypoint |
| Release deployment | `ops/docker/release/compose.*` + ops guides |
| CI | `.github/workflows/ci.yml` |
| Security policy | `SECURITY.md` (template-level policy) + source review |
| Production DB | external generation metadata/CURRENT, not git |

## 18. Command reference

```bash
# inspect
 git status --short --branch
 git log -5 --oneline
 python3 projectctl.py --help
 python3 projectctl.py env --check
 python3 projectctl.py smoke

# native backend
 VIDEO_PROCESSED_ROOT=/path/to/runtime QWEN3_VL_MODEL_DIR=/path/to/model \
   python3 projectctl.py backend --host 127.0.0.1 --port 8000

# health/search
 curl -f http://127.0.0.1:8000/health/ready
 curl -sS -H 'Content-Type: application/json' \
   --data '{"query":"...","query_type":"kis","top_k":3}' \
   http://127.0.0.1:8000/api/search

# Docker compose syntax (use the installed Compose v2 plugin)
 docker compose -f docker-compose.release.yml config
 docker compose -f docker-compose.release.yml pull
 docker compose -f docker-compose.release.yml up -d
 docker compose -f docker-compose.release.yml ps
 docker compose -f docker-compose.release.yml logs --tail=100 aic

# host diagnostics
 ss -lntp | grep -E ':3000|:8000'
 df -h
 free -h
 docker stats
 docker top aic-retrieval
```

Never run `projectctl.py ingest` against production DB v1: current implementation is SigLIP2-oriented and incompatible with Qwen 1024-D production vectors.

## 19. External services and dependencies

Verified external dependencies include GitHub, Docker Hub, Hugging Face model/package infrastructure, optional OpenAI-compatible remote QA, raw video source URLs/templates, and optional remote SSH helpers in untracked/ops tooling. Docker Hub and model availability affect cold deployment. Remote QA is not required for extractive production QA. No S3/R2, email, payment, CDN or managed DB is implemented.

## 20. Git history and consistency

`1813223` fixed torchvision installation with torch; earlier commits separated CPU/CUDA dependencies and added finals compose. `16386cb` made Docker Hub deployment image-first and changed ops guides/examples. The current application code remains Qwen-default but preserves legacy SigLIP2. Documentation and code are broadly aligned on this status, while generic compose/source-build scripts coexist with image-first release guidance.

## 21. Final validation and limitations

- Repository root/source/config/docs/workflows/Docker/Compose/tests/deploy/scripts inspected.
- Current actual main matched requested SHA at audit time.
- Native Qwen health and API functional observations passed.
- Full suite did not pass due baseline missing eval modules.
- Docker Compose validation was not executable through the installed Docker client in this session because the `docker compose` plugin was unavailable; YAML/source were inspected, so Compose runtime validation is `UNVERIFIED`.
- GPU competition validation: `PENDING_GPU_VALIDATION`.
- Image-query Qwen equivalence: `UNVERIFIED`.
- Peak RSS and quality metrics: `UNVERIFIED`.

## 22. Appendices

- File inventory: `inventories/file-inventory.csv`
- Environment inventory: `inventories/environment-variables.csv`
- Port inventory: `inventories/ports.csv`
- Dependency inventory: `inventories/dependencies.csv`
- Service inventory: `inventories/services.csv`
- Workflow inventory: `inventories/workflows.csv`
- Architecture diagrams: `architecture/*.mmd`
- Runbooks: `runbooks/*.md`
- Audits: `audits/*.md`
- Migration report: `migration-report.md`
- Benchmark report: `benchmark-report.md`
