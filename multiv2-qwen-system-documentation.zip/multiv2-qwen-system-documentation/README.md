# Multiv2 Qwen System Documentation

This package is a source-traceable audit and operations bible for `gianguyen14/multiv2`.

- Requested/audited commit: `16386cbccf207977fa408dd2c8db614642583d3c`
- Branch audited: `main`; migration work was isolated on `migration/qwen-only-search` and no migration code was committed.
- Audit timestamp: 2026-09-19 UTC.
- Decision: `PASS_QWEN_PRIMARY`.

Start with `multiv2-system-documentation.pdf`, then read `migration-report.md`, `benchmark-report.md`, and the runbooks. CSV inventories cover committed files, environment variables, ports, dependencies, services and workflows. Mermaid source files are in `architecture/`; render them with Mermaid CLI or a compatible Markdown viewer.

The Markdown System Bible is the source text used to generate the PDF. The PDF includes the same core findings, evidence, inventories, runbooks, migration status and limitations. The package does not include secrets, model weights, production DB, raw videos, or untracked experiment data.

Regeneration: rerun the audit-specific report generator and the PDF build script described in the operator environment. A portable PDF source builder is included at `metadata/build_pdf.py` in this package.

Limitations:

- No NVIDIA GPU exists on the audit host; GPU status is `PENDING_GPU_VALIDATION`.
- Full pytest collection has baseline failures due to missing historical `eval.*` modules.
- Qwen image-query and Qwen frame-image ingest equivalence are not verified; SigLIP2 remains isolated legacy/compatibility functionality.
- No repository-native backup/restore, authentication, rate limiting, metrics, or lock file was found.
