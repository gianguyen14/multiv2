# Configuration consistency audit

| Documentation/Config | Code reality | Impact |
|---|---|---|
| `.env.example` retains SigLIP flags | `main.py` defaults Qwen but explicit `siglip2` remains valid | Migration cannot be called Qwen-only; legacy is intentionally available. |
| `docker-compose.yml` defaults localhost and builds `aic:latest` | release compose uses Docker Hub and 3000/8000 aliases | Operators must select the intended compose file. |
| `docker-compose.cpu.yml` default tag is historical `finals-20260917` | later ops release examples use current immutable CPU tag | Stale default can deploy old image; override `IMAGE_TAG` explicitly. |
| `docs/API_REFERENCE.md` says image false for current Qwen | `main.py` exposes image route but Qwen rejects it | Correctly documents capability distinction. |
| `projectctl ingest` | `backend/app/video/ingest.py` constructs `SigLIP2Encoder` | It is not a production Qwen ingest path. |
| CI invokes filtered pytest and explicitly ignores historical modules | full `projectctl.py test` fails collection on absent `eval.*` modules | Baseline CI/test behavior differs from local full test. |
| Deploy scripts build from Git | ops guides are image-first | Two release models coexist. |
