# Technical debt

- Legacy SigLIP2 ingest/runtime path remains because current main does not provide verified Qwen image ingest.
- Current production Qwen search is text-query-only; `/api/search/image` is explicitly unsupported.
- Ingestion provenance for the active Qwen DB is metadata-backed but no complete current-main Qwen frame ingest command exists.
- Full local test collection references missing historical `eval.*` modules.
- Dependencies have no lock file and broad version ranges.
- Docker/compose has multiple overlapping build and image-first workflows.
- No repository-native backup/restore or monitoring/metrics stack.
- API authentication and rate limiting are absent.
- GPU validation is pending on this CPU-only host.
