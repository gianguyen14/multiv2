# Risk register

| Risk | Probability | Impact | Evidence | Mitigation |
|---|---|---|---|---|
| Public unauthenticated API exposure | Medium | High | FastAPI routes have no auth | VPN/reverse proxy/auth/firewall |
| Wrong embedding space deployment | Medium | Critical | explicit Qwen/SigLIP guards and multiple compose paths | pin image+DB pair; readiness smoke |
| GPU behavior differs from CPU | Medium | High | no GPU host validation | run required CPU/GPU consistency suite on competition hardware |
| CPU latency unsuitable for local development | High | Medium | measured 22.7–55.5s query wall time | use CPU functional mode; benchmark GPU before competition |
| Disk exhaustion during CUDA build | High on current host | Medium | prior Docker build evidence | build on GPU host or larger builder; preserve assets |
| Dependency drift | High | Medium | unpinned manifests | lock/hash dependencies |
| Historical test modules missing | High | Medium | baseline collection errors | repair test inventory or exclude explicitly with ownership |
