# Defensive security review

| Finding | Severity | Evidence | Impact | Recommendation |
|---|---|---|---|---|
| API has no application authentication/authorization | High | `backend/app/main.py`; unauthenticated routes | Anyone with network access can search/read media | Place behind authenticated reverse proxy/VPN/firewall before public exposure. |
| CORS allows credentials and arbitrary headers for configured explicit origins | Medium | `backend/app/main.py:239-254` | Browser requests from allowed origins can use credentialed requests | Keep exact origins; add auth boundary; avoid public bind without controls. |
| Optional debug mode exposes exception details | Medium | `DEBUG_API_ERRORS` in `main.py` | Internal paths/errors may leak | Keep false in production. |
| Remote QA sends bearer secret to configured external endpoint | Medium | `qa_answer_synthesizer.py` | Secret/data leave host if enabled | Keep extractive default; restrict endpoint; rotate keys. |
| Dependency versions mostly unpinned | Medium | `pyproject.toml`, requirements | Non-reproducible/supply-chain drift | Lock and hash production dependencies. |
| Raw video source template can fetch external URLs | Medium | `video_source.py` | SSRF risk if operator-controlled URL template/input | Restrict hosts/schemes and egress; use allowlist. |
| No rate limiting in app | Medium | route/middleware inventory | Resource exhaustion/model abuse | Add proxy/app rate limits and request size/time budgets. |
| Docker runs non-root but mounts can be writable | Low | `Dockerfile:84`, compose | Host cache/log writes; ownership risk | Keep DB/model/video read-only; scope writable cache. |

No SQL database, login flow, JWT, OAuth, queue, or object-storage adapter was found in the committed repository.
