# Benchmark methodology

The current native Qwen runtime was left running and queried through HTTP. Five fixed KIS/QA/Vietnamese/English requests were sent to `/api/search`; HTTP status, result count and wall latency were recorded. No ground-truth quality score was inferred from top results. SigLIP2 was not compared against the Qwen index because the embedding spaces are incompatible. No GPU was available; CPU/GPU consistency and competition throughput are `PENDING_GPU_VALIDATION`.
